package com.luminor.operations;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.http.cookie.CommonCookieAttributeHandler;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.luminor.Base.BaseTest;
import com.luminor.reports.Reporting;

public class PerformOperations extends BaseTest {

	// WebDriver driver;
	// ThreadLocal<ExtentTest> extentTest = new ThreadLocal<ExtentTest>();
	// wait for the visibility of the element

	private final static By ExploreSymbol = By.xpath("//div[@role='button']/span");

	public boolean waitForvisible(By element) {

		WebElement eleObject = null;

		WebDriverWait driverWait = new WebDriverWait(getDriver(), 10);

		try {
			eleObject = driverWait.until(ExpectedConditions.visibilityOfElementLocated(element));
			Assert.assertTrue(true);
		} catch (Exception ex) {
			eleObject = null;
		}
		if (eleObject != null) {
			// Reporting.test.pass(element+"element is present");
			return true;

		} else
			return false;
	}

	// wait for the visibility of the element
	public boolean waitUntilElementIsClickable(By element) {

		WebElement eleObject = null;

		waitForvisible(element);

		WebDriverWait driverWait = new WebDriverWait(getDriver(), 10);

		try {
			eleObject = driverWait.until(ExpectedConditions.elementToBeClickable(element));
		} catch (Exception ex) {
			eleObject = null;
		}
		if (eleObject != null)
			return true;
		else
			return false;
	}

	// click on the object
	public boolean clickOn(By element, String objectName) {

		boolean flag = false;

		try {
			if (waitForvisible(element)) {
				// scrollToViewElement(element);
				getDriver().findElement(element).click();
				flag = true;
				// Reporting.reportResult("Click : '<i>" + objectName + "</i>'", "Done");
				Reporting.test.pass(objectName + " element is present and clicked");

				try {
					Alert alert = getDriver().switchTo().alert();
					alert.accept();
				} catch (Exception e) {

				}

			} else {
				Reporting.test.fail(objectName + " element is not present and clicked");
				Assert.assertTrue(false);
				// Reporting.reportResult(objectName+ " NOT Displayed", "Fail");
				// Reporter.log("Object NOT Displayed : " + objectName);
			}
		} catch (Exception ex) {
			// Reporting.reportResult(objectName+ " NOT Displayed", "Fail");
		}

		if (flag)
			return true;
		else
			return false;
	}

	// enter the text in the field
	public void setText(By element, String objectName, String valueToEnter) {
		try {

			if (waitForvisible(element)) {
				getDriver().findElement(element).clear();
				getDriver().findElement(element).sendKeys(valueToEnter);
				String actualValue = getAttribute(element, "value");

				if (actualValue.equalsIgnoreCase(valueToEnter)) {
					Assert.assertEquals(actualValue, valueToEnter);
					System.out.println(actualValue);
					System.out.println(valueToEnter);
					Reporting.test.pass(valueToEnter + " value is entered.");
				} else
					Reporting.test.fail("value is not entered");

			} else {
				Reporting.test.fail("input box is not displayed");
			}

		} catch (Exception ex) {
			ex.printStackTrace();
			Reporting.test.fail("input box is not displayed");
		}
	}

	// enter the text in the field
	public void clearElement(By element, String objectName) {
		try {
			Thread.sleep(1000);
			if (waitForvisible(element)) {
				getDriver().findElement(element).clear();

				String actualValue = getAttribute(element, "value");

			} else {

			}

		} catch (Exception ex) {
			// Reporting.reportResult(objectName+ " NOT Displayed", "Fail");
			ex.printStackTrace();
		}
	}

	// retrieve text
	public String getText(By element, String objectName) {
		String currentMsg = "";

		try {

			currentMsg = getDriver().findElement(element).getText();
			Reporting.test.pass(objectName + " is displayed :" + currentMsg);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return currentMsg;
	}

	public void scrollToViewElement(WebElement element) {

		try {
			((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", element);
			((JavascriptExecutor) getDriver()).executeScript("window.scrollBy(0,-300)");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void mouseClick(By element, String objectName) {
		Actions act = new Actions(getDriver());

		WebElement ele = getDriver()
				.findElement(By.xpath("//div[@class='ui-menu-item-wrapper' and text()='" + objectName + "']"));

		act.moveToElement(ele).click().build().perform();

	}

	public void waitForSync(int timeToWait) {
		try {
			Thread.sleep(timeToWait);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void swtichToFrame(By frameElement) {

		verifyElementAvailableOnScreen(frameElement, "");
		switchToDefaultFrame();
		getDriver().switchTo().frame(getDriver().findElement(frameElement));

	}

	public void switchToDefaultFrame() {
		getDriver().switchTo().defaultContent();
	}

	public String getAttribute(By element, String valueToRead) {

		String actualValue = "";

		try {
			Thread.sleep(1000);

			if (valueToRead.isEmpty())
				actualValue = getDriver().findElement(element).getAttribute("value");
			else
				actualValue = getDriver().findElement(element).getAttribute(valueToRead);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			actualValue = "";
		}
		return actualValue;
	}

	public boolean verifyElementAvailableOnScreen(By element, String expectedMessage) {
		Actions act = new Actions(getDriver());
		String msg = "";

		boolean flag = false;
		try {
			if (waitForAvailableElement(element)) {
				act.moveToElement(getDriver().findElement(element)).build().perform();
				msg = getDriver().findElement(element).getText();
				Reporting.test.pass(expectedMessage + " text should be displayed");
				if (msg.isEmpty()) {
					msg = expectedMessage;
				}
				// Reporting.reportResult("Successful Message Displayed : '<i>" + msg + "</i>'",
				// "Pass");
				flag = true;
			} else {
				// Reporting.reportResult("Successful Message Displayed : '<i>" + msg + "</i>'",
				// "Fail");
			}
		} catch (Exception ex) {
			// log.info("FAILED: " + ex.getMessage());
			// CustomReport.reportResult(objectName, "Clicked", "Fail");
		}

		if (flag)
			return true;
		else
			return false;
	}

	public boolean waitForAvailableElement(By element) {

		boolean flag = false;

		for (int id = 1; id < 15; id++) {
			List<WebElement> allElement = getDriver().findElements(element);

			if (allElement.size() > 0) {
				flag = true;
				break;
			} else
				waitForSync(2000);
		}

		if (flag)
			return true;
		else
			return false;

	}

	// select on the object
	public void selectElementFromList(String element, String objectName, String valueToSelect) {
		String ValueToSelectfromList = "";
		try {

			List<WebElement> select = getDriver().findElements(By.xpath(element));
			for (int i = 1; i <= select.size(); i++) {
				System.out.println(select.size());
				WebElement elementTobeSelected = getDriver().findElement(By.xpath(element + "[" + i + "]"));
				if ((elementTobeSelected.isDisplayed())) {

					ValueToSelectfromList = elementTobeSelected.getText();
					System.out.println(ValueToSelectfromList);
					if (ValueToSelectfromList.equalsIgnoreCase(valueToSelect)) {
						elementTobeSelected.click();
						Assert.assertTrue(true, valueToSelect);
						Reporting.test.pass(ValueToSelectfromList + " is selected.");
						break;
					}

					waitForSync(3000);

				} else

					Reporting.test.fail(ValueToSelectfromList + " is not selected.");
				// Reporting.reportResult("Select: '<i>" + objectName + "</i>' as : '<i>" +
				// valueToSelect + "'</i>","Fail");

			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public String getValueFromList(By element) {
		return driver.findElement(element).getAttribute("value");

	}

	public void navigateToBack() {
		driver.navigate().back();
		waitForSync(SMALL_WAIT);
	}

	public By get_Title_Tab_Link(String title_name) {
		return (By.xpath("//a[text()='" + title_name + "']"));
	}

	public void clickOnExploreSymbol() {
		waitForSync(SMALL_WAIT);
		clickOn(ExploreSymbol, "ExploreSymbol");

	}

	public String getValueByXpath(String value, String type) {
		String xpathValue = "";
		if (waitForvisible(By.xpath("//*[text()='\"" + value + "\"']//following-sibling::span[@class='" + type + "']")))
			xpathValue = driver
					.findElement(
							By.xpath("//*[text()='\"" + value + "\"']//following-sibling::span[@class='" + type + "']"))
					.getText();
		if (xpathValue != null) {
			Reporting.test.pass("Value of " + value + " is:" + xpathValue);
			Assert.assertTrue(true, "value is present");
			return xpathValue;
		} else {
			Reporting.test.fail("value is not present");
			Assert.assertTrue(false, "value is not present");
		}
		return xpathValue;
	}

	public void clickOnUsingTxt(String text) {
		// String xpathValue="";
		try {
			if (text != null) {
				if (waitUntilElementIsClickable((By.xpath("//*[text()='" + text + "']"))))
					driver.findElement(By.xpath("//*[text()='" + text + "']")).click();
				Reporting.test.pass(text + " is present and clicked.");
				Assert.assertTrue(true, "xpath is present and clicked.");

			} else {
				Reporting.test.fail(text + " is not present and clicked.");
				Assert.assertTrue(false, "value is not present");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void clearElement(By element) {
		WebElement elementToClear = driver.findElement(element);
		String s = Keys.chord(Keys.CONTROL, "a");
		elementToClear.sendKeys(s);
		// sending DELETE key
		elementToClear.sendKeys(Keys.DELETE);
	}

	public void openLinkInNewTab(String link) {
		link = link.replaceAll("^\"+|\"+$", "");
		System.out.println(link);
		driver.findElement(By.tagName("body")).sendKeys(Keys.CONTROL + "t");

		Set<String> windowHandles = driver.getWindowHandles();

		System.out.println(windowHandles.size());

		for (String winHandle : driver.getWindowHandles()) {

			driver.switchTo().window(winHandle);

		}

		driver.navigate().to(link);
	}

	public void blankBodyParam(By element) {
		WebElement ele_acct = driver.findElement(element);
		waitForSync(WAIT_TO_LOAD);
		ele_acct.sendKeys(Keys.CONTROL + "A");
		waitForSync(WAIT_TO_LOAD);
		ele_acct.sendKeys(Keys.CONTROL, Keys.DELETE);
		waitForSync(WAIT_TO_LOAD);
	}

	public void verifyErrorBodyResponse() {
		WebElement error_response = driver.findElement(By.xpath("//*[contains(@class,'error')]"));
		// WebElement Bad_Request=driver.findElement(By.xpath("//*[text()='Bad
		// Request']"));
		String statusError = driver.findElement(By.xpath("//*[text()='Bad Request']")).getText();
		String errorResponse = driver.findElement(By.xpath("//*[text()='400']")).getText();
		
		if (waitForvisible(By.xpath("//*[contains(@class,'error')]"))) {

			System.out.println(error_response);
			System.out.println(statusError);
			if ((errorResponse.equals("400")) || statusError.contains("Bad Request")) {
				System.out.println(error_response);

				Reporting.test.pass("Status is: " + errorResponse + " and the Response is " + statusError);
			}

			else
				Reporting.test.fail("Response is: " + errorResponse + " and the Response is " + statusError);
		}
	}
	
	public void setValueInBodyParam(String value,By element) {
		
		WebElement ele = driver.findElement(element);
		value="\""+value+"\"";
		String no = ele.getText();
		waitForSync(WAIT_TO_LOAD);
		if(driver.findElement(element).isDisplayed()) {
			
			//System.out.println(AccountNo);
			
			WebElement ele_acct = getDriver().findElement(By.xpath("//textarea[@class='ace_text-input']"));
			waitForSync(WAIT_TO_LOAD);
			ele_acct.sendKeys(Keys.CONTROL + "A");
			waitForSync(WAIT_TO_LOAD);
			ele_acct.sendKeys(Keys.CONTROL + "C");
			waitForSync(WAIT_TO_LOAD);
			Toolkit toolkit = Toolkit.getDefaultToolkit();
			waitForSync(SMALL_WAIT);
			Clipboard clipboard = toolkit.getSystemClipboard();
			waitForSync(WAIT_TO_LOAD);
			String result="";
			try {
				result = (String) clipboard.getData(DataFlavor.stringFlavor);
				waitForSync(SMALL_WAIT);
			} catch (UnsupportedFlavorException e1) {
				
				e1.printStackTrace();
			} catch (IOException e1) {
				
				e1.printStackTrace();
			}
			
			//write for loop logic to replace text		
			String str = result.replace(no, value);

			ele_acct.sendKeys(str);
			
			}
		
			
		}
}
