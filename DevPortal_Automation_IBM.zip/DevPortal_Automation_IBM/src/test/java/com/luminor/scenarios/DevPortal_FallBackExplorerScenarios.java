package com.luminor.scenarios;

import java.util.Map;

import org.testng.annotations.Test;

import com.luminor.Base.BaseTest;
import com.luminor.pages.DevPortalFallBackExplorerPage;
import com.luminor.pages.DevPortalLoginPage;

public class DevPortal_FallBackExplorerScenarios extends BaseTest {

	DevPortalFallBackExplorerPage fallback = new DevPortalFallBackExplorerPage();
	DevPortalLoginPage login = new DevPortalLoginPage();

	@Test
	public void DP_01_FallbackLoginRequest_Functionality(Map<String, String> map) {
		login.loginToDevPortal(map.get("Username"), map.get("Password"));
		fallback.fallbackLoginRequest(map.get("link1"), map.get("link2"));
		fallback.fallbackfinishLoginRequest(map.get("headerParam"));
		fallback.fallBackCustomerRequest(map.get("customerName"));

	}

	@Test
	public void DP_02_FallbackGetAccountRequest_Functionality(Map<String, String> map) {
		login.loginToDevPortal(map.get("Username"), map.get("Password"));
		fallback.fallbackLoginRequest(map.get("link1"), map.get("link2"));
		fallback.fallbackfinishLoginRequest(map.get("headerParam"));
		fallback.fallBackCustomerRequest(map.get("customerName"));
		fallback.fallBackGetAccountsRequest(map.get("link1"), map.get("link3"), map.get("username"));
	}

	@Test
	public void DP_03_FallbackinitatePaymentRequest_Functionality(Map<String, String> map) {
		login.loginToDevPortal(map.get("Username"), map.get("Password"));
		fallback.fallbackLoginRequest(map.get("link1"), map.get("link2"));
		fallback.fallbackfinishLoginRequest(map.get("headerParam"));
		fallback.fallBackCustomerRequest(map.get("customerName"));
		// fallback.fallBackGetAccountsRequest(map.get("link1"),map.get("link3"),
		// map.get("username"));
		fallback.fallBackinitatePaymentRequest(map.get("link1"), map.get("link3"), map.get("username"));
		fallback.fallBackFinishPaymentRequest();
		fallback.fallBackReturnPaymentStatus();
	}

	@Test
	public void DP_04_FallbackFundsAvaialbleRequest_Functionality(Map<String, String> map) {
		login.loginToDevPortal(map.get("Username"), map.get("Password"));
		fallback.fallbackLoginRequest(map.get("link1"), map.get("link2"));
		fallback.fallbackfinishLoginRequest(map.get("headerParam"));
		fallback.fallBackCustomerRequest(map.get("customerName"));
		fallback.fallBackfundAvailableRequest(map.get("link1"), map.get("link3"), map.get("username"));

	}

	@Test
	public void DP_05_FallbackGetTransactionsRequest_Functionality(Map<String, String> map) {
		login.loginToDevPortal(map.get("Username"), map.get("Password"));
		fallback.fallbackLoginRequest(map.get("link1"), map.get("link2"));
		fallback.fallbackfinishLoginRequest(map.get("headerParam"));
		fallback.fallBackCustomerRequest(map.get("customerName"));
		fallback.fallBackGetTransactionReqest(map.get("link1"), map.get("link3"), map.get("username"),
				map.get("FromDate"), map.get("ToDate"));
	}

}
