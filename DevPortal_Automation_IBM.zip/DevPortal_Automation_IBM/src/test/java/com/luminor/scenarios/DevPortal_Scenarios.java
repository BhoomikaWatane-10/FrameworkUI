package com.luminor.scenarios;

import java.util.Map;

import org.testng.annotations.Test;

import com.luminor.Base.BaseTest;
import com.luminor.pages.DevPortalAPIExplorerConsentPage;
import com.luminor.pages.DevPortalAPIExplorerPage;
import com.luminor.pages.DevPortalAPIExplorerPaymentPage;
import com.luminor.pages.DevPortalHowToFallBackPage;
import com.luminor.pages.DevPortalLoginPage;
import com.luminor.pages.DevPortalNewsPage;
import com.luminor.pages.DevPortalStatsticsPage;
import com.luminor.pages.DevPortalWelcomePage;
import com.luminor.pages.DownloadSpecifications;

public class DevPortal_Scenarios extends BaseTest {

	DevPortalLoginPage login = new DevPortalLoginPage();
	DevPortalWelcomePage welcome = new DevPortalWelcomePage();
	DevPortalNewsPage news = new DevPortalNewsPage();
	DevPortalHowToFallBackPage fallback = new DevPortalHowToFallBackPage();
	DevPortalAPIExplorerPage APIExporer = new DevPortalAPIExplorerPage();
	DevPortalAPIExplorerConsentPage consent = new DevPortalAPIExplorerConsentPage();
	DevPortalAPIExplorerPaymentPage payment = new DevPortalAPIExplorerPaymentPage();
	DownloadSpecifications downloadpcifications = new DownloadSpecifications();
	DevPortalStatsticsPage statistics = new DevPortalStatsticsPage();
	// ThreadLocal<ExtentTest> extentTest = new ThreadLocal<ExtentTest>();

	@Test
	public void DP_01_Login_Funationality(Map<String, String> map) throws Exception {

		login.loginToDevPortal((map.get("Username")), map.get("Password"));
	}

	@Test
	public void DP_02_Welcome_Funationality(Map<String, String> map) throws Exception {

		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		welcome.clickOnWelcomeTab();

	}

	@Test
	public void DP_03_News_Funationality(Map<String, String> map) throws Exception {

		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		news.clickOnNewsTab();
	}

	@Test
	public void DP_04_HowToFallBack_Funationality(Map<String, String> map) throws Exception {

		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		fallback.clickOnHowToFallBackTab();
	}

	@Test
	public void DP_05_newTPPRegistation_Funationality(Map<String, String> map) throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		APIExporer.newTPPRegistation(map.get("LinkText1"));
	}

	@Test
	public void DP_06_getTPPApplicationStatus_Funationality(Map<String, String> map) throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		APIExporer.getTPPApplicationStatus(map.get("LinkText1"));
	}

	@Test
	public void DP_07_updateTppApplication_Funationality(Map<String, String> map) throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		APIExporer.updateTPPApplication(map.get("LinkText1"));
	}

	@Test
	public void DP_08_userLoginPage_Funationality(Map<String, String> map) throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		APIExporer.userLoginPage(map.get("Language"), map.get("BankUserName"), map.get("country"));

	}

	@Test
	public void DP_09_getListOfAvailableAccounts_Funationality(Map<String, String> map) throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		APIExporer.getListOfAvailableAccounts(map.get("BankUserName"));
	}

	@Test
	public void DP_10_createConsentandAuthorizeandGetAccountInformationTppRedriectFalse_Funationality(
			Map<String, String> map) throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		consent.createConsent(map.get("TppRedirectPreferred"), map.get("BankUsernameForConsentAuthorization"),
				map.get("LinkText1"), map.get("FieldValuesFromResponse1"), map.get("StringDataType"));
		consent.getConsentDetails(map.get("FieldValuesFromResponse1"), map.get("StringDataType"));
		consent.geConsentStatus(map.get("FieldValuesFromResponse1"), map.get("StringDataType"));

		consent.initiateconsentAuthorization();
		consent.getconsentAuthorization(map.get("FieldValuesFromResponse1"), map.get("StringDataType"));
		consent.getconsentAuthorizationDetails(map.get("FieldValuesFromResponse1"), map.get("StringDataType"));
		consent.updateConsentAuthorizationDetails(map.get("FieldValuesFromResponse1"), map.get("StringDataType"));
		consent.getConsentAuthorizationStatus();

		consent.AcoountInformation(map.get("FieldValuesFromResponse1"), map.get("StringDataType"),
				map.get("NumericDataType"), map.get("BooleanDataType"));
	}

	@Test
	public void DP_11_fundsAvailableOnAccountConfirmation_Funationality(Map<String, String> map) throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		consent.createConsent(map.get("TppRedirectPreferred"), map.get("BankUsernameForConsentAuthorization"),
				map.get("LinkText1"), map.get("FieldValuesFromResponse1"), map.get("StringDataType"));
		consent.getConsentDetails(map.get("FieldValuesFromResponse1"), map.get("StringDataType"));
		consent.geConsentStatus(map.get("FieldValuesFromResponse1"), map.get("StringDataType"));// delete this when
																								// tppredirectpreferred=true
		consent.initiateconsentAuthorization();
		consent.getconsentAuthorization(map.get("FieldValuesFromResponse1"), map.get("StringDataType"));
		consent.getconsentAuthorizationDetails(map.get("FieldValuesFromResponse1"), map.get("StringDataType"));
		consent.updateConsentAuthorizationDetails(map.get("FieldValuesFromResponse1"), map.get("StringDataType"));
		consent.getConsentAuthorizationStatus();
		consent.confirmFundsAvailabilityOnAccount(map.get("FieldValuesFromResponse1"), map.get("StringDataType"),
				map.get("NumericDataType"), map.get("BooleanDataType"));
	}

	@Test
	public void DP_12_PaymmentIntiationAndAuthorization_TppRedirectTrue_functionality(Map<String, String> map)
			throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		payment.initatePayment(map.get("TppRedirectPreferred"), map.get("LinkText1"),
				map.get("FieldValuesFromResponse1"), map.get("StringDataType"), map.get("BankUserName"));
		payment.getPaymentStatus(map.get("FieldValuesFromResponse1"), map.get("StringDataType"));
		payment.getPaymentFee(map.get("FieldValuesFromResponse1"), map.get("StringDataType"),
				map.get("NumericDataType"));
		payment.getinitiatePaymentAuthorization(map.get("FieldValuesFromResponse1"), map.get("StringDataType"));
		payment.getPaymentAuthorization(map.get("FieldValuesFromResponse1"), map.get("NumericDataType"));
		payment.getPaymentAuthorizationDetail(map.get("FieldValuesFromResponse1"), map.get("StringDataType"));
		payment.updatePaymentAuthorizationDetail(map.get("FieldValuesFromResponse1"), map.get("StringDataType"));
		payment.getPaymentAuthorizationStatus();
	}

	@Test
	public void DP_13_createConsentandGetAccountInformationTppRedirectTrue_Funationality(Map<String, String> map)
			throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		consent.createConsent(map.get("TppRedirectPreferred"), map.get("BankUsernameForConsentAuthorization"),
				map.get("LinkText1"), map.get("FieldValuesFromResponse1"), map.get("StringDataType"));
		consent.getConsentDetails(map.get("FieldValuesFromResponse1"), map.get("StringDataType"));
		consent.geConsentStatus(map.get("FieldValuesFromResponse1"), map.get("StringDataType"));
		consent.AcoountInformation(map.get("FieldValuesFromResponse1"), map.get("StringDataType"),
				map.get("NumericDataType"), map.get("BooleanDataType"));
	}

	@Test
	public void DP_14_downloadSpecifications_TPPRegistration_JSON_Funationality(Map<String, String> map)
			throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		downloadpcifications.downloadSpecifications(map.get("LinkName"), map.get("FileType"),
				map.get("DownloadFilePath"));
	}

	@Test
	public void DP_15_downloadSpecifications_LoginPage_JSON_Funationality(Map<String, String> map) throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		downloadpcifications.downloadSpecifications(map.get("LinkName"), map.get("FileType"),
				map.get("DownloadFilePath"));
	}

	@Test
	public void DP_16_downloadSpecifications_UserAuthentication_JSON_Funationality(Map<String, String> map)
			throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		downloadpcifications.downloadSpecifications(map.get("LinkName"), map.get("FileType"),
				map.get("DownloadFilePath"));
	}

	@Test
	public void DP_17_downloadSpecifications_ListOfAvailableAccounts_JSON_Funationality(Map<String, String> map)
			throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		downloadpcifications.downloadSpecifications(map.get("LinkName"), map.get("FileType"),
				map.get("DownloadFilePath"));
	}

	@Test
	public void DP_18_downloadSpecifications_Consents_JSON_Funationality(Map<String, String> map) throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		downloadpcifications.downloadSpecifications(map.get("LinkName"), map.get("FileType"),
				map.get("DownloadFilePath"));
	}

	@Test
	public void DP_19_downloadSpecifications_consentAuthorisation_JSON_Funationality(Map<String, String> map)
			throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		downloadpcifications.downloadSpecifications(map.get("LinkName"), map.get("FileType"),
				map.get("DownloadFilePath"));
	}

	@Test
	public void DP_20_downloadSpecifications_AcountInformation_JSON_Funationality(Map<String, String> map)
			throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		downloadpcifications.downloadSpecifications(map.get("LinkName"), map.get("FileType"),
				map.get("DownloadFilePath"));
	}

	@Test
	public void DP_21_downloadSpecifications_PaymentInitiationAndInformation_JSON_Funationality(Map<String, String> map)
			throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		downloadpcifications.downloadSpecifications(map.get("LinkName"), map.get("FileType"),
				map.get("DownloadFilePath"));
	}

	@Test
	public void DP_22_downloadSpecifications_PaymentAuthorisation_JSON_Funationality(Map<String, String> map)
			throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		downloadpcifications.downloadSpecifications(map.get("LinkName"), map.get("FileType"),
				map.get("DownloadFilePath"));
	}

	@Test
	public void DP_23_downloadSpecifications_fundConfirmation_JSON_Funationality(Map<String, String> map)
			throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		downloadpcifications.downloadSpecifications(map.get("LinkName"), map.get("FileType"),
				map.get("DownloadFilePath"));
	}

	@Test
	public void DP_24_downloadSpecifications_TPPRegistration_YAML_Funationality(Map<String, String> map)
			throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		downloadpcifications.downloadSpecifications(map.get("LinkName"), map.get("FileType"),
				map.get("DownloadFilePath"));
	}

	@Test
	public void DP_25_downloadSpecifications_LoginPage_YAML_Funationality(Map<String, String> map) throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		downloadpcifications.downloadSpecifications(map.get("LinkName"), map.get("FileType"),
				map.get("DownloadFilePath"));
	}

	@Test
	public void DP_26_downloadSpecifications_UserAuthentication_YAML_Funationality(Map<String, String> map)
			throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		downloadpcifications.downloadSpecifications(map.get("LinkName"), map.get("FileType"),
				map.get("DownloadFilePath"));
	}

	@Test
	public void DP_27_downloadSpecifications_ListOfAvailableAccounts_YAML_Funationality(Map<String, String> map)
			throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		downloadpcifications.downloadSpecifications(map.get("LinkName"), map.get("FileType"),
				map.get("DownloadFilePath"));
	}

	@Test
	public void DP_28_downloadSpecifications_Consents_YAML_Funationality(Map<String, String> map) throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		downloadpcifications.downloadSpecifications(map.get("LinkName"), map.get("FileType"),
				map.get("DownloadFilePath"));
	}

	@Test
	public void DP_29_downloadSpecifications_consentAuthorisation_YAML_Funationality(Map<String, String> map)
			throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		downloadpcifications.downloadSpecifications(map.get("LinkName"), map.get("FileType"),
				map.get("DownloadFilePath"));
	}

	@Test
	public void DP_30_downloadSpecifications_AcountInformation_YAML_Funationality(Map<String, String> map)
			throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		downloadpcifications.downloadSpecifications(map.get("LinkName"), map.get("FileType"),
				map.get("DownloadFilePath"));
	}

	@Test
	public void DP_31_downloadSpecifications_PaymentInitiationAndInformation_YAML_Funationality(Map<String, String> map)
			throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		downloadpcifications.downloadSpecifications(map.get("LinkName"), map.get("FileType"),
				map.get("DownloadFilePath"));
	}

	@Test
	public void DP_32_downloadSpecifications_PaymentAuthorisation_YAML_Funationality(Map<String, String> map)
			throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		downloadpcifications.downloadSpecifications(map.get("LinkName"), map.get("FileType"),
				map.get("DownloadFilePath"));
	}

	@Test
	public void DP_33_downloadSpecifications_fundConfirmation_YAML_Funationality(Map<String, String> map)
			throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		downloadpcifications.downloadSpecifications(map.get("LinkName"), map.get("FileType"),
				map.get("DownloadFilePath"));
	}

	@Test
	public void DP_34_PaymmentIntiationAndAuthorization_TppRedirectrFalse_functionality(Map<String, String> map)
			throws Exception {

		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		payment.initatePayment(map.get("TppRedirectPreferred"), map.get("LinkText1"),
				map.get("FieldValuesFromResponse1"), map.get("StringDataType"), map.get("BankUserName"));
		payment.getPaymentStatus(map.get("FieldValuesFromResponse1"), map.get("StringDataType"));
		payment.getPaymentFee(map.get("FieldValuesFromResponse1"), map.get("StringDataType"),
				map.get("NumericDataType"));
		payment.getinitiatePaymentAuthorization(map.get("FieldValuesFromResponse1"), map.get("StringDataType"));
		payment.getPaymentAuthorization(map.get("FieldValuesFromResponse1"), map.get("NumericDataType"));
		payment.getPaymentAuthorizationDetail(map.get("FieldValuesFromResponse1"), map.get("StringDataType"));
		payment.updatePaymentAuthorizationDetail(map.get("FieldValuesFromResponse1"), map.get("StringDataType"));
		payment.getPaymentAuthorizationStatus();
	}

	@Test
	public void DP_35_Statistics_Funationality(Map<String, String> map) throws Exception {

		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		statistics.DownloadReport(map.get("Country"), map.get("ReportId"));

	}
}
