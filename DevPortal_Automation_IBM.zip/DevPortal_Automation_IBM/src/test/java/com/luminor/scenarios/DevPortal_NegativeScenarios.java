package com.luminor.scenarios;

import java.util.Map;

import org.testng.annotations.Test;

import com.luminor.Base.BaseTest;
import com.luminor.pages.DevPortalAPIExplorerConsentPage;
import com.luminor.pages.DevPortalAPIExplorerPage;
import com.luminor.pages.DevPortalAPIExplorerPaymentPage;
import com.luminor.pages.DevPortalLoginPage;


public class DevPortal_NegativeScenarios extends BaseTest{

	DevPortalLoginPage login = new DevPortalLoginPage();
	DevPortalAPIExplorerPage APIExporer = new DevPortalAPIExplorerPage();
	DevPortalAPIExplorerConsentPage consent = new DevPortalAPIExplorerConsentPage();
	DevPortalAPIExplorerPaymentPage payment = new DevPortalAPIExplorerPaymentPage();
	
	
	@Test
	public void DP_01_TppRegistration_Vrfy400_Funcationality(Map<String, String> map) throws Exception {

		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		APIExporer.tppRegistrationBlankBody(map.get("link1"), map.get("link2"));
	}
	
	@Test
	public void DP_02_getTppRegistration_blankValueclientid_Funcationality(Map<String, String> map) throws Exception {

		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		APIExporer.getTPPApplicationMissingclientId(map.get("link1"), map.get("link2"));
	}
	
	@Test
	public void DP_03_updateTppRegistration_Vrfy400_Funcationality(Map<String, String> map) throws Exception {

		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		APIExporer.tppRegistrationBlankBody(map.get("link1"), map.get("link2"));
	}
	
	@Test
	public void DP_04_updateTppRegistration_blankValueclientid_Funcationality(Map<String, String> map) throws Exception {

		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		APIExporer.getTPPApplicationMissingclientId(map.get("link1"), map.get("link2"));
	}
	
	@Test
	public void DP_05_LoginPage_blankValueclientid_Funcationality(Map<String, String> map) throws Exception {

		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		APIExporer.getTPPApplicationMissingclientId(map.get("link1"), map.get("link2"));
	}
	
	@Test
	public void DP_06_userAuthentication_blankValueclientid_Funcationality(Map<String, String> map) throws Exception {

		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		APIExporer.getTPPApplicationMissingclientId(map.get("link1"), map.get("link2"));
	}
	
	@Test
	public void DP_07_userAuthentication_withoutLoginTriedToGetAccessToken_Funcationality(Map<String, String> map) throws Exception {

		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		APIExporer.getTPPApplicationMissingclientId(map.get("link1"), map.get("link2"));
	}
	
	@Test
	public void DP_08_userAuthentication_blankValueclientid_Funcationality(Map<String, String> map) throws Exception {

		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		APIExporer.getTPPApplicationMissingClientIdForTokens(map.get("link1"), map.get("link2"));
	}
	
	@Test
	public void DP_09_getListOfAvailableAccountsWithwrongBearerToken_Funcationality(Map<String, String> map) throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		APIExporer.getListOfAvailableAccountsWithWrongTokens(map.get("link1"), map.get("link2"),map.get("BankUserName"));
	}


	@Test
	public void DP_10_createConsent_Vrfy400_Funcationality(Map<String, String> map) throws Exception {

		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		APIExporer.tppRegistrationBlankBody("Consents","Create new consent");
	}
	
	@Test
	public void DP_11_createconsentsWithwrongBearerToken_Funcationality(Map<String, String> map) throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		consent.CreateConsentsWithWrongTokens(map.get("link1"), map.get("link2"),map.get("BankUserName"));
	}
	
	@Test
	public void DP_12_consentDetails_blankClientId_Funcationality(Map<String, String> map) throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		APIExporer.getTPPApplicationMissingclientId(map.get("link1"), map.get("link2"));
	}
	
	@Test
	public void DP_13_initiateconsentAuthorization_blankValueclientid_Functionality(Map<String, String> map) throws Exception {

		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		APIExporer.getTPPApplicationMissingclientId(map.get("link1"), map.get("link2"));
	}
	
	@Test
	public void DP_14_getconsentAuthorization_blankValueclientid_Functionality(Map<String, String> map) throws Exception {

		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		APIExporer.getTPPApplicationMissingclientId(map.get("link1"), map.get("link2"));
	}
	
	@Test
	public void DP_15_getconsentAuthorizationDetails_blankValueclientid_Functionality(Map<String, String> map) throws Exception {

		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		APIExporer.getTPPApplicationMissingclientId(map.get("link1"), map.get("link2"));
	}
	
	@Test
	public void DP_16_updateConsentAuthorizationDetails_Vrfy400_Funcationality(Map<String, String> map) throws Exception {

		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		APIExporer.tppRegistrationBlankBody("Consents","Create new consent");
	}
	
	@Test
	public void DP_17_updateConsentAuthorizationDetails_blankValueclientid_Functionality(Map<String, String> map) throws Exception {

		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		APIExporer.getTPPApplicationMissingClientIdForTokens(map.get("link1"), map.get("link2"));
	}
	
	
	@Test
	public void DP_18_getConsentAuthorizationStatus_blankValueclientid_Functionality(Map<String, String> map) throws Exception {

		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		APIExporer.getTPPApplicationMissingClientIdForTokens(map.get("link1"), map.get("link2"));
	}
	
	@Test
	public void DP_19_getConsentAuthorizationStatusWithwrongBearerToken_Funcationality(Map<String, String> map) throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		APIExporer.getListOfAvailableAccountsWithWrongTokens(map.get("link1"), map.get("link2"),map.get("BankUserName"));
	}
	
	@Test
	public void DP_20_accountDetailsverifyBlankAccountID_Functionality(Map<String, String> map) throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		consent.verifyBlankAccountId(map.get("link1"), map.get("link2"));
	}
	
	@Test
	public void DP_21_accountBalancesverifyBlankAccountID_Functionality(Map<String, String> map) throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		consent.verifyBlankAccountId(map.get("link1"), map.get("link2"));
	}
	
	@Test
	public void DP_22_accountTransactionsverifyBlankAccountID_Functionality(Map<String, String> map) throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		consent.verifyBlankAccountId(map.get("link1"), map.get("link2"));
	}
	
	@Test
	public void DP_23_initatePaymentWithwrongBearerToken_Funcationality(Map<String, String> map) throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		APIExporer.getListOfAvailableAccountsWithWrongTokens(map.get("link1"), map.get("link2"),map.get("BankUserName"));
	}
	
	@Test
	public void DP_24_initatePayment_Vrfy400_Funcationality(Map<String, String> map) throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		APIExporer.tppRegistrationBlankBody(map.get("link1"), map.get("link2"));
	}
	
	@Test
	public void DP_25_getPaymentDetailsWithwrongBearerToken_Funcationality(Map<String, String> map) throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		APIExporer.getListOfAvailableAccountsWithWrongTokens(map.get("link1"), map.get("link2"),map.get("BankUserName"));
	}
	
	@Test
	public void DP_26_getPaymentDetails_missingPaymentId_Funcationality(Map<String, String> map) throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		payment.missingPaymentId(map.get("link1"), map.get("link2"));
	}
	
	@Test
	public void DP_27_getPaymentStatus_missingPaymentId_Funcationality(Map<String, String> map) throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		payment.missingPaymentId(map.get("link1"), map.get("link2"));
	}
	
	@Test
	public void DP_28_getPaymentAuthorization_missingPaymentId_Funcationality(Map<String, String> map) throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		payment.missingPaymentId(map.get("link1"), map.get("link2"));
	}
	
	@Test
	public void DP_29_intiatePaymentAuthorisation_missingPaymentId_Funcationality(Map<String, String> map) throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		payment.missingPaymentId(map.get("link1"), map.get("link2"));
	}
	
	@Test
	public void DP_30_getPaymentAuthorisation_missingPaymentId_Funcationality(Map<String, String> map) throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		payment.missingPaymentId(map.get("link1"), map.get("link2"));
	}
	
	@Test
	public void DP_31_updatePaymentAuthorisationDetails_missingPaymentId_Funcationality(Map<String, String> map) throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		payment.missingPaymentId(map.get("link1"), map.get("link2"));
	}
	
	@Test
	public void DP_32_updatePaymentAuthorisationDetails_Vrfy400_Funcationality(Map<String, String> map) throws Exception {

		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		APIExporer.tppRegistrationBlankBody("Consents","Create new consent");
	}
	
	@Test
	public void DP_33_getPaymentAuthorisationStatus_missingPaymentId_Funcationality(Map<String, String> map) throws Exception {
		login.loginToDevPortal((map.get("Username")), map.get("Password"));
		payment.missingPaymentId(map.get("link1"), map.get("link2"));
	}
}
