package com.luminor.scenarios;

import java.util.Map;

import org.testng.annotations.Test;

import com.luminor.Base.BaseTest;
import com.luminor.pages.DevPortalNoLoginPage;

public class DevPortal_NoLoginScenarios extends BaseTest {
	
	DevPortalNoLoginPage nologin = new DevPortalNoLoginPage();
	@Test
	public void DP_35_RegisterTPPApplication_NoLogin_functionality(Map<String, String> map) throws Exception{
		nologin.verifyNoLoginScenario(map.get("link1"),map.get("link2"));
	}
	
	@Test
	public void DP_36_GetTPPStatus_NoLogin_functionality(Map<String, String> map) throws Exception{
		nologin.verifyNoLoginScenario(map.get("link1"),map.get("link2"));
	}
	
	@Test
	public void DP_37_UpdateTPPApplication_NoLogin_functionality(Map<String, String> map) throws Exception{
		nologin.verifyNoLoginScenario(map.get("link1"),map.get("link2"));
	}
	
	@Test
	public void DP_38_OpensUserLoginPage_NoLogin_functionality(Map<String, String> map) throws Exception{
		nologin.verifyNoLoginScenario(map.get("link1"),map.get("link2"));
	}
	
	@Test
	public void DP_39_UserAuthentication_NoLogin_functionality(Map<String, String> map) throws Exception{
		nologin.verifyNoLoginScenario(map.get("link1"),map.get("link2"));
	}
	
	@Test
	public void DP_40_ListOfavailableAccounts_NoLogin_functionality(Map<String, String> map) throws Exception{
		nologin.verifyNoLoginScenario(map.get("link1"),map.get("link2"));
	}
	
	@Test
	public void DP_41_Createconsents_NoLogin_functionality(Map<String, String> map) throws Exception{
		nologin.verifyNoLoginScenario(map.get("link1"),map.get("link2"));
	}
	
	@Test
	public void DP_42_GetConsentDetails_NoLogin_functionality(Map<String, String> map) throws Exception{
		nologin.verifyNoLoginScenario(map.get("link1"),map.get("link2"));
	}
	
	@Test
	public void DP_43_RevokeConsents_NoLogin_functionality(Map<String, String> map) throws Exception{
		nologin.verifyNoLoginScenario(map.get("link1"),map.get("link2"));
	}
	
	@Test
	public void DP_44_GetConsentStatus_NoLogin_functionality(Map<String, String> map) throws Exception{
		nologin.verifyNoLoginScenario(map.get("link1"),map.get("link2"));
	}
	
	@Test
	public void DP_45_DP_45_GetConsentAuthorisation_NoLogin_functionality_NoLogin_functionality(Map<String, String> map) throws Exception{
		nologin.verifyNoLoginScenario(map.get("link1"),map.get("link2"));
	}
	
	@Test
	public void DP_46_InitateConsentAuthoisation_NoLogin_functionality(Map<String, String> map) throws Exception{
		nologin.verifyNoLoginScenario(map.get("link1"),map.get("link2"));
	}
	
	@Test
	public void DP_48_GetConsentAuthorisationDetails_NoLogin_functionality(Map<String, String> map) throws Exception{
		nologin.verifyNoLoginScenario(map.get("link1"),map.get("link2"));
	}
	
	@Test
	public void DP_49_UpdateConsentAuthorisationDetails_NoLogin_functionality(Map<String, String> map) throws Exception{
		nologin.verifyNoLoginScenario(map.get("link1"),map.get("link2"));
	}
	
	@Test
	public void DP_50_GetConsentauthorisationStatus_NoLogin_functionality(Map<String, String> map) throws Exception{
		nologin.verifyNoLoginScenario(map.get("link1"),map.get("link2"));
	}
	
	@Test
	public void DP_51_AccountInformationGetAccountswithinUserConsents_NoLogin_functionality(Map<String, String> map) throws Exception{
		nologin.verifyNoLoginScenarioforUserConsent(map.get("link1"));
	}
	
	@Test
	public void DP_52_AccountInformationGetAccountsBalance_NoLogin_functionality(Map<String, String> map) throws Exception{
		nologin.verifyNoLoginScenario(map.get("link1"),map.get("link2"));
	}
	
	@Test
	public void DP_53_AccountInformationGetAccountTransaction_NoLogin_functionality(Map<String, String> map) throws Exception{
		nologin.verifyNoLoginScenario(map.get("link1"),map.get("link2"));
	}
	
	@Test
	public void DP_54_PaymentInitatePayment_NoLogin_functionality(Map<String, String> map) throws Exception{
		nologin.verifyNoLoginScenario(map.get("link1"),map.get("link2"));
	}
	
	@Test
	public void DP_55_PaymentGetPaymentDetails_NoLogin_functionality(Map<String, String> map) throws Exception{
		nologin.verifyNoLoginScenario(map.get("link1"),map.get("link2"));
	}
	
	@Test
	public void DP_56_PaymentCancelPayment_NoLogin_functionality(Map<String, String> map) throws Exception{
		nologin.verifyNoLoginScenario(map.get("link1"),map.get("link2"));
	}
	
	@Test
	public void DP_57_PaymentGetPaymentStatus_NoLogin_functionality(Map<String, String> map) throws Exception{
		nologin.verifyNoLoginScenario(map.get("link1"),map.get("link2"));
	}
	
	@Test
	public void DP_58_PaymentGetPaymentFee_NoLogin_functionality(Map<String, String> map) throws Exception{
		nologin.verifyNoLoginScenario(map.get("link1"),map.get("link2"));
	}
	
	@Test
	public void DP_59_PaymentauthorisationGetPaymentAuthorisation_NoLogin_functionality(Map<String, String> map) throws Exception{
		nologin.verifyNoLoginScenario(map.get("link1"),map.get("link2"));
	}
	
	@Test
	public void DP_60_PaymentauthorisationIntiatePaymentAuthorisation_NoLogin_functionality(Map<String, String> map) throws Exception{
		nologin.verifyNoLoginScenario(map.get("link1"),map.get("link2"));
	}
	
	@Test
	public void DP_61_PaymentauthorisationGetPaymentAuthorisation_NoLogin_functionality(Map<String, String> map) throws Exception{
		nologin.verifyNoLoginScenario(map.get("link1"),map.get("link2"));
	}
	
	@Test
	public void DP_62_PaymentauthorisationUpdatePaymentAuthorisation_NoLogin_functionality(Map<String, String> map) throws Exception{
		nologin.verifyNoLoginScenario(map.get("link1"),map.get("link2"));
	}
	
	@Test
	public void DP_63_PaymentauthorisationCancelPaymentAuthorisation_NoLogin_functionality(Map<String, String> map) throws Exception{
		nologin.verifyNoLoginScenario(map.get("link1"),map.get("link2"));
	}
	
	@Test
	public void DP_64_PaymentauthorisationGetPaymentAuthorisationStatus_NoLogin_functionality(Map<String, String> map) throws Exception{
		nologin.verifyNoLoginScenario(map.get("link1"),map.get("link2"));
	}
	
	@Test
	public void DP_65_confirmfundOnAvialableAccounts_NoLogin_functionality(Map<String, String> map) throws Exception{
		nologin.verifyNoLoginScenario(map.get("link1"),map.get("link2"));
	}
	
	
}
