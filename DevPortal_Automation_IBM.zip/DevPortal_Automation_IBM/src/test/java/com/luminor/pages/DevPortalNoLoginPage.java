package com.luminor.pages;

import org.openqa.selenium.By;

import com.luminor.Base.BaseTest;
import com.luminor.operations.PerformOperations;
import com.luminor.reports.Reporting;

public class DevPortalNoLoginPage extends BaseTest {

	private static By signUpToTryOut = By.xpath("//*[text()='Sign Up to Try Out']");
	private static By LogInPageForDevelopers = By.xpath("//*[text()='Log in to Luminor for Developers']");
	private static By getAccountForuserConsents = By.xpath("//*[text()=\"Get accounts within user's consent\"]");
	PerformOperations common = new PerformOperations();
	DevPortalAPIExplorerPage apiexplorer = new DevPortalAPIExplorerPage();

	public void verifyNoLoginScenario(String linkname1, String linkname2) {
		common.clickOnExploreSymbol();
		apiexplorer.ClickOnapiExplorerLnk();
		common.waitForSync(SMALL_WAIT);

		common.clickOnUsingTxt(linkname1);
		common.clickOnUsingTxt(linkname2);
		common.waitForSync(SMALL_WAIT);
		common.clickOn(signUpToTryOut, "sign Up To Try Out");
		common.waitForSync(SMALL_WAIT);
		if (driver.findElement(LogInPageForDevelopers).isDisplayed()) {
			Reporting.test.pass("User need to Login to execute the API");
		} else {
			Reporting.test.fail("Login Page is displayed");

		}
	}

	public void verifyNoLoginScenarioforUserConsent(String linkname1) {
		common.clickOnExploreSymbol();
		apiexplorer.ClickOnapiExplorerLnk();
		common.waitForSync(SMALL_WAIT);

		common.clickOnUsingTxt(linkname1);
		if (common.waitForvisible(getAccountForuserConsents)) {
			driver.findElement(getAccountForuserConsents).click();
			Reporting.test.pass("Get accounts within user's consent is present and clicked");
		} else {
			Reporting.test.fail("Get accounts within user's consent is not present and clicked");
		}
		common.waitForSync(SMALL_WAIT);
		common.clickOn(signUpToTryOut, "sign Up To Try Out");
		common.waitForSync(SMALL_WAIT);
		if (driver.findElement(LogInPageForDevelopers).isDisplayed()) {
			Reporting.test.pass("User need to Login to execute the API");
		} else {
			Reporting.test.fail("Login Page is displayed");

		}
	}
}