package com.luminor.pages;

import org.openqa.selenium.By;
import org.testng.Assert;

import com.luminor.Base.BaseTest;
import com.luminor.operations.PerformOperations;
import com.luminor.reports.Reporting;

/**
 * @author Bhoomika Watane
 * 
 *
 */
public class DevPortalAPIExplorerPage extends BaseTest {
	/* TPP Registration */
	private static By apiExplorerLnk = By.cssSelector("a[href='#/api-explorer']");
	private static By apiExplorerTxtToVerify = By.xpath("//h2[text()='API Explorer']");

	private static By xRequestID = By.xpath("//*[@id='X-Request-ID']");
	private static By tryItOutButton = By.xpath("//*[text()='Try it out']");
	private static By clientId = By.xpath("//*[text()='\"clientId\"']//following-sibling::span[@class='token string']");
	private static By status = By.xpath("//*[text()='Created']");
	private static By statusSuccess201 = By.xpath("//*[contains(@class,'success')]");
	private static By textAreaBodyParam = By.xpath("//textarea[@class='ace_text-input']");
	/* Get application Status */

	private static By clientIdtext = By.xpath("//*[@id='clientId']");
	private static By verifyActiveStatus = By
			.xpath("//*[text()='\"status\"']//following-sibling::span[@class='token string']");
	private static By statusSuccess200 = By.xpath("//*[text()='OK']");

	private static By verifyResponseData = By.xpath("//div[@class='Code__code-source___QLclz']");

	private static By formMissingValueButton = By.xpath("//*[text()='Form is missing values']");

	/* User Login Page */
	// private static By loginPageLnk = By.xpath("//h2[text()='Login page']");
	private static By openUserLoginPageLnk = By.xpath("//div[contains(text(),'selected language')]");
	private static By bankCountryButton = By.id("bank_country");
	private static String listOfBankCountries = "//ul[@aria-labelledby='bank_country-label']/li";
	private static By languageSelectButton = By.id("locale");
	private static String listOfLanguages = "//ul[@aria-labelledby='locale-label']/li";
	private static By languageListOnLuminorPage = By.id("lang-select");
	private static By loginButtonOnLuminorPage = By.id("idToken6_0");
	private static By inputBoxOfUserOnLuminorPage = By.id("idToken2");
	private static By confirmationMsgTxtOnLuminorPage = By.id("callback_1");
	private static By confirmButtonOnLuminorPage = By.id("idToken3_0");
	private static By logginSuccessfullyMsgTxtOnLuminorPage = By
			.xpath("//h3[text()='You have logged in successfully']");
	private static By authorizationCodeOnLuminorPage = By.xpath("//span[@class='token plain']");
	private static By accesstokenLnkOnLuminorPage = By.cssSelector("a[href='#/api-explorer/oauth2/getAccessToken']");

	/* Tokens and Customers */
	private static By LoginSymbol = By.xpath("//div[contains(@class,'Avatar__authorized')]");
	private static By tokenLnk = By.cssSelector("a[href='#/tokens']");
	private static By customerButton = By.id("selectCustomer");
	private static String customerList = "//li[@data-value]";
	private static String accounttbl = "//table[@id='scrollable-table-element']//tr/td[1]";
	private static String currencytbl = "//table[@id='scrollable-table-element']//tr/td[2]";
	private static By clientIdtoken = By.id("client_id");
	private static By authorizationText = By.id("Authorization");
	PerformOperations common = new PerformOperations();

	public void ClickOnapiExplorerLnk() {
		common.clickOn(apiExplorerLnk, "API Explorer");
	}

	public boolean verifyApiExplorerTxt() {
		if (common.waitForvisible(apiExplorerTxtToVerify)) {
			String apiExplorerText = driver.findElement(apiExplorerTxtToVerify).getText();
			Assert.assertEquals(apiExplorerText, "API Explorer");
			return true;
		} else
			return false;
	}

	public boolean verifyxRequestID() {
		// common.clickOn(signUpToTryOut, "signUP to try Out");
		if (common.waitForvisible(xRequestID)) {
			String verifyxRequestID = driver.findElement(xRequestID).getText();
			System.out.println(verifyxRequestID);
			if (verifyxRequestID != null) {
				System.out.println(verifyxRequestID);
				Reporting.test.pass("Request ID is: " + verifyxRequestID);
			}
			// Assert.assertEquals(xRequestID, "");
			return true;
		} else
			return false;
	}

	public void ClickOnTryItOut() {
		common.clickOn(tryItOutButton, "try It Out button");
	}

	public boolean verifystatus() {
		// common.clickOn(signUpToTryOut, "signUP to try Out");
		if (common.waitForvisible(status)) {
			String statusSuccess = driver.findElement(status).getText();
			String status201 = driver.findElement(statusSuccess201).getText();
			System.out.println(statusSuccess);
			System.out.println(status201);
			if ((statusSuccess.equals("Created")) || (status201.equals("201"))) {
				System.out.println(statusSuccess);
				System.out.println(status201);
				Reporting.test.pass("Response is: " + status201 + " and Status is: " + statusSuccess);
			}
			// Assert.assertEquals(xRequestID, "");
			return true;
		} else
			return false;
	}

	public boolean verifyClientID() {
		// common.clickOn(signUpToTryOut, "signUP to try Out");
		if (common.waitForvisible(clientId)) {
			String verifyClientID = driver.findElement(clientId).getText();
			System.out.println(verifyClientID);
			if (verifyClientID != null) {
				System.out.println(verifyClientID);
				Reporting.test.pass(verifyClientID + " Client ID is displayed");
			}
			// Assert.assertEquals(xRequestID, "");
			return true;
		} else
			return false;
	}

	public void verifyclientIdtext() {
		// common.clickOn(signUpToTryOut, "signUP to try Out");
		String verifyClientID = "";
		if (common.waitForvisible(clientIdtext)) {
			verifyClientID = driver.findElement(clientIdtext).getText();
			System.out.println(verifyClientID);
			if (verifyClientID != null) {
				System.out.println(verifyClientID);
				Reporting.test.pass(" Client ID is : " + verifyClientID);

			}
			// Assert.assertEquals(xRequestID, "");

			else
				Reporting.test.fail(" Client ID is : " + verifyClientID);

		}

	}

	public boolean verifyActiveStatus() {
		// common.clickOn(signUpToTryOut, "signUP to try Out");
		String activeStatus = "";
		String status200 = "";
		if (common.waitForvisible(statusSuccess200)) {
			activeStatus = driver.findElement(verifyActiveStatus).getText();
			status200 = driver.findElement(statusSuccess200).getText();
			System.out.println(verifyActiveStatus);
			System.out.println(status200);
			if ((activeStatus.contains("ACTIVE")) || (status200.contains("OK"))) {
				System.out.println(activeStatus);
				System.out.println(status200);
				Reporting.test.pass("Response is: " + status200 + " and Status is: " + activeStatus);
				Assert.assertTrue(true, activeStatus);
			}
			// Assert.assertEquals(xRequestID, "");
			return true;
		} else
			Reporting.test.pass("Response is: " + status200 + " and Status is: " + activeStatus);
		return false;
	}

	public boolean verifyTppResponseDataofUpdate() {
		String verifyUpdatedataOfBody = "";
		String verifyUpdateData = "";

		if (common.waitForvisible(verifyResponseData)) {
			verifyUpdatedataOfBody = driver.findElement(By.xpath("//div[@class='ace_content']")).getText();
			verifyUpdateData = driver.findElement(verifyResponseData).getText();
			System.out.println(verifyUpdateData);
			System.out.println(verifyUpdatedataOfBody);
			if (verifyUpdateData != null) {
				Assert.assertTrue(true);
				Reporting.test.pass("Data from Body: " + "<br>" + verifyUpdatedataOfBody + "<br>"
						+ "Data From Response: " + "<br>" + verifyUpdateData);

			}
			// Assert.assertEquals(xRequestID, "");
			return true;
		} else
			Assert.assertTrue(false);
		Reporting.test.fail("Data from Body: " + "<br>" + verifyUpdatedataOfBody + "<br>" + "Data From Response: "
				+ "<br>" + verifyUpdateData);
		return false;
	}

	public void clickOnOpenUserLoginPageLnk() {
		common.clickOn(openUserLoginPageLnk, "Open User Login Page");
	}

	public void clickOnbankCountryButton() {
		common.clickOn(bankCountryButton, "Bank Country");
	}

	public void selectFromlistOfBankCountries(String selectCountry) {
		// List<WebElement>
		// selectBankcountries=driver.findElements(listOfBankCountries);
		common.selectElementFromList(listOfBankCountries, "Bank Country", selectCountry);
	}

	public void clicklanguageSelectButton() {
		common.clickOn(languageSelectButton, "Language Select(locale STRING)");
	}

	public void selectFromlistOfLanguages(String selectLanguage) {
		// List<WebElement>
		// selectLanguages=driver.findElements(By.xpath(listOfBankCountries));
		common.selectElementFromList(listOfLanguages, "Language Selection", selectLanguage);
	}

	public void getValueOflanguageListOnLuminorPage(String selectLanguage) {
		String languageSelected = common.getValueFromList(languageListOnLuminorPage);
		if (languageSelected.equalsIgnoreCase(selectLanguage)) {
			Reporting.test.pass("selected language on Luminor Page is:" + languageSelected);
			Assert.assertEquals(languageSelected, selectLanguage);
		} else
			Reporting.test.fail("Selected language is not correct");
	}

	public void enterinputBoxOfUserOnLuminorPage(String username) {
		common.setText(inputBoxOfUserOnLuminorPage, "Enter User Name", username);
	}

	public void clickOnloginButtonOnLuminorPage() {
		common.clickOn(loginButtonOnLuminorPage, "Login button of Luminor Page");

	}

	public void visibleFormMissingValueButton() {
		if (common.waitForvisible(formMissingValueButton)) {
			Reporting.test.pass("Form Missing Value button is displayed");
		} else {
			Reporting.test.fail("Form Missing Value button is not displayed.");
		}
	}

	public void getconfirmationMsgTxtOnLuminorPage() {
		common.getText(confirmationMsgTxtOnLuminorPage, "Confirmation Message");
	}

	public void clickOnConfirmButtonOnLuminorPage() {
		common.clickOn(confirmButtonOnLuminorPage, "Confirm button of Luminor Page");
	}

	public void getAuthorizationCodeOnLuminorPage() {
		String Authorizationtext = common.getText(authorizationCodeOnLuminorPage, "Authorization Code");
		if (Authorizationtext != null)
			Reporting.test.pass("Authorization code is:" + Authorizationtext);
		else
			Reporting.test.fail("Authorizaton code is not displayed");
	}

	public void clickOnaccesstokenLnkOnLuminorPage() {
		common.clickOn(accesstokenLnkOnLuminorPage, "Access token");
	}

	public boolean verifyAccessTokenData() {

		if (common.waitForvisible(verifyResponseData)) {

			String verifyUpdateData = driver.findElement(verifyResponseData).getText();
			System.out.println(verifyUpdateData);

			if (verifyUpdateData != null) {
				Assert.assertTrue(true);
				Reporting.test.pass("Data From Response: " + "<br>" + verifyUpdateData);

			}

			return true;
		} else
			return false;
	}

	public void clickOnLoginSymbol() {
		common.clickOn(LoginSymbol, "Login Symbol");
	}

	public void clickOnTokens() {
		common.clickOn(tokenLnk, "Tokens");
	}

	public void clickOncustomerButton() {
		common.clickOn(customerButton, "Customer list");
	}

	public void getCustomerFromTheList(String username) {
		int listno = getDriver().findElements(By.xpath(customerList)).size();
		if (listno > 0) {
			getDriver().findElement(By.xpath("//li[@data-value='" + username + "']")).click();
			Reporting.test.pass(username + "Customer is selected");
		} else {
			Reporting.test.fail("customer is not selected");
		}
	}

	public void getAccountValue() {

		String AccountNo = "";
		if (common.waitForvisible(By.xpath(accounttbl))) {
			int accountno = getDriver().findElements(By.xpath(accounttbl)).size();
			if (accountno > 0) {
				for (int i = 0; i < accountno; i++) {
					AccountNo = getDriver().findElements(By.xpath(accounttbl)).get(i).getText();
					System.out.println(AccountNo);

					Reporting.test.pass(AccountNo + " Account no. are present for selected customer");
				}
			} else {
				Reporting.test.fail("Account no not present");
				Assert.assertTrue(false);
			}
		}

	}

	public boolean verifyAccountList() {

		String verifyUpdateData;
		if (common.waitForvisible(verifyResponseData)) {

			verifyUpdateData = driver.findElement(verifyResponseData).getText();
			System.out.println(verifyUpdateData);

			if (verifyUpdateData != null) {
				Assert.assertTrue(true);
				Reporting.test.pass("Available Accounts List: " + "<br>" + verifyUpdateData);

			}
			return true;
		} else
			return false;
	}

	public boolean verifyAccessTokenDataOfError() {

		if (common.waitForvisible(verifyResponseData)) {

			String verifyUpdateData = driver.findElement(verifyResponseData).getText();
			System.out.println(verifyUpdateData);

			if (verifyUpdateData.contains("error")) {
				Assert.assertTrue(true);
				Reporting.test.pass("Data From Response: " + "<br>" + verifyUpdateData + "<br>"
						+ "kindly login to get the access token");

			}

			return true;
		} else
			return false;
	}

	public void setAuthorizationText() {
		// driver.findElement(authorizationText).click();
		common.waitForSync(SMALL_WAIT);
		driver.findElement(authorizationText).sendKeys("1234");
		Reporting.test.pass("Text entered successfully in the Authorization tokens: 1234");
	}

	public void newTPPRegistation(String linkName) {
		common.waitForSync(SMALL_WAIT);
		common.clickOnExploreSymbol();
		ClickOnapiExplorerLnk();
		verifyApiExplorerTxt();
		common.clickOnUsingTxt(linkName);
		common.clickOnUsingTxt("Registers new TPP application");
		verifyxRequestID();
		ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		verifystatus();
		verifyClientID();

	}

	public void getTPPApplicationStatus(String linkName) {
		common.waitForSync(SMALL_WAIT);
		common.clickOnExploreSymbol();
		ClickOnapiExplorerLnk();
		verifyApiExplorerTxt();
		common.clickOnUsingTxt(linkName);
		common.clickOnUsingTxt("Get TPP application status");
		ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		verifyclientIdtext();
		verifyActiveStatus();

	}

	public void updateTPPApplication(String linkName) {
		common.waitForSync(SMALL_WAIT);
		common.clickOnExploreSymbol();
		ClickOnapiExplorerLnk();
		verifyApiExplorerTxt();
		common.clickOnUsingTxt(linkName);
		common.clickOnUsingTxt("Update TPP application");
		ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		verifyclientIdtext();
		verifyTppResponseDataofUpdate();

	}

	public void userLoginPage(String language, String username, String country) {
		common.waitForSync(SMALL_WAIT);
		common.clickOnExploreSymbol();
		ClickOnapiExplorerLnk();
		verifyApiExplorerTxt();
		common.clickOnUsingTxt("Login page");
		clickOnOpenUserLoginPageLnk();
		verifyclientIdtext();
		clickOnbankCountryButton();
		selectFromlistOfBankCountries(country);
		clicklanguageSelectButton();
		selectFromlistOfLanguages(language);
		ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		getValueOflanguageListOnLuminorPage(language);
		common.waitForSync(SMALL_WAIT);
		enterinputBoxOfUserOnLuminorPage(username);
		clickOnloginButtonOnLuminorPage();
		getconfirmationMsgTxtOnLuminorPage();
		clickOnConfirmButtonOnLuminorPage();
		common.waitForSync(SMALL_WAIT);
		getAuthorizationCodeOnLuminorPage();
		clickOnaccesstokenLnkOnLuminorPage();
		ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		verifyAccessTokenData();

	}

	public void getListOfAvailableAccounts(String username) {
		clickOnLoginSymbol();
		clickOnTokens();
		clickOncustomerButton();
		getCustomerFromTheList(username);
		common.waitForSync(SMALL_WAIT);
		getAccountValue();
		common.waitForSync(SMALL_WAIT);
		common.clickOnExploreSymbol();
		ClickOnapiExplorerLnk();
		verifyApiExplorerTxt();
		common.clickOnUsingTxt("List of available accounts");
		common.clickOnUsingTxt("Get list of available accounts");
		ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		verifyAccountList();
	}

	public void tppRegistrationBlankBody(String linkName, String linkname2) {

		common.waitForSync(SMALL_WAIT);
		common.clickOnExploreSymbol();
		ClickOnapiExplorerLnk();
		verifyApiExplorerTxt();
		common.clickOnUsingTxt(linkName);
		common.clickOnUsingTxt(linkname2);
		verifyxRequestID();
		common.blankBodyParam(textAreaBodyParam);
		ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		common.verifyErrorBodyResponse();
	}

	public void getTPPApplicationMissingclientId(String linkName, String linkname2) {

		String verifyClientID = "";
		common.waitForSync(SMALL_WAIT);
		common.clickOnExploreSymbol();
		ClickOnapiExplorerLnk();
		verifyApiExplorerTxt();
		common.clickOnUsingTxt(linkName);
		common.clickOnUsingTxt(linkname2);
		common.clickOn(clientIdtext, "Client ID");
		common.blankBodyParam(clientIdtext);
		// ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		visibleFormMissingValueButton();
		verifyClientID = driver.findElement(clientIdtext).getText();
		System.out.println(verifyClientID);
		if (verifyClientID != "") {
			System.out.println(verifyClientID);
			Reporting.test.fail(" Client ID is : " + verifyClientID);
			Assert.assertTrue(false);

		} else {
			Reporting.test.pass(" Client ID is blank, cannot proceed.");
		}
	}

	public void getAccessTokenwithoutLoginScenario(String linkName, String linkname2) {

		common.waitForSync(SMALL_WAIT);
		common.clickOnExploreSymbol();
		ClickOnapiExplorerLnk();
		verifyApiExplorerTxt();
		common.clickOnUsingTxt(linkName);
		common.clickOnUsingTxt(linkname2);
		ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		verifyAccessTokenDataOfError();
	}

	public void getTPPApplicationMissingClientIdForTokens(String linkName, String linkname2) {

		String verifyClientID = "";
		common.waitForSync(SMALL_WAIT);
		common.clickOnExploreSymbol();
		ClickOnapiExplorerLnk();
		verifyApiExplorerTxt();
		common.clickOnUsingTxt(linkName);
		common.clickOnUsingTxt(linkname2);
		common.clickOn(clientIdtoken, "Client ID");
		common.blankBodyParam(clientIdtoken);
		// ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		visibleFormMissingValueButton();
		verifyClientID = driver.findElement(clientIdtoken).getText();
		System.out.println(verifyClientID);
		if (verifyClientID != "") {
			System.out.println(verifyClientID);
			Reporting.test.fail(" Client ID is : " + verifyClientID);
			Assert.assertTrue(false);

		} else {
			Reporting.test.pass(" Client ID is blank, cannot proceed.");
		}
	}

	public void getListOfAvailableAccountsWithWrongTokens(String linkname1, String linkname2, String username) {
		clickOnLoginSymbol();
		clickOnTokens();
		clickOncustomerButton();
		getCustomerFromTheList(username);
		common.waitForSync(SMALL_WAIT);
		getAccountValue();
		common.waitForSync(SMALL_WAIT);
		common.clickOnExploreSymbol();
		ClickOnapiExplorerLnk();
		verifyApiExplorerTxt();
		common.clickOnUsingTxt(linkname1);
		common.clickOnUsingTxt(linkname2);
		setAuthorizationText();
		ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		verifyAccessTokenDataOfError();
	}

}