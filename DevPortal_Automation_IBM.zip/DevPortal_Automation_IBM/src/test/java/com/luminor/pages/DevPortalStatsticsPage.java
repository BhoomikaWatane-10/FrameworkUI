package com.luminor.pages;

import org.openqa.selenium.By;
import org.testng.Assert;

import com.luminor.Base.BaseTest;
import com.luminor.operations.PerformOperations;
import com.luminor.reports.Reporting;

public class DevPortalStatsticsPage extends BaseTest {

	private static By selectCountryCode = By.id("selectCountryCode");
	private static String countryCodeList="//ul[@aria-labelledby='selectCountryCode-label']/li";
	private static By selectReportId = By.id("selectReportId");
	private static String reportIdList="//ul[@aria-labelledby='selectReportId-label']/li";
	private static By downloadButton = By.xpath("//*[text()='Download']");
	private static By statisticsLnk = By.xpath("//*[text()='Statistics']");
	private static By verifyText = By.xpath("//*[text()='Availability and Performance']");
	PerformOperations common = new PerformOperations();
	
	public void DownloadReport(String country,String reportId) {
		common.waitForSync(SMALL_WAIT);
		common.clickOnExploreSymbol();
		common.waitForSync(SMALL_WAIT);
		common.clickOn(statisticsLnk, "Statistics");
		common.waitForSync(SMALL_WAIT);
		if(common.waitForvisible(verifyText)){
			Reporting.test.pass("Statistics page is displayed");
		}
		else {
			Reporting.test.fail("Statistics page is not displayed");
			Assert.assertTrue(false);
		}
	common.clickOn(selectCountryCode, "Click on country code");
	common.selectElementFromList(countryCodeList, "Country Code",country);
	common.clickOn(selectReportId, "Click on Select Report");
	common.selectElementFromList(reportIdList, "Report Id", reportId);
	common.clickOn(downloadButton, "Download");
	}
	
	
}
