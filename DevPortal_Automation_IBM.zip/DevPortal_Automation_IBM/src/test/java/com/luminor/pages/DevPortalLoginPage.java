package com.luminor.pages;

import org.openqa.selenium.By;
import org.testng.Assert;

import com.luminor.Base.BaseTest;
import com.luminor.operations.PerformOperations;
import com.luminor.reports.Reporting;

public class DevPortalLoginPage extends BaseTest {

	private static By LogInButton = By.xpath("//button[text()='LOG IN']");
	private static By UserName = By.id("inputUserName");
	private static By Password = By.id("inputPassword");
	private static By LogInButtonUser = By.xpath("//button[@type='submit']");

	
	private static By lnkHowToAPI = By.xpath("//a[text()='How to APIs']");
	private static By WelcomeText = By.xpath("//*[text()='Welcome to']");
	private static By LogOutButton = By.xpath("//button[text()='LOGOUT']");
	
	Reporting report = new Reporting();
	PerformOperations common = new PerformOperations();

	
	public void clickOnLoginButton() {
		common.clickOn(LogInButton, "Login Button");
		Assert.assertTrue(true, "Login Button clicked");
		
	}

	public void enterUserName(String username) {
		common.setText(UserName, "User Name", username);
		
	}

	public void enterPassword(String password) {
		common.setText(Password, "Password", password);
		

	}

	public void clickOnLogin() {
		common.clickOn(LogInButtonUser, "Credentials Login Button");
		

	}

	public void clickOnLogout() {
		common.clickOn(LogOutButton, "Logout");
		

	}

	
	public boolean verifyWelcomeText() {
		if (common.waitForvisible(WelcomeText)) {
			String welcomeText = driver.findElement(WelcomeText).getText();
			System.out.println(welcomeText);
			common.verifyElementAvailableOnScreen(WelcomeText, "Welcome to");
			
			return true;
		} else {
			return false;
		}

	}

	public void loginToDevPortal(String username, String password) {

		
		clickOnLoginButton();
		enterUserName(username);
		enterPassword(password);
		clickOnLogin();
		verifyWelcomeText();
		}

	public void logoutDevPortal() {
		common.clickOnExploreSymbol();
		clickOnLogout();
	}
}
