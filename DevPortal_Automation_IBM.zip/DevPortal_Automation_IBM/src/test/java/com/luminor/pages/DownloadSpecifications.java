package com.luminor.pages;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;

import org.openqa.selenium.By;

import com.luminor.Base.BaseTest;
import com.luminor.operations.PerformOperations;
import com.luminor.reports.Reporting;

public class DownloadSpecifications extends BaseTest {

	PerformOperations common = new PerformOperations();
	DevPortalAPIExplorerPage apiexplorer = new DevPortalAPIExplorerPage();

	public void downloadSpecifications(String linkname, String type, String path) throws IOException {

		String st = "";
		common.waitForSync(SMALL_WAIT);
		common.clickOnExploreSymbol();
		common.waitForSync(SMALL_WAIT);
		apiexplorer.ClickOnapiExplorerLnk();
		common.clickOnUsingTxt(linkname);
		common.waitForSync(SMALL_WAIT);
		deleteFile(linkname, type, path);
		By downloadSpecificationsLnk = By.xpath("//h2[text()='" + linkname
				+ "']//ancestor::span[@class='Collapsible__trigger is-open']/following-sibling::div//span[text()='Download specification']");
		By FileTypeLnk = By.xpath("//h2[text()='" + linkname
				+ "']//ancestor::span[@class='Collapsible__trigger is-open']/following-sibling::div//li[text()='" + type
				+ "']");

		if (common.waitForvisible(downloadSpecificationsLnk)) {
			common.clickOn(downloadSpecificationsLnk, "Download specification");
			if (common.waitForvisible(FileTypeLnk)) {
				common.clickOn(FileTypeLnk, type);
				common.waitForSync(SMALL_WAIT);
				Reporting.test.pass(type + " file is downloaded for" + linkname);
			}
			String ext = type.toLowerCase();
			File file = new File(path + "\\" + linkname + "." + ext);
			if (file.exists() && !file.isDirectory()) {
				String FileName = file.getName();
				Reporting.test.pass(FileName + " is downloaded.Path is :" + file.toString());
				SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
				Reporting.test.pass("timestamp of the downloaded file: " + sdf.format(file.lastModified()));

				BufferedReader br = new BufferedReader(new FileReader(file));
				Reporting.test.pass("Data From File:  ");
				try {

					while ((st = br.readLine()) != null)
						// st=br.readLine();
						// st=""+st;
						Reporting.test.pass(st);

				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					Reporting.test.fail("File data is not present.");
					e.printStackTrace();
				}

				try {

					br.close();

				} catch (IOException e) {

					e.printStackTrace();
				}
			} else {
				Reporting.test.fail("File is not Exist.");
			}
		}

		else {
			Reporting.test.fail("Download spcification is not present for " + linkname);
		}

	}

	public void deleteFile(String linkname, String type, String path) {
		String ext = type.toLowerCase();
		File file = new File(path + "\\" + linkname + "." + ext);
		if (file.exists() && !file.isDirectory()) {
			file.delete();
		}
	}
}