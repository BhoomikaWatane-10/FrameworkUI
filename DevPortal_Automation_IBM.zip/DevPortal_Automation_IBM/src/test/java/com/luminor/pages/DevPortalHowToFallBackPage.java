package com.luminor.pages;

import org.openqa.selenium.By;
import org.testng.Assert;

import com.luminor.Base.BaseTest;
import com.luminor.operations.PerformOperations;

public class DevPortalHowToFallBackPage extends BaseTest {

	public static By fallBackLnk=By.cssSelector("a[href='#/how-to-fallback']");
	public static By fallBackTextVerify=By.xpath("//h2[text()='How to Luminor Fallback']");
	
	PerformOperations common = new PerformOperations();

	public void clickOnHowtoFallBackLnk() {
		common.clickOn(fallBackLnk, "News link");
	}

	public boolean verifyHowtoFallbackTxt() {
		if (common.waitForvisible(fallBackTextVerify)) {
			String welcomeText = driver.findElement(fallBackTextVerify).getText();
			System.out.println(welcomeText);
			 Assert.assertEquals(welcomeText,"How to Luminor Fallback");
			return true;
		} 
		else {
			return false;
		}

	}
	
public void clickOnHowToFallBackTab() {
	
	common.clickOnExploreSymbol();
	clickOnHowtoFallBackLnk();
	verifyHowtoFallbackTxt();
}
}
