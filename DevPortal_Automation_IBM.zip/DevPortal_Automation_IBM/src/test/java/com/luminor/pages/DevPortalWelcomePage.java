package com.luminor.pages;

import org.openqa.selenium.By;

import com.luminor.Base.BaseTest;
import com.luminor.operations.PerformOperations;

public class DevPortalWelcomePage extends BaseTest {

	public static By WelcomeLnk = By.cssSelector("a[href='#/welcome']");
	public static By WelcomeTxtVerify = By.xpath("//*[text()='Welcome to Luminor developer portal']");

	PerformOperations common = new PerformOperations();

	public void clickOnWelcomeLnk() {
		common.clickOn(WelcomeLnk, "Login Button");
	}

	public boolean verifyWelcomeTxt() {
		if (common.waitForvisible(WelcomeTxtVerify)) {
			String welcomeText = driver.findElement(WelcomeTxtVerify).getText();
			System.out.println(welcomeText);
			// Assert.assertTrue(true);
			return true;
		} 
		else {
			return false;
		}

	}
	
public void clickOnWelcomeTab() {
	
	common.clickOnExploreSymbol();
	clickOnWelcomeLnk();
	verifyWelcomeTxt();
}
}