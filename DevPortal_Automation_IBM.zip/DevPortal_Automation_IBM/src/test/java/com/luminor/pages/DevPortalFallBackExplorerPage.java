package com.luminor.pages;

import org.openqa.selenium.By;
import org.testng.Assert;

import com.luminor.Base.BaseTest;
import com.luminor.Base.Calender;
import com.luminor.operations.PerformOperations;
import com.luminor.reports.Reporting;

public class DevPortalFallBackExplorerPage extends BaseTest {

	PerformOperations common = new PerformOperations();
	DevPortalAPIExplorerPage apiexplorer = new DevPortalAPIExplorerPage();
	Calender calender = new Calender();
	private static By customerName = By
			.xpath("//span[text()='\"name\"']//following-sibling::span[@class='ace_string']");
	private static By loginMessage = By
			.xpath("//span[text()='\"message\"']//following-sibling::span[@class='token string']");
	private static By fundsAvailableValue = By
			.xpath("//span[text()='\"fundsAvailable\"']//following-sibling::span[@class='token boolean']");
	private static By accountNoValueInBodyParam = By.xpath("//span[text()='\"account\"']//following-sibling::span[@class='ace_string']");
	private static By ibanValueInBodyParam = By.xpath("//span[text()='\"iban\"']//following-sibling::span[@class='ace_string']");
	private static By txtBodyParam = By.xpath("//textarea[@class='ace_text-input']");
	private static By headerParamInfinishLogin = By.id("async");
	private static By verifyResponseData = By.xpath("//div[@class='Code__code-source___QLclz']");
	private static String listFinishLogin = "//*[@aria-labelledby='async-label']/li";
	private static By success200 = By.xpath("//li[contains(text(),'200')]");
	private static String accounttbl = "//table[@id='scrollable-table-element']//tr/td[1]";
	private static String currencytbl = "//table[@id='scrollable-table-element']//tr/td[2]";
	private static String AccountNoInAccountRequest = "//span[text()='\"account_number\"']//following-sibling::span[@class='token string']";
	private static By payment_id=By.xpath("//span[text()='\"payment_id\"']//following-sibling::span[@class='token string']");
	private static By tryItOutButton = By.xpath("//*[text()='Try it out']");
	private static By accountId = By.id("account");
	private static By fromDate = By.id("fromDate");
	private static By toDate = By.id("toDate");
	private static By paymentIdValue = By.id("payment_id");
	
	
	public void ClickOnTryItOut() {
		common.clickOn(tryItOutButton, "try It Out button");
	}
	
	
	public void setAccountIdTxt(String value) {

		value = value.replaceAll("^\"+|\"+$", "");
		common.setText(accountId, "Account Id", value);
	}

	public void setToDate() {
		common.clearElement(toDate);
		getDriver().findElement(toDate).click();
		common.setText(toDate, "To Date", calender.getCurrentDate());
	}
	
	public void setFromDate() {
		common.clearElement(fromDate);
		getDriver().findElement(fromDate).click();
		common.setText(fromDate, "From Date", calender.getPreviousDate());
	}
	
	public boolean verifyFallBackResponseData() {
	
		String verifyUpdateData = "";
		String successResponse200 = "";
		if (common.waitForvisible(verifyResponseData)) {

			verifyUpdateData = driver.findElement(verifyResponseData).getText();
			successResponse200 = driver.findElement(success200).getText();
			// System.out.println(verifyUpdateData);

			if (verifyUpdateData != null && (successResponse200.equals("200"))) {
				Assert.assertTrue(true);
				Reporting.test.pass("DATA FROM RESPONSE: " + "<br>" + verifyUpdateData);

			}

			return true;
		} else
			Reporting.test.fail("DATA FROM RESPONSE: " + "<br>" + verifyUpdateData);
		return false;
	}

	public void fallbackLoginRequest(String linkname1, String linkname2) {
		
		common.waitForSync(LONG_WAIT);
		common.clickOnExploreSymbol();
		common.waitForSync(SMALL_WAIT);
		common.clickOnUsingTxt(linkname1);
		common.waitForSync(SMALL_WAIT);
		common.clickOnUsingTxt(linkname2);
		common.waitForSync(SMALL_WAIT);
		common.clickOnUsingTxt("Login request");
		common.waitForSync(LONG_WAIT);
		
		  String txtBodyParamValue = driver.findElement(txtBodyParam).getText();
		  
		  if (txtBodyParamValue != null) {
		  Reporting.test.pass("Values in the Body parameter:" + txtBodyParamValue);
		  ClickOnTryItOut(); } else {
		  Reporting.test.pass("Values in the Body parameter is blank"); }
		 

		String textmessage = common.getText(loginMessage, "Login Message");
		if (textmessage.contains("Finish authentication")) {
			Reporting.test.pass("FallBack login is successful");
		} else {
			Reporting.test.fail("FallBack login is not successful");
		}
	}

	public void fallbackfinishLoginRequest(String valuetoSelectForHeaderParam) {
		
		common.navigateToBack();
		common.waitForSync(SMALL_WAIT);
		common.clickOnUsingTxt("Finish Login request");
		common.clickOn(headerParamInfinishLogin, "Header Param");
		common.waitForSync(SMALL_WAIT);
		common.selectElementFromList(listFinishLogin, "Header Param", valuetoSelectForHeaderParam);
		common.waitForSync(SMALL_WAIT);
		ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		verifyFallBackResponseData();
		String textmessage = common.getText(loginMessage, "Finish Login Message");
		if (textmessage.contains("Successful login")) {
			Reporting.test.pass("FallBack login is successful");
		} else {
			Reporting.test.fail("FallBack login is not successful");
		}
	}

	public void fallBackCustomerRequest(String customername) {
		
		common.navigateToBack();
		common.clickOnUsingTxt("Select customer request");
		common.setValueInBodyParam(customername, customerName);
		ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		verifyFallBackResponseData();
		String textmessage = common.getText(loginMessage, "Finish Login Message");
		if (textmessage.contains("Successful selection")) {
			Reporting.test.pass(customername+ " customer selection is successful");
		} else {
			Reporting.test.fail("customer selection is not successful");
		}
		common.navigateToBack();
	}

	public String getAccountNoFromcustomerList() {
		
		String AccountNo = "";
		String currency = "";
		int accountno = getDriver().findElements(By.xpath(accounttbl)).size();
		if (accountno > 0) {
			for (int i = 0; i < accountno; i++) {

				currency = getDriver().findElements(By.xpath(currencytbl)).get(i).getText();
				System.out.println(AccountNo);
				if (currency.equals("EUR")) {
					AccountNo = getDriver().findElements(By.xpath(accounttbl)).get(i).getText();
					Reporting.test.pass(AccountNo + " Account No is copied.");
					break;
				}

			}
		}
		return AccountNo;
	}

	public String selectCustomerFromTokens(String username) {
		
		String AccountNo="";
		apiexplorer.clickOnLoginSymbol();
		apiexplorer.clickOnTokens();
		apiexplorer.clickOncustomerButton();
		apiexplorer.getCustomerFromTheList(username);
		AccountNo = getAccountNoFromcustomerList();
		
		return AccountNo;
	}

	public void fallBackGetAccountsRequest(String linkname1,String linkname3,String username) {
		String AccountNoInTable = selectCustomerFromTokens(username);
		common.waitForSync(LONG_WAIT);
		common.clickOnExploreSymbol();
		common.waitForSync(SMALL_WAIT);
		common.clickOnUsingTxt(linkname1);
		common.waitForSync(SMALL_WAIT);
		//common.clickOnUsingTxt(linkname2);
		//common.waitForSync(SMALL_WAIT);
		common.clickOnUsingTxt(linkname3);
		common.waitForSync(LONG_WAIT);
		//common.clickOnUsingTxt(linkname1);
		common.clickOnUsingTxt("Get accounts request");
		common.waitForSync(LONG_WAIT);
		ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		verifyFallBackResponseData();
		
		 int No= driver.findElements(By.xpath(AccountNoInAccountRequest)).size();
		 for(int i = 1;i<=No;i++) {
			 String specifyAccountNo="//span[text()='\"account_number\"']//following-sibling::span[@class='token string']"+"["+i+"]";
			 System.out.println(specifyAccountNo);
			String accountNo= driver.findElement(By.xpath(specifyAccountNo)).getText();
			accountNo = accountNo.replaceAll("^\"+|\"+$", "");
			if(accountNo.equals(AccountNoInTable)) {
				Reporting.test.pass(accountNo+" :Account no is present and copied");
				break;
			}
			else {
				Reporting.test.fail(accountNo+" :Account no is not present.");
			}
		 }
		 common.navigateToBack();
	}
	
	public void fallBackGetTransactionReqest(String linkname1,String linkname2, String
			username,String fromDateValue,String toDateVaue) {
		String AccountNoValue = selectCustomerFromTokens(username);
		common.waitForSync(SMALL_WAIT);
		common.waitForSync(LONG_WAIT);
		common.clickOnExploreSymbol();
		common.waitForSync(SMALL_WAIT);
		common.clickOnUsingTxt(linkname1);
		common.waitForSync(SMALL_WAIT);
		common.clickOnUsingTxt(linkname2);
		//common.waitForSync(SMALL_WAIT);
		common.clickOnUsingTxt("Get Transactions request");
	  //common.clickOnUsingTxt(linkname); 
		setAccountIdTxt(AccountNoValue);
		setToDate();
		common.waitForSync(SMALL_WAIT);
		setFromDate();
		common.waitForSync(SMALL_WAIT);
		ClickOnTryItOut();
	  verifyFallBackResponseData(); //need to add the code }
	}
	
	public void fallBackinitatePaymentRequest(String linkname1,String linkname2,String username) {
		String AccountNoValue = selectCustomerFromTokens(username);
		common.waitForSync(LONG_WAIT);
		common.clickOnExploreSymbol();
		common.waitForSync(SMALL_WAIT);
		common.clickOnUsingTxt(linkname1);
		common.waitForSync(SMALL_WAIT);
		common.clickOnUsingTxt(linkname2);
		//common.waitForSync(SMALL_WAIT);
		common.clickOnUsingTxt("Initiate payment request");
		common.waitForSync(LONG_WAIT);
		//common.clickOnUsingTxt(linkname1);
		//common.clickOnUsingTxt("Get accounts request");
		//common.clickOnUsingTxt(linkname1);
		//common.clickOnUsingTxt(linkname2);
		common.setValueInBodyParam(AccountNoValue, accountNoValueInBodyParam);
		ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		String textmessage = common.getText(loginMessage, "Document signing Message");
		if (textmessage.contains("Document signing message")) {
			Reporting.test.pass("Response is 200 and Message is :"+textmessage);
		} else {
			Reporting.test.fail("customer selection is not successful");
		}
		common.navigateToBack();
	}
	
	
	public void fallBackFinishPaymentRequest() {
		common.clickOnUsingTxt("Finish payment request");
		//common.setValueInBodyParam(AccountNoValue, accountNoValueInBodyParam);
		ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		String textmessage = common.getText(loginMessage, "Successful payment message");
		if (textmessage.contains("Successful payment")) {
			Reporting.test.pass("Response is 200 and Message is :"+textmessage+"<br>" +"Payment is finished for Account");
		} else {
			Reporting.test.fail("Payment is  not successful");
		}
		
		}
	
	public String fallBackgetPaymentId() {
		String paymentIdValue = common.getText(payment_id, "Payment Id");
		
		//common.navigateToBack();
		return paymentIdValue;
	}
		
	public void fallBackReturnPaymentStatus() {
		String paymentId=fallBackgetPaymentId();
		common.navigateToBack();
		common.clickOnUsingTxt("Returns the payment status");
		common.waitForSync(WAIT_TO_LOAD);
		common.blankBodyParam(paymentIdValue);
		common.waitForSync(WAIT_TO_LOAD);
		paymentId=paymentId.replaceAll("^\"+|\"+$", "");
		common.setText(paymentIdValue, "Payment Id", paymentId);
		ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		verifyFallBackResponseData();
		
		
	}
	public void fallBackfundAvailableRequest(String linkname1,String linkname2,String username) {
		
		String AccountNoValue = selectCustomerFromTokens(username);
		common.waitForSync(LONG_WAIT);
		common.clickOnExploreSymbol();
		common.waitForSync(SMALL_WAIT);
		common.clickOnUsingTxt(linkname1);
		common.waitForSync(SMALL_WAIT);
		common.clickOnUsingTxt(linkname2);
		common.clickOnUsingTxt("Confirm Funds request");
		common.waitForSync(WAIT_TO_LOAD);
		//common.blankBodyParam(paymentIdValue);
		//common.waitForSync(WAIT_TO_LOAD);
		common.setValueInBodyParam(AccountNoValue, ibanValueInBodyParam);
		ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		verifyFallBackResponseData();
		String textmessage = common.getText(fundsAvailableValue, "fundsAvailable");
		if (textmessage.equals("true")) {
			Reporting.test.pass("Response is 200 and funds available :"+textmessage);
		} else {
			Reporting.test.fail("fund is not avialable");
		}
	
		
		
		
	}
	}
	
	

