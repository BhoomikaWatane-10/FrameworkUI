package com.luminor.pages;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.luminor.Base.BaseTest;
import com.luminor.Base.Calender;
import com.luminor.operations.PerformOperations;
import com.luminor.reports.Reporting;

/**
 * @author Bhoomika
 *
 */
public class DevPortalAPIExplorerConsentPage extends BaseTest {

	private static By tryItOutButton = By.xpath("//*[text()='Try it out']");
	private static By verifyResponseData = By.xpath("//div[@class='Code__code-source___QLclz']");
	private static By consentId = By.id("consentId");
	private static By accountId = By.id("accountId");

	/* Get consent authorisations details */

	private static By authenticationMethodId = By
			.xpath("//*[text()='\"authenticationMethodId\"']//following-sibling::span[@class='token string']");

	/* Account Information */

	private static By getAccountswithinUsersConsentLnk = By.xpath("//*[text()=\"Get accounts within user's consent\"]");

	private static By ResourceIdaccountIdTxt = By.id("accountId");

	private static By toDate = By.id("dateTo");
	private static By fromDate = By.id("dateFrom");
	private static By tppRedirectPrefered = By.id("tpp-redirect-preferred");
	private static String tppRedirectPreferedList = "//*[@aria-labelledby='tpp-redirect-preferred-label']/li";
	private static By scaRedirect = By
			.xpath("//*[text()='\"scaRedirect\"']//following-sibling::span[@class='token punctuation']");
	private static By linkTobeValidatePayment = By.xpath(
			"//*[text()='\"scaRedirect\"']//following::*[text()='\"href\"']//following-sibling::span[@class='token string']");
	private static String accounttbl = "//table[@id='scrollable-table-element']//tr/td[1]";
	private static String currencytbl = "//table[@id='scrollable-table-element']//tr/td[2]";
	private static By ibanValue = By.xpath("//span[text()='\"iban\"']//following-sibling::span[@class='ace_string']");

	PerformOperations common = new PerformOperations();
	DevPortalAPIExplorerPage apiexplorer = new DevPortalAPIExplorerPage();
	Calender calender = new Calender();

	public void getConsentIdTxt() {
		common.getText(consentId, "Consent Id");
	}

	public boolean verifyGetConsentDetailsData() {

		if (common.waitForvisible(verifyResponseData)) {

			String verifyUpdateData = driver.findElement(verifyResponseData).getText();
			System.out.println(verifyUpdateData);

			if (verifyUpdateData != null) {
				Assert.assertTrue(true);
				Reporting.test.pass("DATA FROM RESPONSE: " + "<br>" + verifyUpdateData);

			}

			return true;
		} else
			return false;
	}

	public void getScaStatus() {
		String status = common.getValueByXpath("scaStatus", "token string");
		if (status.contains("finalised")) {
			Reporting.test.pass("authorization of Consent is " + status);
			Assert.assertTrue(true);
		} else {
			Reporting.test.fail("authorization of Consent is no successful");
			Assert.assertTrue(false);
		}
	}

	public void getstartedScaStatus() {
		String status = common.getValueByXpath("scaStatus", "token string");
		if (status.contains("started")) {
			Reporting.test.pass("authorization of Consent is " + status);
			Assert.assertTrue(true);
		} else if (status.contains("received")) {
			Reporting.test.pass("authorization of Consent is " + status);
			Assert.assertTrue(true);
		} else if (status.contains("valid")) {
			Reporting.test.pass("authorization of Consent is " + status);
			Assert.assertTrue(true);
		} else {
			Reporting.test.fail("authorization of Consent is not successful");
			Assert.assertTrue(false);
		}
	}

	public void getauthenticationMethodId() {
		common.getText(authenticationMethodId, "Authetication Method Id");
	}

	public boolean verifyAuthorizationDetailsData() {

		if (common.waitForvisible(verifyResponseData)) {

			String verifyUpdateData = driver.findElement(verifyResponseData).getText();
			System.out.println(verifyUpdateData);

			if (verifyUpdateData != null) {
				Assert.assertTrue(true);
				Reporting.test.pass("Data From Response of access token: " + "<br>" + verifyUpdateData);

			}

			return true;
		} else
			return false;
	}

	public void clickOngetAccountswithinUsersConsentLnk() {
		common.clickOn(getAccountswithinUsersConsentLnk, "Accounts within user's consent");
	}

	public void setResourceIdAsAccountIdTxt(String value) {

		value = value.replaceAll("^\"+|\"+$", "");
		common.setText(ResourceIdaccountIdTxt, "Account Id", value);
	}

	public void setToDate() {
		common.clearElement(toDate);
		getDriver().findElement(toDate).click();
		common.setText(toDate, "To Date", calender.getCurrentDate());
	}

	public void setFromDate() {
		common.clearElement(fromDate);
		;
		getDriver().findElement(fromDate).click();
		common.setText(fromDate, "From Date", calender.getPreviousDate());
	}

	public void clickOntppRedirectPreferred() {
		common.clickOn(tppRedirectPrefered, "tpp-redirect-preferred");
	}

	public void getListOfTppRedirectPreferred(String tppRedirectPreferred) {
		common.selectElementFromList(tppRedirectPreferedList, "tpp-Redirect-prefered", tppRedirectPreferred);
	}

	public String getAccountNoFromcustomerList() {
		String AccountNo = "";
		String currency = "";
		int accountno = getDriver().findElements(By.xpath(accounttbl)).size();
		if (accountno > 0) {
			for (int i = 0; i < accountno; i++) {
				common.waitForSync(LONG_WAIT);
				currency = getDriver().findElements(By.xpath(currencytbl)).get(i).getText();
				System.out.println(AccountNo);
				if (currency.equals("EUR")) {
					AccountNo = getDriver().findElements(By.xpath(accounttbl)).get(i).getText();
					Reporting.test.pass(AccountNo + " Account No is copied.");
					break;
				}

			}
		}
		return AccountNo;
	}

	public void setAccountnoInBodyParam(String AccountNo) {
		WebElement e = driver.findElement(ibanValue);
		AccountNo = "\"" + AccountNo + "\"";
		String no = e.getText();

		if (driver.findElement(ibanValue).isDisplayed()) {

			System.out.println(AccountNo);

			WebElement ele_acct = common.getDriver().findElement(By.xpath("//textarea[@class='ace_text-input']"));
			// common.waitForvisible(ele_acct){
			common.waitForSync(SMALL_WAIT);
			ele_acct.sendKeys(Keys.CONTROL + "A");
			common.waitForSync(WAIT_TO_LOAD);
			ele_acct.sendKeys(Keys.CONTROL + "C");
			common.waitForSync(WAIT_TO_LOAD);
			Toolkit toolkit = Toolkit.getDefaultToolkit();
			common.waitForSync(SMALL_WAIT);
			Clipboard clipboard = toolkit.getSystemClipboard();
			common.waitForSync(WAIT_TO_LOAD);
			String result = "";
			try {
				result = (String) clipboard.getData(DataFlavor.stringFlavor);
				common.waitForSync(WAIT_TO_LOAD);
			} catch (UnsupportedFlavorException e1) {

				e1.printStackTrace();
			} catch (IOException e1) {

				e1.printStackTrace();
			}
			common.waitForSync(WAIT_TO_LOAD);
			// write for loop logic to replace text
			String str = result.replace(no, AccountNo);

			ele_acct.sendKeys(str);

		}
	}

	public void createConsent(String tppRedirectPreferred, String username, String LinkName, String valuesToFetch,
			String Type) {
		String link[] = LinkName.split(";");
		String linkToclicked = "";
		String[] ValuetoEnter = valuesToFetch.split(";");
		apiexplorer.clickOnLoginSymbol();
		apiexplorer.clickOnTokens();
		apiexplorer.clickOncustomerButton();
		apiexplorer.getCustomerFromTheList(username);
		String AccountNo = getAccountNoFromcustomerList();
		common.waitForSync(SMALL_WAIT);
		common.clickOnExploreSymbol();
		apiexplorer.ClickOnapiExplorerLnk();
		common.waitForSync(SMALL_WAIT);
		common.clickOnUsingTxt(link[0]);
		common.clickOnUsingTxt(link[1]);
		clickOntppRedirectPreferred();
		common.waitForSync(SMALL_WAIT);
		getListOfTppRedirectPreferred(tppRedirectPreferred);
		common.waitForSync(SMALL_WAIT);
		setAccountnoInBodyParam(AccountNo);

		apiexplorer.ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		if (common.waitForvisible(scaRedirect)) {
			if (driver.findElement(linkTobeValidatePayment).isDisplayed()) {
				linkToclicked = common.getText(linkTobeValidatePayment, "scadirect Link");

				common.openLinkInNewTab(linkToclicked);
				common.waitForSync(SMALL_WAIT);
				// common.clickOnUsingTxt("Confirm");
				common.clickOnUsingTxt("Sign with Smart-ID");
				common.waitForSync(10000);
				common.clickOnExploreSymbol();
				apiexplorer.ClickOnapiExplorerLnk();
				common.clickOnUsingTxt(link[0]);
			}
		} else {
			apiexplorer.verifyxRequestID();
			common.getValueByXpath(ValuetoEnter[0], Type);
			common.getValueByXpath(ValuetoEnter[1], Type);
			common.navigateToBack();

		}

	}

	public void getConsentDetails(String valuesToFetch, String Type) {
		String[] ValuetoEnter = valuesToFetch.split(";");
		common.clickOnUsingTxt("Get consent details");
		apiexplorer.ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		common.getValueByXpath(ValuetoEnter[0], Type);
		common.getValueByXpath(ValuetoEnter[2], Type);
		verifyGetConsentDetailsData();
		common.navigateToBack();
	}

	public void geConsentStatus(String valuesToFetch, String Type) {
		String[] ValuetoEnter = valuesToFetch.split(";");
		common.clickOnUsingTxt("Get consent status");
		common.waitForSync(SMALL_WAIT);
		apiexplorer.ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		common.getValueByXpath(ValuetoEnter[1], Type);
		common.navigateToBack();
	}

	public void initiateconsentAuthorization() {
		// consent authorization
		common.clickOnUsingTxt("Consent authorisation");
		common.waitForSync(SMALL_WAIT);
		common.clickOnUsingTxt("Initiate consent authorisation");
		common.waitForSync(SMALL_WAIT);
		apiexplorer.ClickOnTryItOut();
		common.navigateToBack();
	}

	public void getconsentAuthorization(String valuesToFetch, String Type) {
		String[] ValuetoEnter = valuesToFetch.split(";");
		common.clickOnUsingTxt("Get consent authorisations");
		common.waitForSync(SMALL_WAIT);
		apiexplorer.ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		common.getValueByXpath(ValuetoEnter[3], Type);
		// getScaStatus();
		common.navigateToBack();
	}

	public void getconsentAuthorizationDetails(String valuesToFetch, String Type) {
		String[] ValuetoEnter = valuesToFetch.split(";");
		common.clickOnUsingTxt("Get consent authorisation details");
		common.waitForSync(SMALL_WAIT);
		apiexplorer.ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		getstartedScaStatus();
		// getauthenticationMethodId();
		common.getValueByXpath(ValuetoEnter[4], Type);
		common.getValueByXpath(ValuetoEnter[5], Type);
		verifyAuthorizationDetailsData();
		common.navigateToBack();
	}

	public void updateConsentAuthorizationDetails(String valuesToFetch, String Type) {
		String[] ValuetoEnter = valuesToFetch.split(";");
		common.clickOnUsingTxt("Update consent authorisation details");
		apiexplorer.ClickOnTryItOut();
		common.getValueByXpath(ValuetoEnter[6], Type);
		getstartedScaStatus();
		common.navigateToBack();
	}

	public void getConsentAuthorizationStatus() {
		common.clickOnUsingTxt("Get consent authorisation status");
		common.waitForSync(SMALL_WAIT);
		apiexplorer.ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		driver.findElement(tryItOutButton).click();
		common.waitForSync(SMALL_WAIT);
		driver.findElement(tryItOutButton).click();
		getScaStatus();
		common.navigateToBack();
	}

	public void AcoountInformation(String valuesToFetch, String Type, String noType, String boolType) {
		String[] ValuetoEnter = valuesToFetch.split(";");
		common.clickOnUsingTxt("Account information");
		clickOngetAccountswithinUsersConsentLnk(); // 's using so create seperate method
		common.waitForSync(SMALL_WAIT);
		apiexplorer.ClickOnTryItOut();
		common.waitForSync(LONG_WAIT);
		String value = common.getValueByXpath(ValuetoEnter[9], Type);
		common.getValueByXpath(ValuetoEnter[2], Type);
		common.getValueByXpath(ValuetoEnter[7], Type);
		common.getValueByXpath(ValuetoEnter[9], noType);
		common.navigateToBack();
		common.clickOnUsingTxt("Get account details");
		setResourceIdAsAccountIdTxt(value);

		apiexplorer.ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		verifyGetConsentDetailsData();
		common.getValueByXpath(ValuetoEnter[9], Type);// resourceid
		common.getValueByXpath(ValuetoEnter[2], Type);// iban
		common.getValueByXpath(ValuetoEnter[7], Type);// currency
		common.getValueByXpath(ValuetoEnter[4], Type);// name
		common.getValueByXpath(ValuetoEnter[10], Type);// product
		common.getValueByXpath(ValuetoEnter[11], Type);// balncetype
		// common.getValueByXpath("creditLimitIncluded");
		common.navigateToBack();
		common.clickOnUsingTxt("Get account balances");
		common.waitForSync(SMALL_WAIT);
		setResourceIdAsAccountIdTxt(value);
		apiexplorer.ClickOnTryItOut();
		common.getValueByXpath(ValuetoEnter[7], Type);// iban
		common.getValueByXpath(ValuetoEnter[7], Type);// currency
		common.getValueByXpath(ValuetoEnter[8], noType);// amount
		common.getValueByXpath(ValuetoEnter[12], boolType);// creditlimitincluded
		common.navigateToBack();
		common.clickOnUsingTxt("Get account transactions");
		setResourceIdAsAccountIdTxt(value);
		setToDate();
		setFromDate();
		common.waitForSync(SMALL_WAIT);
		// common.clickOnUsingTxt("Try it out");
		apiexplorer.ClickOnTryItOut();
		common.waitForSync(LONG_WAIT);
		if (common.getValueByXpath(ValuetoEnter[13], Type).equals("\"NOT PROVIDED\"")) {
			System.out.println(common.getValueByXpath(ValuetoEnter[13], Type));// endtoendid
			common.waitForSync(LONG_WAIT);
			apiexplorer.ClickOnTryItOut();
			common.waitForSync(LONG_WAIT);
		} else {
			Reporting.test.fail("Response Data is not captured");
			Assert.assertTrue(false);
		}
		common.getValueByXpath(ValuetoEnter[2], Type);// iban
		common.getValueByXpath(ValuetoEnter[7], Type);// currency
		// common.getValueByXpath(ValuetoEnter[13],Type);//transctionid
		common.getValueByXpath(ValuetoEnter[13], Type);// endtoendid
		common.getValueByXpath(ValuetoEnter[8], noType);// amount
		common.getValueByXpath(ValuetoEnter[14], Type);// debatorname
		common.getValueByXpath(ValuetoEnter[15], Type);// debatoraccount
		common.getValueByXpath(ValuetoEnter[16], Type);// bookingdate
		common.getValueByXpath(ValuetoEnter[17], Type);// valuedate
		common.getValueByXpath(ValuetoEnter[18], Type);// currency
		common.getValueByXpath(ValuetoEnter[19], Type);// banktransactioncode
		verifyGetConsentDetailsData();
		common.navigateToBack();
	}

	public void confirmFundsAvailabilityOnAccount(String valuesToFetch, String Type, String noType, String boolType) {
		String[] ValuetoEnter = valuesToFetch.split(";");
		common.clickOnUsingTxt("Funds Confirmation");
		common.waitForSync(SMALL_WAIT);
		common.clickOnUsingTxt("Confirm funds availability on account");
		common.getValueByXpath(ValuetoEnter[0], Type);
		common.getValueByXpath(ValuetoEnter[1], Type);
		String amount = common.getValueByXpath("amount", "ace_constant ace_numeric");
		double amt = Double.parseDouble(amount);
		apiexplorer.ClickOnTryItOut();
		String value = common.getValueByXpath("fundsAvailable", "token boolean");

		if (amt > 0) {

			Reporting.test.pass("funds Available: " + value);
		} else {

			Reporting.test.fail("Funds Available: " + value);
			Assert.assertTrue(false);
		}

	}

	public void CreateConsentsWithWrongTokens(String linkname1, String linkname2, String username) {

		common.waitForSync(SMALL_WAIT);
		common.clickOnExploreSymbol();
		apiexplorer.ClickOnapiExplorerLnk();
		apiexplorer.verifyApiExplorerTxt();
		common.clickOnUsingTxt(linkname1);
		common.clickOnUsingTxt(linkname2);
		apiexplorer.setAuthorizationText();
		apiexplorer.ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		apiexplorer.verifyAccessTokenDataOfError();
	}

	public void verifyBlankAccountId(String linkName, String linkname2) {

		String verifyAccountID = "";
		common.waitForSync(SMALL_WAIT);
		common.clickOnExploreSymbol();
		apiexplorer.ClickOnapiExplorerLnk();
		apiexplorer.verifyApiExplorerTxt();
		common.clickOnUsingTxt(linkName);
		common.clickOnUsingTxt(linkname2);
		common.waitForSync(SMALL_WAIT);
		apiexplorer.visibleFormMissingValueButton();
		verifyAccountID = driver.findElement(accountId).getText();
		if (verifyAccountID != "") {
			System.out.println(verifyAccountID);
			Reporting.test.fail(" Account ID is : " + verifyAccountID);
			Assert.assertTrue(false);

		} else {
			Reporting.test.pass(" Account ID is blank, cannot proceed.");
		}
	}
}
