package com.luminor.pages;

import org.openqa.selenium.By;
import org.testng.Assert;

import com.luminor.Base.BaseTest;
import com.luminor.operations.PerformOperations;
import com.luminor.reports.Reporting;

public class DevPortalAPIExplorerPaymentPage extends BaseTest {

	private static By tppRedirectPrefered = By.id("tpp-redirect-preferred");
	private static String tppRedirectPreferedList = "//*[@aria-labelledby='tpp-redirect-preferred-label']/li";
	private static By scaRedirect = By
			.xpath("//*[text()='\"scaRedirect\"']//following-sibling::span[@class='token punctuation']");
	private static By linkTobeValidatePayment = By.xpath(
			"//*[text()='\"scaRedirect\"']//following::*[text()='\"href\"']//following-sibling::span[@class='token string']");
	PerformOperations common = new PerformOperations();
	DevPortalAPIExplorerPage apiexplorer = new DevPortalAPIExplorerPage();
	DevPortalAPIExplorerConsentPage consent = new DevPortalAPIExplorerConsentPage();
	private static By paymentId = By.id("paymentId");

	public void clickOntppRedirectPreferred() {
		common.clickOn(tppRedirectPrefered, "tpp-redirect-preferred");
	}

	public void selectListOfTppRedirectPreferred(String tppRedirectPreferred) {
		common.selectElementFromList(tppRedirectPreferedList, "tpp-Redirect-prefered", tppRedirectPreferred);
	}

	public void initatePayment(String tppRedirectPreferred, String linkName, String valuesToFetch, String Type,String username) {
		String link = "";
		String[] ValuetoEnter = valuesToFetch.split(";");
		apiexplorer.clickOnLoginSymbol();
		apiexplorer.clickOnTokens();
		apiexplorer.clickOncustomerButton();
		apiexplorer.getCustomerFromTheList(username);
		String AccountNo = consent.getAccountNoFromcustomerList();
		/*
		 * common.waitForSync(SMALL_WAIT); common.clickOnExploreSymbol();
		 */
		common.waitForSync(SMALL_WAIT);
		common.clickOnExploreSymbol();
		apiexplorer.ClickOnapiExplorerLnk();
		common.waitForSync(SMALL_WAIT);
		common.clickOnUsingTxt(linkName);
		common.clickOnUsingTxt("Initiate payment");
		clickOntppRedirectPreferred();
		selectListOfTppRedirectPreferred(tppRedirectPreferred);
		common.waitForSync(SMALL_WAIT);
		consent.setAccountnoInBodyParam(AccountNo);
		common.waitForSync(SMALL_WAIT);
		apiexplorer.ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		common.getValueByXpath(ValuetoEnter[0], Type);// transactionstatus
		common.getValueByXpath(ValuetoEnter[1], Type);// paymentId
		if (common.waitForvisible(scaRedirect)) {
			if (driver.findElement(linkTobeValidatePayment).isDisplayed()) {
				link = common.getText(linkTobeValidatePayment, "scadirect Link");

				common.openLinkInNewTab(link);
				common.waitForSync(SMALL_WAIT);
				common.clickOnUsingTxt("Confirm");
				common.clickOnUsingTxt("Sign with Smart-ID");
				common.waitForSync(LONG_WAIT);
				common.clickOnExploreSymbol();
				apiexplorer.ClickOnapiExplorerLnk();
				common.waitForSync(LONG_WAIT);
				common.waitForSync(LONG_WAIT);
				common.clickOnUsingTxt("Payment initiation and information");
			}
		} else {
			Reporting.test.pass("TPP redirct UI is selected as :" + tppRedirectPreferred + " payment is done by API");
			common.navigateToBack();
		}
	}

	public void getPaymentStatus(String valuesToFetch, String type) {

		String[] ValuetoEnter = valuesToFetch.split(";");
		common.waitForSync(SMALL_WAIT);
		common.clickOnUsingTxt("Get payment status");
		common.waitForSync(SMALL_WAIT);
		apiexplorer.ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		if (common.getValueByXpath(ValuetoEnter[0], type).contains("ACSC")
				|| common.getValueByXpath(ValuetoEnter[0], type).contains("ACTC"))
			common.getValueByXpath(ValuetoEnter[1], type);
		common.navigateToBack();
	}

	public void getPaymentFee(String valuesToFetch, String type, String noType) {
		String[] ValuetoEnter = valuesToFetch.split(";");
		common.waitForSync(SMALL_WAIT);
		common.clickOnUsingTxt("Get payment fee");
		apiexplorer.ClickOnTryItOut();
		common.getValueByXpath(ValuetoEnter[2], noType);
		common.getValueByXpath(ValuetoEnter[3], type);
		common.navigateToBack();
	}

	public void getinitiatePaymentAuthorization(String valuesToFetch, String type) {
		String[] ValuetoEnter = valuesToFetch.split(";");
		common.waitForSync(SMALL_WAIT);
		common.clickOnUsingTxt("Payment authorisation");
		common.waitForSync(SMALL_WAIT);
		common.clickOnUsingTxt("Initiate payment authorisation");
		common.waitForSync(SMALL_WAIT);
		apiexplorer.ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		common.getValueByXpath(ValuetoEnter[5], type);
		common.getValueByXpath(ValuetoEnter[6], type);
		common.getValueByXpath(ValuetoEnter[7], type);
		common.getValueByXpath(ValuetoEnter[8], type);
		common.navigateToBack();
	}

	public void getPaymentAuthorization(String valuesToFetch, String noType) {
		String[] ValuetoEnter = valuesToFetch.split(";");
		common.waitForSync(SMALL_WAIT);
		common.clickOnUsingTxt("Get payment authorisations");
		common.waitForSync(SMALL_WAIT);

		apiexplorer.ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);

		common.getValueByXpath(ValuetoEnter[9], noType);
		common.navigateToBack();
	}

	public void getPaymentAuthorizationDetail(String valuesToFetch, String type) {
		String[] ValuetoEnter = valuesToFetch.split(";");
		common.clickOnUsingTxt("Get payment authorisation details");
		common.waitForSync(SMALL_WAIT);

		apiexplorer.ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		common.getValueByXpath(ValuetoEnter[5], type);// authorisationId
		common.getValueByXpath(ValuetoEnter[6], type);// scaStatus
		common.getValueByXpath(ValuetoEnter[8], type);// authenticationMethodId
		common.getValueByXpath(ValuetoEnter[10], type);// name
		common.getValueByXpath(ValuetoEnter[11], type);// surname
		common.getValueByXpath(ValuetoEnter[12], type);// signatureSchemaType
		common.getValueByXpath(ValuetoEnter[13], type);// created
		apiexplorer.verifyAccessTokenData();
		common.navigateToBack();
	}

	public void updatePaymentAuthorizationDetail(String valuesToFetch, String type) {
		String[] ValuetoEnter = valuesToFetch.split(";");
		common.clickOnUsingTxt("Update payment authorisation details");
		common.waitForSync(SMALL_WAIT);

		apiexplorer.ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);

		common.getValueByXpath(ValuetoEnter[6], type);
		common.getValueByXpath(ValuetoEnter[14], type);
		common.getValueByXpath(ValuetoEnter[15], type);

		apiexplorer.verifyAccessTokenData();
		common.navigateToBack();
	}

	public void getPaymentAuthorizationStatus() {
		common.clickOnUsingTxt("Get payment authorisation status");

		common.waitForSync(SMALL_WAIT);
		apiexplorer.ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);

		if (common.getValueByXpath("scaStatus", "token string").equals("\"finalised\"")) {
			Reporting.test.pass("Payment is successful");
		} else {
			for (int i = 0; i < 5; i++) {
				apiexplorer.ClickOnTryItOut();
				common.waitForSync(SMALL_WAIT);
				// Reporting.test.fail("Payment is not successful" +
				// common.getValueByXpath("scaStatus", "token string"));
				Assert.assertTrue(true);
			}
		}

	}

	public void missingPaymentId(String linkName, String linkname2) {

		String verifyPaymentID = "";
		common.waitForSync(SMALL_WAIT);
		common.clickOnExploreSymbol();
		apiexplorer.ClickOnapiExplorerLnk();
		apiexplorer.verifyApiExplorerTxt();
		common.clickOnUsingTxt(linkName);
		common.clickOnUsingTxt(linkname2);
		common.clickOn(paymentId, "Payment ID");
		common.blankBodyParam(paymentId);
		// ClickOnTryItOut();
		common.waitForSync(SMALL_WAIT);
		apiexplorer.visibleFormMissingValueButton();
		verifyPaymentID = driver.findElement(paymentId).getText();
		System.out.println(verifyPaymentID);
		if (verifyPaymentID != "") {
			System.out.println(verifyPaymentID);
			Reporting.test.fail(" Client ID is : " + verifyPaymentID);
			Assert.assertTrue(false);

		} else {
			Reporting.test.pass(" Client ID is blank, cannot proceed.");
		}
	}
}
