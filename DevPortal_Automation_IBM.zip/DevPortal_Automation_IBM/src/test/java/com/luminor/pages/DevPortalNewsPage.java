package com.luminor.pages;

import org.openqa.selenium.By;
import org.testng.Assert;

import com.luminor.Base.BaseTest;
import com.luminor.operations.PerformOperations;
import com.luminor.reports.Reporting;

public class DevPortalNewsPage extends BaseTest {

	public static By newsLnk=By.cssSelector("a[href='#/news']");
	public static By newsTextVerify=By.xpath("//*[text()='Luminor Open Banking News']");
	
	PerformOperations common = new PerformOperations();

	public void clickOnNewsLnk() {
		//common.waitForSync(SMALL_WAIT);
		common.clickOn(newsLnk, "News link");
		common.waitForSync(SMALL_WAIT);
	}

	public boolean verifyNewsTxt() {
		String welcomeText;
		if (common.waitForvisible(newsTextVerify)) {
			welcomeText	 = driver.findElement(newsTextVerify).getText();
			System.out.println(welcomeText);
			 Assert.assertEquals(welcomeText,"Luminor Open Banking New");
			 Reporting.test.pass(welcomeText+" Page is displayed");
			return true;
		} 
		else {
			Reporting.test.fail("Luminor Open Banking News Page is not displayed");
			return false;
		}

	}
	
public void clickOnNewsTab() {
	try {
		Thread.sleep(5000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	common.clickOnExploreSymbol();
	clickOnNewsLnk();
	verifyNewsTxt();
	/*
	 * if(verifyNewsTxt()) { Reporting.test.pass("Text verified suscessfully"); }
	 * else { Reporting.test.fail("Text is not matched"); }
	 */
}
}

