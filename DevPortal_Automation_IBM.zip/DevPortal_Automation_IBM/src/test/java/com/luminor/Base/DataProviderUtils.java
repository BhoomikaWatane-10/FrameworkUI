package com.luminor.Base;


import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.DataProvider;





public final class DataProviderUtils {
	
	/*
	 * private static List<Map<String, String>> list=new ArrayList<>();
	 * 
	 * @DataProvider public static Object[] getData(Method m) { String
	 * testname=m.getName(); if(list.isEmpty()) {
	 * list=ExcelUtility.getTestDetails("DATA"); } List<Map<String, String>>
	 * itr_list=new ArrayList<>(); for(int i=0;i<list.size();i++) {
	 * if(list.get(i).get("TC_Name").equalsIgnoreCase(testname)){
	 * itr_list.add(list.get(i)); } } //list.removeAll(itr_list); //&&
	 * list.get(i).get("run").equalsIgnoreCase("yes") return itr_list.toArray(); } }
	 */


@DataProvider
public  static Object[][] TestCaseDataProvider(Method method){
	try {
		//WFCustDataProvider params = method.getAnnotation(WFCustDataProvider.class);
		String excelFileName = System.getProperty("user.dir")+"\\src\\testdata.xlsx";

		String excelSheetName = "DATA";

		String testCaseName = method.getName().toString().trim();
		TestCaseDataFromExcel objData = new TestCaseDataFromExcel(excelFileName, excelSheetName, testCaseName);		
		List<HashMap<String, String>> allData = objData.getTestCaseData();

		Object [][] aryList = new Object[allData.size()][1];

		for(int i=0;i<allData.size();i++) {
			aryList[i][0] = allData.get(i);
		}
		return aryList;
	}catch(Exception ex) {
		ex.printStackTrace();
		return null;
	}

}}