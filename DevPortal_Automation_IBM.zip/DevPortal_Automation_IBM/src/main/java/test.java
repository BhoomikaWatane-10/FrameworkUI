import java.io.File;
import java.text.SimpleDateFormat;


public class test {

   public static void main(String[] args) throws InterruptedException {
	   
	   //"C:\Users\0019FH744\Downloads\TPP registration (2).yaml"
	   
	   
	           //Specify the file path and name
	   	File file = new File("C:\\Users\\0019FH744\\Downloads\\TPP registration (2).json");
	           SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
	   	System.out.println("Last Modified Date: " + sdf.format(file.lastModified()));
	       
	   	File f = new File("C:\\Users\\0019FH744\\Downloads\\TPP registration (2).yaml");
	   	if(f.exists() && !f.isDirectory()) { 
	   	    System.out.println(f.delete());
	   	}
//System.setProperty("webdriver.gecko.driver","C:\\Users\\Abha_Rathour\\Downloads\\ExtractedFiles\\geckodriver-v0.24.0-win64\\geckodriver.exe"); 
	   /*WebDriverManager.chromedriver().setup();
WebDriver driver= new ChromeDriver();

driver.manage().timeouts().implicitlyWait(3000, TimeUnit.MILLISECONDS);

    driver.get("https://www.facebook.com/");

    driver.findElement(By.tagName("body")).sendKeys(Keys.CONTROL + "t");

    Set <String> windowHandles = driver.getWindowHandles();

    System.out.println(windowHandles.size());

    for(String winHandle : driver.getWindowHandles()){

        driver.switchTo().window(winHandle);

    }

    driver.navigate().to("http://www.google.com");

}
*/

	  /*
		 * Date date = new Date(); String modifiedDate= new
		 * SimpleDateFormat("yyyy-MM-dd").format(date);
		 * System.out.println(modifiedDate);
		 * 
		 * final Calendar cal = Calendar.getInstance(); cal.add(Calendar.DATE, -15);
		 * 
		 * DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		 * System.out.println(dateFormat.format(cal.getTime()));
		 */
	//}
	  // private Date yesterday() {
		/*
		 * final Calendar cal1 = Calendar.getInstance(); cal1.add(Calendar.DATE, -1);
		 * System.out.println(cal1.getTime());
		 */
		//}
	   
      /*Date data = new Date();
     // data.getTimezoneOffset();
      java.time.LocalDateTime localDatetime = java.time.LocalDateTime.now();
		String screenshotName = Integer.toString(localDatetime.getHour()) + localDatetime.getMinute() + localDatetime.getSecond() + localDatetime.getDayOfMonth()  + localDatetime.getMonthValue()+localDatetime.getYear();
     System.out.println(screenshotName);
      SimpleDateFormat formatar = new SimpleDateFormat("d-m-y");
      String dataFormatada = formatar.format(data);  

      try{      

         File f = new File(screenshotName);

         System.out.println(screenshotName);

         f.mkdir();

      }catch(Exception e){

         e.printStackTrace();
      }
   }*/
}}