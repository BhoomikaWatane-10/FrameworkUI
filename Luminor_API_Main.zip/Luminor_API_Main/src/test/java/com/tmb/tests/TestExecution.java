package com.tmb.tests;

import java.util.Map;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.luminor.ConsentAuthorizationViaAPI;
import com.luminor.ConsentDetails;
import com.luminor.Testchainingoutput;
import com.luminor.base.BaseTest;
import com.tmb.utils.DataProviderUtils;

public class TestExecution extends BaseTest{

	Testchainingoutput getAccountList = new Testchainingoutput();
	ConsentDetails consent = new ConsentDetails();
	ConsentAuthorizationViaAPI consentAuth = new ConsentAuthorizationViaAPI();
	//RequestSpecification reqSpec = RequestBulider.Builder();
	
	@Test(dataProvider="dataProvider",dataProviderClass = DataProviderUtils.class)
	public void API_01_consentAuthorizationViaAPI(Map<String, String> map) throws Exception {
		
			System.out.println(map.get("TC_Name"));
			consentAuth.ConsentAuthorizationAPI(map.get("username"),map.get("perosonalCode"));	
	}
	
	@Test(dataProvider="dataProvider",dataProviderClass = DataProviderUtils.class)
	public void API_02_CreateConsentAndGetConsentDetails(Map<String, String> map) throws Exception {
		
			System.out.println(map.get("TC_Name"));
			consent.consentDetails(map.get("username"),map.get("perosonalCode"));	
	}
}
