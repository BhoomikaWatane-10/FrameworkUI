package com.tmb.tests;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import com.luminor.base.BaseTest;
import com.tmb.utils.SslconfigUtils;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class createTPPAPITest extends BaseTest {

	// public static void main(String args[]) {
	@Test // (dataProvider="getData11",dataProviderClass = DataProviderUtils.class)
	public void createTPPAPI() throws Exception {
		System.out.println("testing");
		//RestAssured.config = RestAssured.config().sslConfig(Sslconfiguration.getSslConfig());
		try {
			Response response = (Response) given().baseUri("https://psd2.stg.lumsolutions.net/v1")
					// .header("Content-Type","application/json") //.contentType(ContentType.JSON)

					/*
					 * .body("{\n" + "\"appName\": \"Bhoomika12-25-08\",\n" + "\"contacts\": [\n" +
					 * "\"admin@tpp-system-a.com\"\n" + "],\n" + "\"redirectUris\": [\n" +
					 * "\"https://localhost/login\",\n" + "\"https://localhost/login1\",\n" +
					 * "\"https://localhost/login2\",\n" + "\"https://localhost/login3\"]\n" + "}")
					 */ .when().get("/tpp-clients/0bc95e0b-3021-419b-ab25-b096820232a6").then().log().all();// .then().statusCode(200);
			System.out.println(response.then().statusCode(200));
			// Reporting.test.pass( response.asString());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
