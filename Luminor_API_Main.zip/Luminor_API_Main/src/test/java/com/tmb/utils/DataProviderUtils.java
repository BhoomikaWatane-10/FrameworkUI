package com.tmb.utils;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.DataProvider;

public final class DataProviderUtils {

	@DataProvider(name="dataProvider")
	public static Object[][] TestCaseDataProvider(Method method) {
		System.out.println(2);
		try {
			// WFCustDataProvider params = method.getAnnotation(WFCustDataProvider.class);
			
			String excelFileName = System.getProperty("user.dir")+"\\src\\test\\resources\\testdata.xlsx";

			String excelSheetName = "DATA";

			String testCaseName = method.getName().toString().trim();
			TestCaseDataFromExcel objData = new TestCaseDataFromExcel(excelFileName, excelSheetName, testCaseName);
			List<HashMap<String, String>> allData = objData.getTestCaseData();

			Object[][] aryList = new Object[allData.size()][1];

			for (int i = 0; i < allData.size(); i++) {
				aryList[i][0] = allData.get(i);
			}
			return aryList;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}

	}
}