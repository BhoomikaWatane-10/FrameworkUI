package com.tmb.utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public final class ExcelUtility {

	private ExcelUtility() {
		
	}
	
	//Try with Resoures
	public static List<Map<String,String>> getTestDetails(String sheetname){
		List<Map<String,String>> list = null;
		try(FileInputStream fs = new FileInputStream("C:\\Users\\0019FH744\\ProjectWorkspace\\Luminor_API_Main\\src\\test\\resources\\testdata.xlsx")) {

			XSSFWorkbook workbook = new XSSFWorkbook(fs);
			XSSFSheet sheet = workbook.getSheet(sheetname);

			int lastrownum = sheet.getLastRowNum();
			int lastcolnum = sheet.getRow(0).getLastCellNum();

			Map<String,String> map =null;
			list = new ArrayList<>();

			for(int i=1; i<=lastrownum;i++) { 
				map = new HashMap<>(); 
				for(int j=0;j<lastcolnum;j++) {
					String key= sheet.getRow(0).getCell(j).getStringCellValue();
					
					String value = sheet.getRow(i).getCell(j).getStringCellValue();
					//if(value!=null) {
					map.put(key, value);
				//}
					//else {
						//j++;
					//}
				list.add(map);
			}
			}}
		 catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println(list);
		return list;
	}
	
	

}