package com.tmb.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Calender {

	
	public static String getCurrentDate() {
		
		Date date = new Date();
		   String CurrentDate= new SimpleDateFormat("yyyy-MM-dd").format(date);
		   System.out.println(CurrentDate);
		   
		 return CurrentDate;
		
	}
	
public String getPreviousDate() {
		
	final Calendar cal = Calendar.getInstance();
    cal.add(Calendar.DATE, -15);
   
    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    System.out.println(dateFormat.format(cal.getTime()));
    String backDate=dateFormat.format(cal.getTime());
	return backDate;
    
		
	}

public static String getFutureDate(int days) {
	
	final Calendar cal = Calendar.getInstance();
    cal.add(Calendar.DATE, days);
   
    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    System.out.println(dateFormat.format(cal.getTime()));
    String backDate=dateFormat.format(cal.getTime());
	return backDate;
    
		
	}
}
