package com.tmb.utils;

	import java.io.FileInputStream;
	import java.security.KeyManagementException;
	import java.security.KeyStore;
	import java.security.KeyStoreException;
	import java.security.NoSuchAlgorithmException;
	import java.security.UnrecoverableKeyException;

	import io.restassured.config.SSLConfig;

	//public class CertHelper {
	public class SslconfigUtils {
	  @SuppressWarnings("deprecation")
	public static SSLConfig getSslConfig() {
	    String password = "123456";
	    KeyStore keyStore = null;
	    try {
	    	System.out.println(System.getProperty("user.dir"));
	    	String path = System.getProperty("user.dir")+"\\src\\main\\resources\\keystore.jks";
	    	//path=path.replaceAll("\","\"\\");
	    	System.out.println(path);
	    	//C:\Users\0019FH744\ProjectWorkspace\Luminor_API_Main\src\main\resources\keystore.jks
	      FileInputStream fis = new FileInputStream(path);
	      keyStore = KeyStore.getInstance("JKS");
	      keyStore.load(
	          fis,
	          password.toCharArray());

	    } catch (Exception ex) {
	      System.out.println("Error while loading keystore >>>>>>>>>");
	      ex.printStackTrace();
	    }
	    if (keyStore != null) {
	      @SuppressWarnings("deprecation")
		org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = null;
	      try {
	        clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, password);
	      } catch (NoSuchAlgorithmException e) {
	        e.printStackTrace();
	      } catch (KeyManagementException e) {
	        e.printStackTrace();
	      } catch (KeyStoreException e) {
	        e.printStackTrace();
	      } catch (UnrecoverableKeyException e) {
	        e.printStackTrace();
	      }
	      return new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
	    }
	    else return  null;
	  }
	  
	  
	}
//}
