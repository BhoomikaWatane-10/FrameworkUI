package com.tmb.utils;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class TestCaseDataFromExcel {

	// variable declaration
	String excelFilePath;
	String excelSheetName;
	String testCaseName;
	FormulaEvaluator fe;

	// Parameterize constructor calling
	public TestCaseDataFromExcel(String excelFilePath, String excelSheetName, String testCaseName) {
		System.out.println(1);
		this.excelFilePath = excelFilePath;
		this.excelSheetName = excelSheetName;
		this.testCaseName = testCaseName;
	}

	// Method to read the test data from the sheet
	public List<HashMap<String, String>> getTestCaseData() throws Exception {

		// Excel file path
		File file = new File(excelFilePath);
		FileInputStream inputStream = new FileInputStream(file);

		// object initiating of workbook
		Workbook excelBook;

		if (getFileExtension(file).contains(".xls"))
			excelBook = new HSSFWorkbook(inputStream);
		else
			excelBook = new XSSFWorkbook(inputStream);

		// cell evaluator
		fe = excelBook.getCreationHelper().createFormulaEvaluator();

		// object for sheet
		Sheet workSheet = excelBook.getSheet(excelSheetName);

		// retrive total row count
		int totalRow = readTotalRows(workSheet);

		// retrieved sheet header with respective index
		HashMap<String, Integer> headerIndex = dataSheetHeader(workSheet);

		// searching test case in the test data sheet
//		int tcsFound = testCaseExistance(workSheet, testCaseName, headerIndex.get("TestCaseScript"), totalRow);

		boolean foundflag = false;

		// retrive total number of columns
		int totalCol = readTotalCols(workSheet, 0);

		// Object[][] objData = null;
		List<HashMap<String, String>> allData = new ArrayList<HashMap<String, String>>();

		int ithRow = 0, emptyRow = 0, i = 0;
		String strValue = "";
		int columnHeaderCount = 0;

		String tcNm = "";

		do {
			i++;
			try {
				if (workSheet.getRow(i).getCell(headerIndex.get("TC_Name")).toString().isEmpty()) {
					emptyRow++;
				} else if (workSheet.getRow(i).getCell(headerIndex.get("TC_Name")).toString()
						.equalsIgnoreCase(testCaseName)
						&& workSheet.getRow(i).getCell(headerIndex.get("Run")).toString().equalsIgnoreCase("yes")) {

					emptyRow = 0;
					if (!tcNm.equalsIgnoreCase(workSheet.getRow(i).getCell(headerIndex.get("TC_Name")).toString()))
						columnHeaderCount = i - 1;
					HashMap<String, String> hmD = new HashMap<String, String>();
					totalCol = readTotalCols(workSheet, i - 1);
					for (int idCol = 0; idCol < totalCol; idCol++) {
						hmD.put(workSheet.getRow(columnHeaderCount).getCell(idCol).toString(),
								readCellsWithRespectiveTypes(excelBook, workSheet, i, idCol));
					}
					allData.add(hmD);

					tcNm = workSheet.getRow(i).getCell(headerIndex.get("TC_Name")).toString();

					foundflag = true;
				} else {
					emptyRow = 0;
				}
			} catch (Exception ex) {
				emptyRow++;
				if (foundflag)
					break;
			}
		} while (emptyRow <= 1);

		return allData;

	}

	public String readCellsWithRespectiveTypes(Workbook excelBook, Sheet workSheet, int row, int col) {
		String strValue = "";
		Cell cellData = workSheet.getRow(row).getCell(col);
		org.apache.poi.ss.usermodel.CellValue cellVal = fe.evaluate(cellData);

		if (cellData != null && (!cellData.getStringCellValue().isEmpty())) {

			if (cellVal.getCellType() == CellType.STRING)
				strValue = cellVal.getStringValue();
			else if (cellVal.getCellType() == CellType.BLANK)
				strValue = cellVal.getStringValue();
			else if (cellVal.getCellType() == CellType.NUMERIC)
				strValue = cellVal.getStringValue();
		} else
			strValue = "";

		return strValue;
	}

	// find the test case
	public int testCaseExistance(Sheet workSheet, String testCaseName, int colForTcs, int totalNumOfRows) {
		int tcsRow = 0;
		Object[][] objData = null;

		for (int i = 1; i < totalNumOfRows; i++) {
			if (workSheet.getRow(i).getCell(colForTcs).toString().equalsIgnoreCase(testCaseName)) {
				objData = new Object[i][readTotalCols(workSheet, i)];
			}

		}

		return tcsRow;
	}

	// read Header with indexing
	public HashMap<String, Integer> dataSheetHeader(Sheet workSheet) {
		HashMap<String, Integer> hmHeader = new HashMap<String, Integer>();

		int totalColumn = readTotalCols(workSheet, 0);

		for (int i = 0; i < totalColumn; i++) {
			hmHeader.put(workSheet.getRow(0).getCell(i).toString(), i);
		}

		return hmHeader;

	}

	public int readTotalCols(Sheet workSheet, int rowNum) {
		return (workSheet.getRow(rowNum).getPhysicalNumberOfCells());

	}

	// count total rows
	public int readTotalRows(Sheet workSheet) {
		return (workSheet.getPhysicalNumberOfRows());
	}

	// read file extension
	public String getFileExtension(File file) {
		String fileName = file.getName();
		String ext = "";

		if (fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0)
			ext = fileName.substring(fileName.lastIndexOf(".") + 1);
		else
			ext = "";

		return ext;
	}

}
