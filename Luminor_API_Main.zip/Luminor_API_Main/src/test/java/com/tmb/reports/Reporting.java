package com.tmb.reports;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class Reporting {

	public static ExtentReports extent;
	public static ExtentTest test;
	
	ThreadLocal<ExtentTest> extentTest = new ThreadLocal<ExtentTest>();
	public static ExtentReports reportConfig() {
		//java.time.LocalDateTime localDatetime = java.time.LocalDateTime.now();
		//String folderName = Integer.toString(localDatetime.getHour()) + localDatetime.getMinute() + localDatetime.getSecond() + localDatetime.getDayOfMonth()  + localDatetime.getMonthValue()+localDatetime.getYear();
		try{      

	         //File f = new File(System.getProperty("user.dir")+folderName);

	        // System.out.println(folderName);

	      // f.mkdir();
			
		String path = System.getProperty("user.dir") + "\\reports\\" + System.currentTimeMillis()+ "\\Report.html";

		ExtentSparkReporter reporter = new ExtentSparkReporter(path);

		reporter.config().setReportName("API Automation");

		reporter.config().setDocumentTitle("Test Results");

		extent = new ExtentReports();

		extent.attachReporter(reporter);

		extent.setSystemInfo("Author", "Bhoomika");
		
		
		}catch(Exception e){

	         e.printStackTrace();
	      }
		return extent;

	}

	
	public static ExtentTest extentCreateTest(String testcasename) {
		 test=extent.createTest(testcasename);
		 return test;
		}


	
	
	
}
