package com.luminor.base;

import java.io.FileNotFoundException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.tmb.utils.SslconfigUtils;

import io.github.bonigarcia.wdm.WebDriverManager;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
public class BaseUI extends BaseTest {
	//RandomUtils random = new RandomUtils();
	//public static void main(String[] args) throws InterruptedException {
	
	public   String getAccessToken1() throws FileNotFoundException, InterruptedException {
	// WebDriver driver;
		//  String browsername = BaseTest.prop.getProperty("browser"); // Chrome if
		//  (browsername.equals("chrome")) { 
			 // WebDriverManager.chromedriver().setup();
		 // }
		String Bearertoken="";
		  //driver = new ChromeDriver();
		 // driver.get("https://www.google.com");
		 // driver.get("https://login.tst.lumsolutions.net/v1/am/oauth2/authorize?realm=psd2&bank_country=ee&client_id=37e6faeb-7638-4a19-9b11-8cba21de028f&redirect_uri=https://localhost/login&response_type=code&locale=en&inf_logo_label=inf_logo_value");
		 Thread.sleep(20000);
		  driver.findElement(By.id("smartid")).click();
		  Thread.sleep(10000);
		  driver.findElement(By.id("idToken4")).sendKeys("7939112");
		  Thread.sleep(10000);
		  driver.findElement(By.id("idToken6")).sendKeys("46401266973");
		  Thread.sleep(10000);
		  driver.findElement(By.id("idToken15_0")).click();
		  Thread.sleep(25000);
		  driver.findElement(By.id("idToken3_0")).click();
		  Thread.sleep(10000);
		String getCurrentURL = driver.getCurrentUrl();
		
		RestAssured.config = RestAssured.config().sslConfig(SslconfigUtils.getSslConfig());	
		String match = getCurrentURL;//"https://localhost/login?code=GE9xCeiLxeodyTnzGxIhMaJNsVQ.4576-zz7XzuZZN5Zt31X9DKcWZU&auth=eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdXRoX21ldGhvZCI6InNtYXJ0aWQiLCJuYmYiOjE2MjkzNTMwNTksImF1dGhfdmVyaWZ5X3NtYXJ0aWQiOiJhZTE3MGU0NDU4YzVhOGEwZGNkZGMzNTc3YTc2ZjZmMjIwNGNmNDI3MmRlYzkxM2I3ZWYwYjcyMmYwMmIwY2FiIiwiZXhwIjoxNjI5MzU2MDU5LCJsb2NhbGUiOiJlbiIsImlhdCI6MTYyOTM1MzA1OSwianRpIjoiODI0YzYzZTYtMmEyOC00ODBkLWJlOTktYjgwYjAwYTg2YzRmIn0.U27VSi2cWqSAVxW2gcOVRSBain2RSZ1z81QwyiB50An45Nz4m3awZqhIa5-ql12rMiBrm0IeVhKKR-udk4tE3Kve3beeySIDMxbjGGXUGG4ZJkGC_obfFpfFYFWxwP3hyfzaKecAl1ue6TOiQvyZc-ZqiNL88I9skxVsNw-YLlSQGhlCLLNlb8jOJ7vrsxwoigtOoZazeaa03FolJTXXBU1Y7aBssIR_jEqT4Tpw0RdpiaQJthZgNBAiIXthPq2RZfcs_ddZ0JWyaMmLRVQ76ggQaxmwKhrz6cKwkzt3BXVdX87aR0-NNNxUZytY1aUQDlv8NvUX0Fzkx2CEM2SEqA&iss=https%3A%2F%2Flogin.stg.lumsolutions.net%2Fv1%2Fam%2Foauth2%2Frealms%2Froot%2Frealms%2Fpsd2&state=ttr2TU&client_id=f1465c9e-e220-4385-95c5-f15773333a76";
		Pattern patternForCode = Pattern.compile("code=(.*?)&");
		Matcher matcherForCode = patternForCode.matcher(match);
		while (matcherForCode.find()) {
			System.out.println(matcherForCode.group());
			String apiCode = matcherForCode.group();
			apiCode = apiCode.replaceAll("code=", "");
			apiCode = apiCode.replaceAll("&", "");
			 System.out.println(apiCode);
			 
			Response res= RestAssured.given().baseUri(prop.getProperty("baseURI"))//.urlEncodingEnabled(true)
					.header("Content-Type","application/x-www-form-urlencoded")
					.queryParams("realm", "psd2","client_id","37e6faeb-7638-4a19-9b11-8cba21de028f","grant_type","authorization_code","redirect_uri","https://localhost/login","code",apiCode)
			.when().post(prop.getProperty("postAccesstoken"));
			//System.out.println(res.getSessionId());
			System.out.println(res.statusCode());
			String Access_Token = res.asString();
		  try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		
		  
		
		//  System.out.println(Access_Token);
		     
		
		  Pattern patternForRefreshToken = Pattern.compile("\"refresh_token\":\"(.*?),\"auth_method\"");
			Matcher matcherForRefreshtoken = patternForRefreshToken.matcher(Access_Token);
			System.out.println(matcherForRefreshtoken);
			System.out.println(matcherForRefreshtoken.find());
			//while (m.find()==true) {
			//	System.out.println(m.group());
				String gen_refresh_token = matcherForRefreshtoken.group();
				gen_refresh_token = gen_refresh_token.replaceAll("\"refresh_token\":\"", "");
				gen_refresh_token = gen_refresh_token.replaceAll(",\"auth_method\"", "");
				 System.out.println(gen_refresh_token);
			
				 
				 Pattern patternforIdtoken = Pattern.compile("\"id_token\":\"(.*?),\"token_type\"");
					Matcher matcherforIdtoken = patternforIdtoken.matcher(Access_Token);
					System.out.println(matcherforIdtoken);
					System.out.println(matcherforIdtoken.find());
					//while (m.find()==true) {
					//	System.out.println(m.group());
						String gen_Id_token = matcherforIdtoken.group();
						gen_Id_token = gen_Id_token.replaceAll("\"id_token\":\"", "");
						gen_Id_token = gen_Id_token.replaceAll(",\"token_type\"", "");
						 System.out.println(gen_Id_token);
					
			  Response res1=
			  RestAssured.given().baseUri("https://psd2.tst.lumsolutions.net/v1")//.
			 // urlEncodingEnabled(true)
			  .header("Content-Type","application/x-www-form-urlencoded") 
			  //.cookie(myCookie) 
			 .header("Cookie","tgtcookie="+gen_Id_token)
			  .queryParams("realm",
			  "psd2","client_id","37e6faeb-7638-4a19-9b11-8cba21de028f","grant_type",
			  "refresh_token","redirect_uri","https://localhost/login","code",apiCode,
			  "refresh_token",
			  gen_refresh_token,
			  "client_id","37e6faeb-7638-4a19-9b11-8cba21de028f")
			  .when().post("/openam/oauth2/access_token");
			 
			
			  System.out.println(res1.statusCode()); 
			 String refreshtoken = res1.asString();
			 System.out.println(refreshtoken);
			 
			 Pattern patternforBearertoken = Pattern.compile("\"access_token\":\"(.*?),\"auth_method\"");
				Matcher matcherForBearerToken = patternforBearertoken.matcher(refreshtoken);
				System.out.println(matcherForBearerToken);
				System.out.println(matcherForBearerToken.find());
				//while (m.find()==true) {
				//	System.out.println(m.group());
					 Bearertoken = matcherForBearerToken.group();
					Bearertoken = Bearertoken.replaceAll("\"access_token\":\"", "");
					Bearertoken = Bearertoken.replaceAll(",\"auth_method\"", "");
					 System.out.println(Bearertoken);
					 
					
					 
		}	
			/* Response response1 =
				      RestAssured.given()
				          .headers(
				              "Authorization",
				              "Bearer " + Bearertoken,"X-Request-ID",com.tmb.utils.RandomUtils.generateRandomString(14)
				             )
				          .when()
				          .get("https://psd2.tst.lumsolutions.net/v1/account-list")
				          .then()
				          .contentType(ContentType.JSON)
				          .extract()
				          .response();
			 
			 System.out.println(response1.getBody().asPrettyString());
			 */
		 return Bearertoken;
}
	/*
	 * public static void main(String[] args) throws FileNotFoundException,
	 * InterruptedException { test1 t = new test1(); t.initiateWebdriver(); }
	 */
}


