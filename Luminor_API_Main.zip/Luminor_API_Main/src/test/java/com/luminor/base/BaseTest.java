package com.luminor.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;

import com.tmb.utils.SslconfigUtils;

import io.github.bonigarcia.wdm.WebDriverManager;
import io.restassured.RestAssured;

public class BaseTest {

	public static Properties prop;
	public static WebDriver driver;
	public static int SMALL_WAIT;
	public static int LONG_WAIT;
	public static int VERY_LONG_WAIT;
	public static int WAIT_TO_LOAD;

//	PerformOperations common = new PerformOperations();
	public WebDriver getDriver() {

		return driver;
	}

	// public WebDriver driver;

	@BeforeTest
	public static void LoadConfigProperty() throws IOException {
		prop = new Properties();
		System.out.println(System.getProperty("user.dir"));
		FileInputStream fis = new FileInputStream(System.getProperty("user.dir") + "\\src\\test\\resources\\config.properties");
		try {
			prop.load(fis);

			SMALL_WAIT = Integer.parseInt(prop.getProperty("smallwait"));
			LONG_WAIT = Integer.parseInt(prop.getProperty("longwait"));
			VERY_LONG_WAIT = Integer.parseInt(prop.getProperty("verylongwait"));
			WAIT_TO_LOAD = Integer.parseInt(prop.getProperty("waittoLoad"));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		// return destinationFile;
	}

	@BeforeMethod
	public void initiateWebdriver() throws FileNotFoundException {

		String browsername = BaseTest.prop.getProperty("browser");
		// Chrome
		if (browsername.equals("chrome")) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();

			// Firefox
		} else if (browsername.equals("firefox")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
		} else if (browsername.equals("edge")) {
			System.setProperty("webdriver.edge.driver", System.getProperty("user.dir") + "\\src\\msedgedriver.exe");
			driver = new EdgeDriver();

		}
		// WebDriverManager.chromedriver().setup();
		// driver = new ChromeDriver();
		driver.manage().deleteAllCookies();
		driver.get(prop.getProperty("baseURL"));
		driver.manage().window().maximize();
		String tittle = driver.getTitle();

		// Assert.assertEquals(tittle, prop.getProperty("title"));

		// Assertions.assertThat(tittle).containsIgnoringCase("luminor");

	}

	public String getScreenShotPath(String testCaseName, WebDriver driver1) throws IOException {

		java.time.LocalDateTime localDatetime = java.time.LocalDateTime.now();
		String screenshotName = Integer.toString(localDatetime.getHour()) + localDatetime.getMinute()
				+ localDatetime.getSecond() + localDatetime.getDayOfMonth() + localDatetime.getMonthValue()
				+ localDatetime.getYear() + localDatetime.getNano();
		// System.out.println(screenshotName);
		// System.out.println(testCaseName);
		// System.out.println(driver);
		// WebDriver driver1 = null;
		TakesScreenshot ts = (TakesScreenshot) driver1;
		File source = ts.getScreenshotAs(OutputType.FILE);
		String destinationFile = System.getProperty("user.dir") + "\\reports\\Screenshots\\" + screenshotName + ".png";
		FileUtils.copyFile(source, new File(destinationFile));
		return destinationFile;

	}

	@AfterMethod
	public void logout() {
		driver.quit();
	}

	@BeforeTest
	public void getAPIConfig() {
		RestAssured.config = RestAssured.config().sslConfig(SslconfigUtils.getSslConfig());
	}

}
