package com.luminor;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.luminor.base.BaseTest;
import com.luminor.builders.RequestBulider;
import com.tmb.reports.Reporting;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class ConsentDetails extends BaseTest{

	CreateConsent createconsent = new CreateConsent();
	
	String consentId ="";
	Response resConsentDetails=null;
	
	public void consentDetails(String username,String personalCode) throws Exception {
		RequestSpecification reqSpec = RequestBulider.Builder(username,personalCode);
		String consentId = createconsent.createConsent(reqSpec);
		Response resConsentDetails = RestAssured.given().spec(reqSpec).get("/consents/"+consentId).then().extract().response();
		Reporting.test.pass("Consent Deails are :"+resConsentDetails.prettyPrint());
		System.out.println(resConsentDetails.statusCode());
		System.out.println(resConsentDetails.prettyPrint());
	}
}
