package com.luminor.builders;

import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;

import com.luminor.base.BaseTest;
import com.luminor.operations.GetToken;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;

public class RequestBulider extends BaseTest {
	static String bearer = "";
	// public static String bearer1 = "";
	static RequestSpecification reqspec;
	static RequestSpecBuilder reqBuilder;

	
	public static RequestSpecification Builder(String username,String personalCode) {

		try {
			bearer = GetToken.getAccessToken(username,personalCode);
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}

		Map<String, String> header = new HashMap<>();
		header.put("Authorization", "Bearer " + bearer);
		header.put("X-Request-ID", com.tmb.utils.RandomUtils.generateRandomString(14));
		header.put("PSU-IP-Address", "122.122.122");
		reqBuilder = new RequestSpecBuilder();
		reqBuilder.setBaseUri("https://psd2.tst.lumsolutions.net/v1/").addHeaders(header)
				.setContentType(ContentType.JSON);
		reqspec = reqBuilder.build();
		return reqspec;
	}

	
}