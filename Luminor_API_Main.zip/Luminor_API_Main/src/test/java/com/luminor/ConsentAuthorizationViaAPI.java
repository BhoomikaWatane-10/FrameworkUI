package com.luminor;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.luminor.base.BaseTest;
import com.luminor.builders.RequestBulider;
import com.luminor.operations.PerformOperations;
import com.luminor.pojo.AuthenticationPojo;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class ConsentAuthorizationViaAPI extends BaseTest{

	CreateConsent consent = new CreateConsent();
	PerformOperations common = new PerformOperations();
	String authentication_Method="";
	AuthenticationPojo authentication;
	String authorizationId="";
	String consentId ="";
	public void ConsentAuthorizationAPI(String username,String personalCode) {
		RequestSpecification reqSpec = RequestBulider.Builder(username,personalCode);
		try {
		String consentId=	consent.createConsent(reqSpec);
		authentication_Method="SMART_ID";
		authentication = new AuthenticationPojo(authentication_Method);
		
			Response resConsentauthorization = RestAssured.given().spec(reqSpec).post("/consents/"+consentId+"/authorisations");
			authorizationId = common.getvalueFromJsonBodyResponse(resConsentauthorization.asPrettyString(),"authorisationId");
			
			//put method for signing consent
			
		Response resauthenticationMethod=	RestAssured.given().spec(reqSpec).body(authentication).put("/consents/" +
					  consentId + "/authorisations/" + authorizationId + "");
		ObjectMapper object = new ObjectMapper();
		String myData = object.writerWithDefaultPrettyPrinter().writeValueAsString(authentication);
		System.out.println(myData);
		
		System.out.println(resauthenticationMethod.asPrettyString());
		common.waitForSync(LONG_WAIT);
		
		
		Response resConsentAuthorisationList=	RestAssured.given().spec(reqSpec).get("/consents/" +
				  consentId + "/authorisations");
		
		System.out.println(resConsentAuthorisationList.asPrettyString());
		
		Response resConsentAuthorisationDetails=	RestAssured.given().spec(reqSpec).get("/consents/" +
				  consentId + "/authorisations/"+authorizationId);
		
		System.out.println(resConsentAuthorisationDetails.asPrettyString());
		} catch (JsonProcessingException e) {
			
			e.printStackTrace();
		}
		
	}
	
	
}
