
package com.luminor.pojo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonInclude(JsonInclude.Include.NON_NULL)

//@Generated("jsonschema2pojo")
public class AccessPojo {
	
	@JsonProperty("accounts")
	private List<AccountPojo> accounts = null;

	//@JsonProperty("access")
	//private GetAccountListPojo access;

	public AccessPojo(List<AccountPojo> accounts ) {
		// this.access1=access1;
		//this.access = access;
		this.accounts = accounts;
		accounts.toString();
	}

	/*
	 * @JsonProperty("access") public GetAccountListPojo getAccess() { return
	 * access; }
	 * 
	 * @JsonProperty("access") public void setAccess(GetAccountListPojo access) {
	 * this.access = access; }
	 */

	@JsonProperty("accounts")
	public List<AccountPojo> getAccounts() {
		return accounts;
	}

	@JsonProperty("accounts")
	public void setAccounts(List<AccountPojo> accounts) {
		this.accounts = accounts;
	}

	
}
