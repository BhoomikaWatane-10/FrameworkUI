
package com.luminor.pojo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)

//@Generated("jsonschema2pojo")
public class GetAccountListPojo {

	@JsonProperty("access")
	private AccessPojo access;
	@JsonProperty("recurringIndicator")
	private Boolean recurringIndicator;
	@JsonProperty("validUntil")
	private String validUntil;
	@JsonProperty("frequencyPerDay")
	private Integer frequencyPerDay;
	@JsonProperty("combinedServiceIndicator")
	private Boolean combinedServiceIndicator;

	public GetAccountListPojo(AccessPojo access, Boolean recurringIndicator, String validUntil, Integer frequencyPerDay,
			Boolean combinedServiceIndicator) {
		this.access = access;
		this.recurringIndicator = recurringIndicator;
		this.validUntil = validUntil;
		this.frequencyPerDay = frequencyPerDay;
		this.combinedServiceIndicator = combinedServiceIndicator;

	}

	@JsonProperty("recurringIndicator")
	public Boolean getRecurringIndicator() {
		return recurringIndicator;
	}

	@JsonProperty("recurringIndicator")
	public void setRecurringIndicator(Boolean recurringIndicator) {
		this.recurringIndicator = recurringIndicator;
	}

	@JsonProperty("validUntil")
	public String getValidUntil() {
		return validUntil;
	}

	@JsonProperty("validUntil")
	public void setValidUntil(String validUntil) {
		this.validUntil = validUntil;
	}

	@JsonProperty("frequencyPerDay")
	public Integer getFrequencyPerDay() {
		return frequencyPerDay;
	}

	@JsonProperty("frequencyPerDay")
	public void setFrequencyPerDay(Integer frequencyPerDay) {
		this.frequencyPerDay = frequencyPerDay;
	}

	@JsonProperty("combinedServiceIndicator")
	public Boolean getCombinedServiceIndicator() {
		return combinedServiceIndicator;
	}

	@JsonProperty("combinedServiceIndicator")
	public void setCombinedServiceIndicator(Boolean combinedServiceIndicator) {
		this.combinedServiceIndicator = combinedServiceIndicator;
	}

	@JsonProperty("access")
	public AccessPojo getAccess() {
		return access;
	}

	@JsonProperty("access")
	public void setAccess(AccessPojo access) {
		this.access = access;
	}

}
