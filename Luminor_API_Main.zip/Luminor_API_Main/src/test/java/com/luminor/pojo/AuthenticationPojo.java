package com.luminor.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;


public class AuthenticationPojo {
	
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	
	

	@JsonProperty("authenticationMethodId")
	private String authenticationMethodId;

	
	/**
	*
	* @param authenticationMethodId
	*/
	public AuthenticationPojo(String authenticationMethodId) {
	super();
	this.authenticationMethodId = authenticationMethodId;
	}

	@JsonProperty("authenticationMethodId")
	public String getAuthenticationMethodId() {
	return authenticationMethodId;
	}

	@JsonProperty("authenticationMethodId")
	public void setAuthenticationMethodId(String authenticationMethodId) {
	this.authenticationMethodId = authenticationMethodId;
	}

}
