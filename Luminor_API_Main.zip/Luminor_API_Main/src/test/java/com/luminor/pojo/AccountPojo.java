
package com.luminor.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
//Generated("jsonschema2pojo")
public class AccountPojo {
	@JsonProperty("access1")
	private AccessPojo access1;
	@JsonProperty("iban")
	private String iban;
	
	public AccountPojo(String iban) {
		//this.access1=access1;
		this.iban = iban;
		// TODO Auto-generated constructor stub
	}
	
	
	@JsonProperty("iban")
	public String getIban() {
		return iban;
	}

	@JsonProperty("iban")
	public void setIban(String iban) {
		this.iban = iban;
	}
	
	@JsonProperty("access1")
	public AccessPojo getAccess1() {
		return access1;
	}

	@JsonProperty("access1")
	public void setAccess(AccessPojo access1) {
		this.access1 = access1;
	}
}
