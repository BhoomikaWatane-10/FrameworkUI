package com.luminor;

import org.testng.annotations.Test;

import com.luminor.base.BaseTest;
import com.luminor.builders.RequestBulider;
import com.luminor.operations.PerformOperations;
import com.tmb.reports.Reporting;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Testchainingoutput extends BaseTest {
	// PerformOperations common = new PerformOperations();
	PerformOperations common = new PerformOperations();
	//RequestBulider reqSpec = new RequestBulider();
	String iban = "";
	String bearer = "";
	String link = "";
	String consentId = "";
	String authorizationId = "";
	String StringResponseGetAccountList = "";
	Response resGetAccountList = null;
	
	// @Test RequestSpecification reqSpec
	public String getAccountList(RequestSpecification reqSpec) {

		//RequestSpecification reqSpec = RequestBulider.Builder();

		resGetAccountList = RestAssured.given().spec(reqSpec).get("/account-list").then().extract().response();
		StringResponseGetAccountList = resGetAccountList.asPrettyString();
		System.out.println(StringResponseGetAccountList);
		Reporting.test.pass("Response From Get Account List: <br>" + StringResponseGetAccountList);
		iban = "accounts.find{it.currency=='EUR'}.iban";
		String ibanValue = common.getvalueFromJsonBodyResponse(StringResponseGetAccountList, iban);

		return ibanValue;
		// System.out.println(resGetAccountList.asPrettyString());

		/*
		 * JsonPath account = new JsonPath(response1.asPrettyString());
		 * 
		 * iban = account.getString("accounts.find{it.currency=='EUR'}.iban");
		 * System.out.println("IBan :" + iban);
		 * 
		 * 
		 * String consentbody = "{\r\n" + "  \"access\": {\r\n" +
		 * "    \"accounts\": [\r\n" + "      {\r\n" + "        \"iban\": \"" + iban +
		 * "\"      }\r\n" + "    ]\r\n" + "  },\r\n" +
		 * "  \"recurringIndicator\": true,\r\n" + "  \"validUntil\": \"" +
		 * Calender.getFutureDate(2) + "\",\r\n" + "  \"frequencyPerDay\": 4,\r\n" +
		 * "  \"combinedServiceIndicator\": false\r\n" + "}";
		 * 
		 * // Response res= RestAssured.given().baseUri(consent)
		 * 
		 * String header1 = com.tmb.utils.RandomUtils.generateRandomString(14);
		 * System.out.println(header1); try { Response res =
		 * RestAssured.given().baseUri("https://psd2.tst.lumsolutions.net/v1")//
		 * .contentType(ContentType.JSON)
		 * 
		 * .headers("Authorization", "Bearer " + bearer, "X-Request-ID", header1,
		 * "Content-Type", "application/json", "PSU-IP-Address", "127.0.0.1")
		 * .body(consentbody).post("/consents");
		 * 
		 * System.out.println(res.statusCode()); System.out.println(res.prettyPrint());
		 * 
		 * // signing with UI JsonPath consent = new JsonPath(res.asPrettyString());
		 * 
		 * link = consent.getString("_links.scaRedirect.href"); consentId =
		 * consent.getString("consentId");
		 * 
		 * // try { Response res1 =
		 * RestAssured.given().baseUri("https://psd2.tst.lumsolutions.net/v1")//
		 * .contentType(ContentType.JSON)
		 * 
		 * .headers("Authorization", "Bearer " + bearer, "X-Request-ID",
		 * com.tmb.utils.RandomUtils.generateRandomString(14), "Content-Type",
		 * "application/json", "PSU-IP-Address", "127.0.0.1") .post("/consents/" +
		 * consentId + "/authorisations"); // System.out.println("link :" + link);
		 * System.out.println(res1.asPrettyString());
		 * 
		 * // } // catch(Exception e) { // e.printStackTrace(); // } JsonPath
		 * authorization = new JsonPath(res1.asPrettyString());
		 * 
		 * // link = authorization.getString("_links.scaRedirect.href"); authorizationId
		 * = authorization.getString("authorisationId");
		 * 
		 * try { Response res2 =
		 * RestAssured.given().baseUri("https://psd2.tst.lumsolutions.net/v1")//
		 * .contentType(ContentType.JSON)
		 * 
		 * .headers("Authorization", "Bearer " + bearer, "X-Request-ID",
		 * com.tmb.utils.RandomUtils.generateRandomString(14), "Content-Type",
		 * "application/json") .body("{\r\n" +
		 * "  \"authenticationMethodId\": \"SMART_ID\"\r\n" + "}") .put("/consents/" +
		 * consentId + "/authorisations/" + authorizationId + ""); //
		 * System.out.println("link :" + link); System.out.println("res2:" +
		 * res2.asPrettyString()); } catch (Exception e) { e.printStackTrace(); }
		 * Thread.sleep(LONG_WAIT); try { Response res3 =
		 * RestAssured.given().baseUri("https://psd2.tst.lumsolutions.net/v1")//
		 * .contentType(ContentType.JSON)
		 * 
		 * .headers("Authorization", "Bearer " + bearer, "X-Request-ID",
		 * com.tmb.utils.RandomUtils.generateRandomString(14))
		 * 
		 * .get("consents/"+consentId ); // System.out.println("link :" + link);
		 * System.out.println("res3:" + res3.asPrettyString()); } catch (Exception e) {
		 * e.printStackTrace(); } Thread.sleep(VERY_LONG_WAIT); try { Response res4 =
		 * RestAssured.given().baseUri("https://psd2.tst.lumsolutions.net/v1")//
		 * .contentType(ContentType.JSON)
		 * 
		 * .headers("Authorization", "Bearer " + bearer, "X-Request-ID",
		 * com.tmb.utils.RandomUtils.generateRandomString(14))
		 * 
		 * .get("consents/" + consentId + "/authorisations/" + authorizationId + ""); //
		 * System.out.println("link :" + link); System.out.println("res4:" +
		 * res4.asPrettyString()); } catch (Exception e) { e.printStackTrace(); } }
		 * catch (Exception e) { // TODO Auto-generated catch block e.printStackTrace();
		 * }
		 * 
		 * Reporting.test.pass("Consent Created");
		 * 
		 * } catch (Exception e) {
		 * 
		 * Reporting.test.fail("Get Acccount list is not Executed");
		 * 
		 * e.printStackTrace(); }
		 * 
		 * }
		 */
	}
}