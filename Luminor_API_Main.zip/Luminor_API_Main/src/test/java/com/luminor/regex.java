package com.luminor;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class regex {

	// TODO Auto-generated method stub
	

	public static void main(String[] args) {
		//RestAssured.config = RestAssured.config().sslConfig(sslconfig1.getSslConfig());	
		String match = "\"refresh_token\": \"k1FS24iP2AihfibBd/3ySoJpp0krmfILPMWfnMZ6Bxu2+9qZmwmO3FYPIHvyFJeEgGE1yM6QVOK1tEhs4QVS3QX4JEhCBseG8lvx+6ToTXDalHQOgLSnuDDT58S2gky4NuxlfwQQAcmdVGLflncAtFzkmdad6Wr/y6BmJ/QjbY5RS/UEJ9OHFSGxW2pVIVC2fyieJnzVrsBaR5Gqqp0HE8LfKopKM5lO++xFzKy3FJDtbqYe2A+71BuKQWDpCWH/NjemAkr+s0rg1g7nnl6vD17LxBDS+C7/ip7LnMrBQMxnGB6c09aPONunBdHvBJzVA9Cpdclz+bbHZA4wvLvJBqpVJLlxlxcZcWHRwd20Gb6155itC7IAliACmwpaVttodrgR4nGaR4xgAZKWKdpZztHAoLNMK0tOjhaVZkOhJC+nPyiN+tay9UD24L54r//eWW/xjaYLKZzsWOWAzIlaNt0ftbOrNAHIhO3ZfkF3y+jfZxuNj1S7FEZE3BaTSk8NLx2M3Z2tuGygPxq48GPXjFvsz1zkKcdZd7l1U2vizIK6JEMGX5GYxFbYRU6PWANFOdUI0hmTpHdFEl0JjabUgGQV8bC3HjmivzLVoAc8ihZF9jWKxvYekxewiAL/Ffi7On7bSUNJgUvRSI7+BJRluD0w2T3xGsxTfPBcZPu/oNzDFegkWuO1DRImH/8tI+9ztSS2h6hxRw2L1drkyIbBsj/1TYMCacqlb4HnnrI+C1Iy8U2g4upTbuwhD/wpr3hjAkyX2qp9U8sR4nQBlFMBU4qFM9A5SpF+PEYyTmg5yHth5bCTLEmsGdAzUoO2J44KzCnPXa7b1/f6fcYj9oHQnUe/gDbEoOmlHw5sAkJwFSThLawdp+JIgsLP7HHIahFktbodtzxUKrHmYDhhIGUfVT9iRA2Qdu2hd10bhymNnRRyajsO/7y9s+5ci+aYUMi2ALHM55Ly4r7kf7UXfDfHgaClPvEIoqN+lOc/9p6j7rPAB/eeoO2xMkHIDyMu3M/c7TxhKNw3zGYCTUrLWlRuu/JLq4XThmhQt/XR+20YGOFfEsIds4aESkvBsnUo13A4ifJJdTDDaR0mklK2mzZujgTRj0DmxJEMbbqIZd/fWZoJbj/DJytALdDbqnNndJboBviCFRVJOiNoF825IgoawAtoq7v7rbphvdXQqPezxDakQ4ZTb+RrO430UKpKb2HJ9gq/58/iduLGtlvjXxZSVM72IpjNiBxM9lI5Z+jweS/2LW2h5WBIRVFGMkuJMGvwLj9tnt+eKj6s4Muk8BCyeywczSXsZjOscT6TL/a3jQZM7Ox2csK4e76IOEUxzthPrG+bEvLR1xnuDB/crWXV3/2V263dRZk92YuMo8Jg7xuur8OpAJEMqKoBWVUsMJ+HZCpQDXItRQYtufzlxQC2zI3E7vhq7zjgCKpItCUphuhs6/jrRWzDuDpk3NWKUExAS/gGSUzFwp10FAkBFENWjnUcDdVeAAQST61DiHrQeBeGc1wBXxzlv794lvDVAq4Py00L7k8PdUKWe81CFcS4xCKIxlQ8WROnYEgO2gO0ZZaaH/pmSerYdOeUqAIZUteaAfUJwDtWG7BoPUJrJ4fbeY8M4rzzuPEj76BaDnyyobpg6tg1p/e8owtbSjRSAXMSBENFm8lvd4guNu5m/cb3suhyL2cimRASpZmZsP+jXyJHuzRWwmKC4UIdQHvVjOHmkK9vaE+fzKbj8APqajcC4N1nMbFwlj3SjhJtRIbJYQINvFBxHsCyLk4tRzLZ/8jItKYuGraiHzfZvolD2HZdrVvoSe0IFoSHtu7QuKouA1RcD3r23Mdbf4AujQrqlq95\",\r\n"
				+ "    \"auth_method\"";
		Pattern p = Pattern.compile("\"refresh_token\": \"(.*?),\r\n");
		Matcher m = p.matcher(match);
		//System.out.println(match);
		System.out.println(m.find());
		//while (m.find()==true) {
		//	System.out.println(m.group());
			String s = m.group();
			 s = s.replaceAll("\"refresh_token\": \"", "");
			 s = s.replaceAll(",\r\n\"", "");
			 System.out.println(s);
			 
		//	Response res= RestAssured.given().baseUri("https://psd2.stg.lumsolutions.net/v1").header("Content-Type","application/x-www-form-urlencoded").queryParams("realm", "psd2","client_id","37e6faeb-7638-4a19-9b11-8cba21de028f","grant_type","authorization_code","redirect_uri","https://localhost/login","code",s)
		//	.when().post("https://psd2.stg.lumsolutions.net/v1/openam/oauth2/access_token");
			
			//System.out.println(res.statusCode());*/
		//}
	}
}

	//,"token_type""Bearer","expires_in"3599}