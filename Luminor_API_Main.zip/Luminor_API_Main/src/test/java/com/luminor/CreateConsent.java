package com.luminor;

import java.util.ArrayList;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.luminor.base.BaseTest;
import com.luminor.operations.PerformOperations;
import com.luminor.pojo.AccessPojo;
import com.luminor.pojo.AccountPojo;
import com.luminor.pojo.GetAccountListPojo;
import com.tmb.reports.Reporting;
import com.tmb.utils.Calender;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateConsent extends BaseTest {

	Testchainingoutput getaccount = new Testchainingoutput();
	PerformOperations common = new PerformOperations();
	
	String iban = "";
	String bearer = "";
	String link = "";
	String consentId = "";
	String authorizationId = "";
	String StringResponseGetAccountList = "";
	Response resGetAccountList = null;
	
	public String createConsent(RequestSpecification reqSpec) throws JsonProcessingException {

		//RequestSpecification reqSpec = RequestBulider.Builder();
		
		
		String iban=getaccount.getAccountList(reqSpec);
		System.out.println(iban);
		AccountPojo account = new AccountPojo(iban);
		ArrayList<AccountPojo> accountlist = new ArrayList<>();
		System.out.println(account);
		accountlist.add(account);

		AccessPojo access = new AccessPojo(accountlist);
		GetAccountListPojo getAccountList1 = new GetAccountListPojo(access, true, Calender.getFutureDate(2), 4, false);

		ObjectMapper object = new ObjectMapper();
		String myData = object.writerWithDefaultPrettyPrinter().writeValueAsString(getAccountList1);
		System.out.println(myData);
		
		Response resConsent = RestAssured.given().spec(reqSpec).body(getAccountList1).post("/consents");

		System.out.println(resConsent.statusCode());
		System.out.println(resConsent.prettyPrint());
		consentId = common.getvalueFromJsonBodyResponse(resConsent.asPrettyString(),"consentId");
		System.out.println(consentId);
		if(resConsent.statusCode()==200) {
			Reporting.test.pass("consent created "+"<Br>"+"Response code :"+resConsent.statusCode());
			Reporting.test.pass("Response: "+resConsent.prettyPrint());
		}
		else {
			Reporting.test.fail("consent created "+"<Br>"+"Response code :"+resConsent.statusCode());
			Reporting.test.fail("Response: "+resConsent.prettyPrint());
		}
		
		return consentId;
	}
	
	
}
