package com.luminor.pojo;



import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

public class DebtorAccountPojo {

    @JsonProperty("iban")
    private String iban;

    /**
     * No args constructor for use in serialization
     * 
     */
    public DebtorAccountPojo() {
    }

    /**
     * 
     * @param iban
     */
    public DebtorAccountPojo(String iban) {
        super();
        this.iban = iban;
    }

    @JsonProperty("iban")
    public String getIban() {
        return iban;
    }

    @JsonProperty("iban")
    public void setIban(String iban) {
        this.iban = iban;
    }

}
