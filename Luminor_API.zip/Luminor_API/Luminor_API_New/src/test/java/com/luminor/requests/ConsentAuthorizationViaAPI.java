package com.luminor.requests;

import com.aventstack.extentreports.util.Assert;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.luminor.base.BaseTest;
import com.luminor.builders.RequestBulider;
import com.luminor.operations.PerformOperations;
import com.luminor.pojo.AuthenticationPojo;
import com.luminor.reports.Reporting;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class ConsentAuthorizationViaAPI extends BaseTest {

	CreateConsent consent = new CreateConsent();
	PerformOperations common = new PerformOperations();
	private String authentication_Method = "";
	private AuthenticationPojo authentication;
	private String authorizationId = "";
	//private String consentId = "";

	public void ConsentAuthorizationAPI(RequestSpecification reqSpec, String consentId,String recurringIndicator,String validUntilInPutIndays,String frequencyPerDay,String combinedServiceIndicator) {
		//RequestSpecification reqSpec = RequestBulider.Builder(username, personalCode);
		
		//create consent
		try {
			//consentId = consent.createConsent(reqSpec,recurringIndicator,validUntilInPutIndays,frequencyPerDay,combinedServiceIndicator);
			authentication_Method = "SMART_ID";
			authentication = new AuthenticationPojo(authentication_Method);

			Response resConsentauthorization = RestAssured.given().spec(reqSpec)
					.post("/consents/" + consentId + "/authorisations");
			authorizationId = common.getvalueFromJsonBodyResponse(resConsentauthorization.asPrettyString(),
					"authorisationId");

			// put method for signing consent

			Response resauthenticationMethod = RestAssured.given().spec(reqSpec).body(authentication)
					.put("/consents/" + consentId + "/authorisations/" + authorizationId + "");
			ObjectMapper object = new ObjectMapper();
			String myData = object.writerWithDefaultPrettyPrinter().writeValueAsString(authentication);
			System.out.println(myData);
			
			Reporting.test.pass("Request Body for authentication Method"+"<br>"+myData);
			if (resauthenticationMethod.statusCode() == 200 || resauthenticationMethod.statusCode() == 201) {
				System.out.println(resauthenticationMethod.asPrettyString());
				Reporting.test
						.pass("Authentication is successful:" + "<br>" + resauthenticationMethod.asPrettyString());
				common.waitForSync(LONG_WAIT);
			} else {
				Reporting.test
						.fail(resauthenticationMethod.statusCode() + "<br>" + resauthenticationMethod.asPrettyString());
				org.testng.Assert.assertTrue(false);
			}
			
			//consent signing List
			Response resConsentAuthorisationList = RestAssured.given().spec(reqSpec)
					.get("/consents/" + consentId + "/authorisations");

			if (resConsentAuthorisationList.statusCode() == 200 || resConsentAuthorisationList.statusCode() == 201) {
				System.out.println(resConsentAuthorisationList.asPrettyString());
				Reporting.test.pass("Authorization List:" + "<br>" + resConsentAuthorisationList.asPrettyString());
			}

			else {
				Reporting.test.fail(resConsentAuthorisationList.statusCode() + "<br>"
						+ resConsentAuthorisationList.asPrettyString());
				org.testng.Assert.assertTrue(false);
			}
		}
			catch (JsonProcessingException e) {

				e.printStackTrace();
			}
		}
			
			public void consentAuthorizationDetails(String username,String personalCode, String recurringIndicator,String validUntilInPutIndays,String frequencyPerDay,String combinedServiceIndicator) {
				
				RequestSpecification reqSpec = RequestBulider.Builder(username, personalCode);
				String consentId;
				try {
					consentId = consent.createConsent(reqSpec,recurringIndicator,validUntilInPutIndays,frequencyPerDay,combinedServiceIndicator);
					ConsentAuthorizationAPI(reqSpec,consentId, recurringIndicator, validUntilInPutIndays, frequencyPerDay, combinedServiceIndicator);
					
					
					//consent authorization Details
					Response resConsentAuthorisationDetails = RestAssured.given().spec(reqSpec)
							.get("/consents/" + consentId + "/authorisations/" + authorizationId);

					if (resConsentAuthorisationDetails.statusCode() == 200
							|| resConsentAuthorisationDetails.statusCode() == 201) {
						System.out.println(resConsentAuthorisationDetails.asPrettyString());
						Reporting.test
								.pass("Consent Autorization is successful. Details are:" + "<br>" + resConsentAuthorisationDetails.asPrettyString());
					}

					else {
						Reporting.test.fail(resConsentAuthorisationDetails.statusCode() + "<br>"
								+ resConsentAuthorisationDetails.asPrettyString());
						org.testng.Assert.assertTrue(false);
					}
					System.out.println(resConsentAuthorisationDetails.asPrettyString());
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				//try {
			
			
			
		} 

			
			
	}

