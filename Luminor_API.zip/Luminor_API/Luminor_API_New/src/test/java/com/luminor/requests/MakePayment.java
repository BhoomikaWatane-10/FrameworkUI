package com.luminor.requests;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.luminor.base.BaseTest;
import com.luminor.builders.RequestBulider;
import com.luminor.operations.PerformOperations;
import com.luminor.pojo.AuthenticationPojo;
import com.luminor.pojo.CreditorAccountPojo;
import com.luminor.pojo.CreditorAddressPojo;
import com.luminor.pojo.DebtorAccountPojo;
import com.luminor.pojo.InstructedAmountPojo;
import com.luminor.pojo.MakePaymentPojo;
import com.luminor.reports.Reporting;
import com.luminor.utils.Calender;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class MakePayment extends BaseTest {

	GetAccountList getaccount = new GetAccountList();
	PerformOperations common = new PerformOperations();

	private String paymentId = "";
	private String authorisationId = "";
	private AuthenticationPojo authentication;
	private String authentication_Method;
	private String PaymentURL;
	// Properties prop;

	private String SmartIDButton = "//*[text()=\"Sign with Smart-ID\"]";
	//private String paymentProcessingRequest = "//*[text()=\"we're processing your payment\"]";
	private String backToserviceProviderButton = "//*[contains(text(),\"You will pay\"]";
	//private String LanguageEN = "//ul[@class='languageselect-languages']/li/div[text()='en']";
	// Back to service provider
	public void makePaymentViaAPI(String username, String perosonalCode, String amount, String currency,

			String debtorName, String debtorType, String debtorId, String debtorIdType, String requestedExecutionDate,
			String creditorName, String creditorIban, String country, String street,
			String remittanceInformationUnstructured) throws JsonProcessingException {
		RequestSpecification reqSpec = RequestBulider.Builder(username, perosonalCode);//username, perosonalCode

		String iban = getaccount.getAccountList(reqSpec);
		System.out.println(iban);
		DebtorAccountPojo debtoraccount = new DebtorAccountPojo(iban);
		CreditorAccountPojo creditAccount = new CreditorAccountPojo(creditorIban);
		InstructedAmountPojo instructedAmount = new InstructedAmountPojo(amount, currency);
		CreditorAddressPojo creditorAddress = new CreditorAddressPojo(country, street);

		MakePaymentPojo payment = new MakePaymentPojo(instructedAmount, debtoraccount, debtorName, debtorType, debtorId,
				debtorIdType, Calender.getCurrentDate(), creditorName, creditAccount, creditorAddress,
				remittanceInformationUnstructured);

		ObjectMapper object = new ObjectMapper();
		String myData = object.writerWithDefaultPrettyPrinter().writeValueAsString(payment);
		System.out.println(myData);

		Response resCreatePayment = RestAssured.given().spec(reqSpec).body(payment)
				.post("/payments/sepa-credit-transfers");
		paymentId = common.getvalueFromJsonBodyResponse(resCreatePayment.prettyPrint(), "paymentId");
		Reporting.test.pass("Request Body for Payment " + "<br>" + myData);
		if (resCreatePayment.statusCode() == 200 || resCreatePayment.statusCode() == 201) {
			System.out.println(resCreatePayment.prettyPrint());
			Reporting.test.pass("Response of Make Payment:" + "<br>" + resCreatePayment.prettyPrint());
			common.waitForSync(SMALL_WAIT);

		} else {
			Reporting.test.fail("Response of Make Payment:" + "<br>" + resCreatePayment.statusCode()
					+ resCreatePayment.prettyPrint());
//common.waitForSync(LONG_WAIT);
		}

		Response resIntiatePaymentAuthorize = RestAssured.given().spec(reqSpec)
				.post("/payments/sepa-credit-transfers/" + paymentId + "/authorisations");
		if (resIntiatePaymentAuthorize.statusCode() == 200 || resIntiatePaymentAuthorize.statusCode() == 201) {
			authorisationId = common.getvalueFromJsonBodyResponse(resIntiatePaymentAuthorize.prettyPrint(),
					"authorisationId");
			System.out.println(resIntiatePaymentAuthorize.prettyPrint());
			Reporting.test.pass("Response of Make Payment:" + "<br>" + resIntiatePaymentAuthorize.prettyPrint());
			common.waitForSync(SMALL_WAIT);

		} else {
			Reporting.test.fail("Intitate Payment Signing:" + "<br>" + resIntiatePaymentAuthorize.statusCode()
					+ resIntiatePaymentAuthorize.prettyPrint());

		}
		authentication_Method = "SMART_ID";
		authentication = new AuthenticationPojo(authentication_Method);

		Response resAuthorisationPayment = RestAssured.given().spec(reqSpec).body(authentication)
				.put("/payments/sepa-credit-transfers/" + paymentId + "/authorisations/" + authorisationId);

		if (resAuthorisationPayment.statusCode() == 200 || resAuthorisationPayment.statusCode() == 201) {
			System.out.println(resAuthorisationPayment.prettyPrint());
			Reporting.test.pass("Authentication for signing Payment:" + "<br>" + resAuthorisationPayment.prettyPrint());
			common.waitForSync(SMALL_WAIT);

		} else {
			Reporting.test.fail("Authentication for signing Payment:" + "<br>" + resAuthorisationPayment.statusCode()
					+ resAuthorisationPayment.prettyPrint());

		}

		Response resPaymentauthorizationDetails = RestAssured.given().spec(reqSpec)
				.get("/payments/sepa-credit-transfers/" + paymentId + "/authorisations/" + authorisationId);

		if (resPaymentauthorizationDetails.statusCode() == 200 || resPaymentauthorizationDetails.statusCode() == 201) {
			System.out.println(resPaymentauthorizationDetails.prettyPrint());
			Reporting.test
					.pass("Payment authorization Details:" + "<br>" + resPaymentauthorizationDetails.prettyPrint());
			common.waitForSync(LONG_WAIT);

		} else {
			Reporting.test.fail("Payment authorization Details:" + "<br>" + resPaymentauthorizationDetails.statusCode()
					+ resPaymentauthorizationDetails.prettyPrint());

		}

		Response resPaymentauthorizationStatus = RestAssured.given().spec(reqSpec)
				.get("/payments/sepa-credit-transfers/" + paymentId + "/authorisations/" + authorisationId + "/status");

		if (resPaymentauthorizationStatus.statusCode() == 200 || resPaymentauthorizationStatus.statusCode() == 201) {
			System.out.println(resPaymentauthorizationStatus.prettyPrint());
			Reporting.test.pass("Payment authorization Status:" + "<br>" + resPaymentauthorizationStatus.prettyPrint());

		} else {
			Reporting.test.fail("Payment authorization Status:" + "<br>" + resPaymentauthorizationStatus.statusCode()
					+ resPaymentauthorizationStatus.prettyPrint());

		}

	}

	public void makePaymentViaAPIFixedIban(String username, String perosonalCode, String amount, String iban,
			String currency,

			String debtorName, String debtorType, String debtorId, String debtorIdType, String requestedExecutionDate,
			String creditorName, String creditorIban, String country, String street,
			String remittanceInformationUnstructured) throws JsonProcessingException {

		RequestSpecification reqSpec = RequestBulider.Builder(username,perosonalCode);
		String clientId = prop.getProperty("clientId");
		// String baseURI = prop.getProperty("baseURI");
		System.out.println(iban);
		DebtorAccountPojo debtoraccount = new DebtorAccountPojo(iban);
		CreditorAccountPojo creditAccount = new CreditorAccountPojo(creditorIban);
		InstructedAmountPojo instructedAmount = new InstructedAmountPojo(amount, currency);
		CreditorAddressPojo creditorAddress = new CreditorAddressPojo(country, street);

		MakePaymentPojo payment = new MakePaymentPojo(instructedAmount, debtoraccount, debtorName, debtorType, debtorId,
				debtorIdType, Calender.getCurrentDate(), creditorName, creditAccount, creditorAddress,
				remittanceInformationUnstructured);

		ObjectMapper object = new ObjectMapper();
		String myData = object.writerWithDefaultPrettyPrinter().writeValueAsString(payment);
		System.out.println(myData);

		Response resCreatePayment = RestAssured.given().spec(reqSpec)
				.headers("Tpp-Redirect-URI", "https://www.microsoft.com", "Tpp-Nok-Redirect-URI",
						"https://www.google.lv", "Tpp-Client-Id", clientId)
				.body(payment).post("/payments/sepa-credit-transfers");
		paymentId = common.getvalueFromJsonBodyResponse(resCreatePayment.prettyPrint(), "paymentId");
		Reporting.test.pass("Request Body for Payment " + "<br>" + myData);

		if (resCreatePayment.statusCode() == 200 || resCreatePayment.statusCode() == 201) {
			System.out.println(resCreatePayment.prettyPrint());
			Reporting.test.pass("Response of Make Payment:" + "<br>" + resCreatePayment.prettyPrint());
			common.waitForSync(SMALL_WAIT);

		} else {
			Reporting.test.fail("Response of Make Payment:" + "<br>" + resCreatePayment.statusCode()
					+ resCreatePayment.prettyPrint());
//common.waitForSync(LONG_WAIT);
		}

		Response resIntiatePaymentAuthorize = RestAssured.given().spec(reqSpec)
				.post("/payments/sepa-credit-transfers/" + paymentId + "/authorisations");
		if (resIntiatePaymentAuthorize.statusCode() == 200 || resIntiatePaymentAuthorize.statusCode() == 201) {
			authorisationId = common.getvalueFromJsonBodyResponse(resIntiatePaymentAuthorize.prettyPrint(),
					"authorisationId");
			System.out.println(resIntiatePaymentAuthorize.prettyPrint());
			Reporting.test.pass("Response of Make Payment:" + "<br>" + resIntiatePaymentAuthorize.prettyPrint());
			common.waitForSync(SMALL_WAIT);

		} else {
			Reporting.test.fail("Intitate Payment Signing:" + "<br>" + resIntiatePaymentAuthorize.statusCode()
					+ resIntiatePaymentAuthorize.prettyPrint());

		}
		authentication_Method = "SMART_ID";
		authentication = new AuthenticationPojo(authentication_Method);

		Response resAuthorisationPayment = RestAssured.given().spec(reqSpec).body(authentication)
				.put("/payments/sepa-credit-transfers/" + paymentId + "/authorisations/" + authorisationId);

		if (resAuthorisationPayment.statusCode() == 200 || resAuthorisationPayment.statusCode() == 201) {
			System.out.println(resAuthorisationPayment.prettyPrint());
			Reporting.test.pass("Authentication for signing Payment:" + "<br>" + resAuthorisationPayment.prettyPrint());
			common.waitForSync(SMALL_WAIT);

		} else {
			Reporting.test.fail("Authentication for signing Payment:" + "<br>" + resAuthorisationPayment.statusCode()
					+ resAuthorisationPayment.prettyPrint());

		}

		Response resPaymentauthorizationDetails = RestAssured.given().spec(reqSpec)
				.get("/payments/sepa-credit-transfers/" + paymentId + "/authorisations/" + authorisationId);

		if (resPaymentauthorizationDetails.statusCode() == 200 || resPaymentauthorizationDetails.statusCode() == 201) {
			System.out.println(resPaymentauthorizationDetails.prettyPrint());
			Reporting.test
					.pass("Payment authorization Details:" + "<br>" + resPaymentauthorizationDetails.prettyPrint());
			common.waitForSync(25);

		} else {
			Reporting.test.fail("Payment authorization Details:" + "<br>" + resPaymentauthorizationDetails.statusCode()
					+ resPaymentauthorizationDetails.prettyPrint());

		}

		Response resPaymentauthorizationStatus = RestAssured.given().spec(reqSpec)
				.get("/payments/sepa-credit-transfers/" + paymentId + "/authorisations/" + authorisationId + "/status");
		common.waitForSync(10);
		 resPaymentauthorizationStatus = RestAssured.given().spec(reqSpec)
				.get("/payments/sepa-credit-transfers/" + paymentId + "/authorisations/" + authorisationId + "/status");
		 resPaymentauthorizationStatus = RestAssured.given().spec(reqSpec)
				.get("/payments/sepa-credit-transfers/" + paymentId + "/authorisations/" + authorisationId + "/status");
		if (resPaymentauthorizationStatus.statusCode() == 200 || resPaymentauthorizationStatus.statusCode() == 201) {
			System.out.println(resPaymentauthorizationStatus.prettyPrint());
			Reporting.test.pass("Payment authorization Status:" + "<br>" + resPaymentauthorizationStatus.prettyPrint());

		} else {
			Reporting.test.fail("Payment authorization Status:" + "<br>" + resPaymentauthorizationStatus.statusCode()
					+ resPaymentauthorizationStatus.prettyPrint());

		}

	}

public void makePaymentViaUI(String username, String perosonalCode, String amount, String currency,
		
		String debtorName, String debtorType, String debtorId, String debtorIdType, String requestedExecutionDate,
		String creditorName, String creditorIban, String country, String street,
		String remittanceInformationUnstructured) throws JsonProcessingException {
		RequestSpecification reqSpec = RequestBulider.Builder(username, perosonalCode);

		String iban = getaccount.getAccountList(reqSpec);
		
		Select s = null;
		System.out.println(iban);
		DebtorAccountPojo debtoraccount = new DebtorAccountPojo(iban);
		CreditorAccountPojo creditAccount = new CreditorAccountPojo(creditorIban);
		InstructedAmountPojo instructedAmount = new InstructedAmountPojo(amount, currency);
		CreditorAddressPojo creditorAddress = new CreditorAddressPojo(country, street);

		MakePaymentPojo payment = new MakePaymentPojo(instructedAmount, debtoraccount, debtorName, debtorType, debtorId,
				debtorIdType, Calender.getCurrentDate(), creditorName, creditAccount, creditorAddress,
				remittanceInformationUnstructured);

		ObjectMapper object = new ObjectMapper();
		String myData = object.writerWithDefaultPrettyPrinter().writeValueAsString(payment);
		System.out.println(myData);

		Response resCreatePayment = RestAssured.given().spec(reqSpec).headers("Tpp-Redirect-Preferred","true","Tpp-Redirect-URI", "https://www.microsoft.com","Tpp-Nok-Redirect-URI", "https://www.google.lv","Tpp-Client-Id", prop.getProperty("clientId")).body(payment)
				.post("/payments/sepa-credit-transfers");
		paymentId = common.getvalueFromJsonBodyResponse(resCreatePayment.prettyPrint(), "paymentId");
		PaymentURL= common.getvalueFromJsonBodyResponse(resCreatePayment.prettyPrint(), "_links.scaRedirect.href");
		
		System.out.println(PaymentURL);
		Reporting.test.pass("Request Body for Payment " + "<br>" + myData);
		if (resCreatePayment.statusCode() == 200 || resCreatePayment.statusCode() == 201) {
			System.out.println(resCreatePayment.prettyPrint());
			Reporting.test.pass("Response of Make Payment:" + "<br>" + resCreatePayment.prettyPrint());
			common.waitForSync(SMALL_WAIT);

		} else {
			Reporting.test.fail("Response of Make Payment:" + "<br>" + resCreatePayment.statusCode()
					+ resCreatePayment.prettyPrint());
		}
		common.waitForSync(SMALL_WAIT);
		if(PaymentURL!="") {
		driver.get(PaymentURL);
		common.waitForSync(LONG_WAIT);
		}
		else {
			Reporting.test.pass("URL value is Empty");
			Assert.assertFalse(false);
		}
		

		
		if (common.waitForvisible(By.id("smartid"))) {
			if(common.waitForvisible(By.id("lang-select"))){
				s = new Select(driver.findElement(By.id("lang-select")));
				s.selectByValue("en");
				common.waitForSync(SMALL_WAIT);
			}
			driver.findElement(By.id("smartid")).click();
			Reporting.test.pass("clicked on SMART ID");
			common.waitForSync(SMALL_WAIT);
		}
		if(common.waitForvisible(By.id("idToken4"))) {
			driver.findElement(By.id("idToken4")).sendKeys(username);// "7939112"
			Reporting.test.pass("enter the User ID");
			common.waitForSync(SMALL_WAIT);
		}
		if (common.waitForvisible(By.id("idToken6"))){
			driver.findElement(By.id("idToken6")).sendKeys(perosonalCode);// "46401266973"
			Reporting.test.pass("enter the Personal code");
			common.waitForSync(SMALL_WAIT);
		}
			else {
				//Reporting.test.pass("Personal code");	
		}
		
			if (common.waitForvisible(By.id("idToken15_0"))){
			driver.findElement(By.id("idToken15_0")).click();
			Reporting.test.pass("clicked on Log In");
			common.waitForSync(LONG_WAIT);
			}
			
					 else {
						 Reporting.test.pass("Confirm the Payment Via UI");
						common.waitForvisible(By.xpath("//div[@class='btn mandate-selection col-lg-8 col-lg-offset-2 active']"));
			//Reporting.test.fail("URL is not Loaded");
			//Assert.assertFalse(false);
		}
			
			if(common.waitForvisible(By.xpath("//div[@class='btn mandate-selection col-lg-8 col-lg-offset-2 active']"))) {
				common.waitForSync(5);
				driver.findElement(By.xpath("//div[@class='btn mandate-selection col-lg-8 col-lg-offset-2 active']")).click();
				common.waitForSync(SMALL_WAIT);
			}
			else {
				Reporting.test.pass("Select the language");
			}
		
		if(driver.findElement(By.xpath("//*[@class='icon']")).isDisplayed()) {
			common.waitForSync(5);
			driver.findElement(By.xpath("//*[@class='icon']")).click();
			common.waitForSync(SMALL_WAIT);
			driver.findElement(By.xpath("//ul[@class='languageselect-languages']/li/div[text()='en']")).click();
			common.waitForSync(SMALL_WAIT);
		}
		

		if(driver.findElement(By.xpath(SmartIDButton)).isDisplayed()) {
			
			driver.findElement(By.xpath(SmartIDButton)).click();
			common.waitForSync(SMALL_WAIT);
			if(driver.findElement(By.xpath("//*[@class='icon']")).isDisplayed()) {
				
				driver.findElement(By.xpath("//*[@class='icon']")).click();
				common.waitForSync(SMALL_WAIT);
				Reporting.test.pass("Please Wait..!! we are processing your payment");
				driver.findElement(By.xpath("//ul[@class='languageselect-languages']/li/div[text()='en']")).click();
				common.waitForSync(SMALL_WAIT);
			}
		Reporting.test.pass("Payment is Confirmed..!!!");
			
					
		}
		Response resPaymentStatus = RestAssured.given().spec(reqSpec)
				.get("/payments/sepa-credit-transfers/" + paymentId +  "/status");

		if (resPaymentStatus.statusCode() == 200 || resPaymentStatus.statusCode() == 201) {
			System.out.println(resPaymentStatus.prettyPrint());
			Reporting.test.pass("Payment authorization Status:" + "<br>" + resPaymentStatus.prettyPrint());

		} else {
			Reporting.test.fail("Payment authorization Status:" + "<br>" + resPaymentStatus.statusCode()
					+ resPaymentStatus.prettyPrint());

		}
		}
		
}
