package com.luminor.requests;

import org.testng.Assert;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.luminor.base.BaseTest;
import com.luminor.builders.RequestBulider;
import com.luminor.operations.PerformOperations;
import com.luminor.pojo.AuthenticationPojo;
import com.luminor.reports.Reporting;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TransactionHistory extends BaseTest {

	PerformOperations common = new PerformOperations();
	CreateConsent consent = new CreateConsent();
	ConsentAuthorizationViaAPI consentauthorize = new ConsentAuthorizationViaAPI();
	public String getAccountListForTransactionHistory(RequestSpecification reqSpec, String consentId) {
		String resourceId1 = "";
		String AccountId="";
		// consentId= consen
		Response resGetAccountList = RestAssured.given().spec(reqSpec).header("Consent-id", consentId).get("/accounts");
				resGetAccountList.then().log().all();
		if (resGetAccountList.statusCode() == 200) {
			System.out.println(resGetAccountList.asString());
			resourceId1 = common.getvalueFromJsonBodyResponse(resGetAccountList.asString(), "accounts.resourceId");
			AccountId=resourceId1.replaceAll("[^a-zA-Z0-9]", "");
			Reporting.test
			.pass("Get Account List : -->"+resGetAccountList.statusCode() + "\n************\n" + resGetAccountList.asPrettyString());
		}
		else {
			Reporting.test
					.fail(resGetAccountList.statusCode() + "\n************\n" + resGetAccountList.asPrettyString());
			Assert.assertTrue(false);
		}
		return AccountId;
	}

	public String initateTranscationHistory(RequestSpecification reqSpec, String consentId, String AccountId) {
		// String accountId=getAccountListForTransactionHistory(reqSpec,consentId)
		String statementId = null;
		// AccountId =getAccountListForTransactionHistory(reqSpec,consentId);
		//String AccountId1=AccountId.replaceAll("[^a-zA-Z0-9]", "");
		Response resInitateTranscationHistory = RestAssured.given().spec(reqSpec).header("Consent-id", consentId)
				.queryParams("DateFrom", "2020-09-01", "DateTo", "2021-08-08", "BookingStatus", "Booked").when()
				.post("/accounts/" + AccountId+"/transactions");

		if (resInitateTranscationHistory.statusCode() == 200 || resInitateTranscationHistory.statusCode() == 201) {
			Reporting.test.pass("Initate Transation History: success--> " + resInitateTranscationHistory.statusCode()
					+ "\n************\n" + resInitateTranscationHistory.asPrettyString());
			statementId = common.getvalueFromJsonBodyResponse(resInitateTranscationHistory.asPrettyString(),
					"statementId");
		} else {
			Reporting.test.fail("Initate Transation History: failed--> " + resInitateTranscationHistory.statusCode()
					+ "\n************\n" + resInitateTranscationHistory.asPrettyString());
		}
		return statementId;

	}

	public String createTransactionhistory(RequestSpecification reqSpec, String consentId, String AccountId,
			String statementId) {
		String authorizationId = "";
//String AccountId1 = "C6735E17AC5BFFECF7F55C6D817F869B2D5C8D11836BE24B1D9B0D12E8CBD8A7";
		Response resCreateTranscationHistory = RestAssured.given().spec(reqSpec).header("Consent-id", consentId)
				.post("/accounts/" + AccountId + "/transactions/" + statementId + "/authorisations");
		
		if (resCreateTranscationHistory.statusCode() == 200 || resCreateTranscationHistory.statusCode() == 201) {
			Reporting.test.pass("Create Transation History: success--> " + resCreateTranscationHistory.statusCode()
					+ "\n************\n" + resCreateTranscationHistory.asPrettyString());
			authorizationId = common.getvalueFromJsonBodyResponse(resCreateTranscationHistory.asPrettyString(),
					"authorisationId");
		} else {
			Reporting.test.fail("Create Transation History: failed--> " + resCreateTranscationHistory.statusCode()
					+ "\n************\n" + resCreateTranscationHistory.asPrettyString());
		}
		return authorizationId;

	}

	public void selectTransactionHistory(RequestSpecification reqSpec, String consentId, String AccountId,
			String statementId, String authorizationId) {
		String authenticationId = "SMART_ID";
		AuthenticationPojo authetication = new AuthenticationPojo(authenticationId);
		//String AccountId1="C6735E17AC5BFFECF7F55C6D817F869B2D5C8D11836BE24B1D9B0D12E8CBD8A7";
		Response resSelectTranscationHistory = RestAssured.given().spec(reqSpec).header("Consent-ID", consentId).body(authetication)
				.put("/accounts/" + AccountId + "/transactions/" + statementId + "/authorisations/" + authorizationId);

		if (resSelectTranscationHistory.statusCode() == 200 || resSelectTranscationHistory.statusCode() == 201) {
			Reporting.test.pass("select Transation History: success--> " + resSelectTranscationHistory.statusCode()
					+ "\n************\n" + resSelectTranscationHistory.asPrettyString());
			common.waitForSync(LONG_WAIT);
			//authorizationId = common.getvalueFromJsonBodyResponse(resSelectTranscationHistory.asPrettyString(),
					//"authorisationId");
		} else {
			Reporting.test.fail("select Transation History: Failed--> " + resSelectTranscationHistory.statusCode()
					+ "\n************\n" + resSelectTranscationHistory.asPrettyString());
		}

		// return statementId;

	}

	public void getTransactionHistoryDetails(String username, String personalCode, String recurringIndicator, String validUntilInPutIndays,
			String frequencyPerDay, String combinedServiceIndicator) {
		String consentId,AccountId,statementId,authorizationId;
		try {
			//System.out.println("inside Out");
			RequestSpecification reqSpec = RequestBulider.Builder(username, personalCode);
			consentId = consent.createConsent(reqSpec, recurringIndicator, validUntilInPutIndays, frequencyPerDay,
					combinedServiceIndicator);
			consentauthorize.ConsentAuthorizationAPI(reqSpec,consentId, recurringIndicator, validUntilInPutIndays, frequencyPerDay, combinedServiceIndicator);
			AccountId = getAccountListForTransactionHistory(reqSpec, consentId);
			statementId = initateTranscationHistory(reqSpec, consentId, AccountId);
			authorizationId = createTransactionhistory(reqSpec, consentId, AccountId, statementId);
			selectTransactionHistory(reqSpec, consentId, AccountId, statementId, authorizationId);
			Response resSelectTranscationHistory = RestAssured.given().spec(reqSpec).header("Consent-id", consentId)
					.get("/accounts/" + AccountId + "/transactions/" + statementId + "/authorisations/"
							+ authorizationId);

			if (resSelectTranscationHistory.statusCode() == 200 || resSelectTranscationHistory.statusCode() == 201) {
				Reporting.test.pass("Transation History Details: success: --> " + resSelectTranscationHistory.statusCode()
						+ "\n************\n" + resSelectTranscationHistory.asPrettyString());
				//authorizationId = common.getvalueFromJsonBodyResponse(resSelectTranscationHistory.asPrettyString(),
						//"authorisationId");
			} else {
				Reporting.test.fail("Transation History Details: Failed --> " + resSelectTranscationHistory.statusCode()
						+ "\n************\n" + resSelectTranscationHistory.asPrettyString());
			}
			
			Response resSelectTranscationHistoryStatus = RestAssured.given().spec(reqSpec).header("Consent-id", consentId)
					.get("/accounts/" + AccountId + "/transactions/" + statementId + "/status");

			if (resSelectTranscationHistoryStatus.statusCode() == 200 || resSelectTranscationHistoryStatus.statusCode() == 201) {
				Reporting.test.pass("Transation History Details: success: --> " + resSelectTranscationHistoryStatus.statusCode()
						+ "\n************\n" + resSelectTranscationHistoryStatus.asPrettyString());
				//authorizationId = common.getvalueFromJsonBodyResponse(resSelectTranscationHistory.asPrettyString(),
						//"authorisationId");
			} else {
				Reporting.test.fail("Transation History status: Failed --> " + resSelectTranscationHistoryStatus.statusCode()
						+ "\n************\n" + resSelectTranscationHistoryStatus.asPrettyString());
			}
			
		} catch (JsonProcessingException e) {
			
			e.printStackTrace();
		}
	}
	
	
}
