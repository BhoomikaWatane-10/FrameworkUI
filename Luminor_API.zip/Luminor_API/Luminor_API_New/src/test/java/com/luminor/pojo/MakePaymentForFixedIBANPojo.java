package com.luminor.pojo;


import com.fasterxml.jackson.annotation.JsonProperty;



public class MakePaymentForFixedIBANPojo {

    @JsonProperty("instructedAmount")
    private InstructedAmountPojo instructedAmount;
    @JsonProperty("debtorAccount")
    private DebtorAccountPojo debtorAccount;
    @JsonProperty("debtorName")
    private String debtorName;
    @JsonProperty("debtorType")
    private String debtorType;
    @JsonProperty("debtorId")
    private String debtorId;
    @JsonProperty("debtorIdType")
    private String debtorIdType;
    @JsonProperty("requestedExecutionDate")
    private String requestedExecutionDate;
    @JsonProperty("creditorName")
    private String creditorName;
    @JsonProperty("creditorAccount")
    private CreditorAccountPojo creditorAccount;
    @JsonProperty("creditorAddress")
    private CreditorAddressPojo creditorAddress;
    @JsonProperty("remittanceInformationUnstructured")
    private String remittanceInformationUnstructured;
    @JsonProperty("iban")
    private String iban;

    /**
     * No args constructor for use in serialization
     * 
     */
    public MakePaymentForFixedIBANPojo() {
    }

    /**
     * 
     * @param debtorAccount
     * @param requestedExecutionDate
     * @param creditorAddress
     * @param creditorName
     * @param creditorAccount
     * @param debtorIdType
     * @param instructedAmount
     * @param debtorName
     * @param remittanceInformationUnstructured
     * @param debtorId
     * @param debtorType
     */
    public MakePaymentForFixedIBANPojo(InstructedAmountPojo instructedAmount, String iban, String debtorName, String debtorType, String debtorId, String debtorIdType, String requestedExecutionDate, String creditorName, CreditorAccountPojo creditorAccount, CreditorAddressPojo creditorAddress, String remittanceInformationUnstructured) {
        super();
        this.instructedAmount = instructedAmount;
      //  this.debtorAccount = debtorAccount;
        this.iban=iban;
        this.debtorName = debtorName;
        this.debtorType = debtorType;
        this.debtorId = debtorId;
        this.debtorIdType = debtorIdType;
        this.requestedExecutionDate = requestedExecutionDate;
        this.creditorName = creditorName;
        this.creditorAccount = creditorAccount;
        this.creditorAddress = creditorAddress;
        this.remittanceInformationUnstructured = remittanceInformationUnstructured;
        
    }

    @JsonProperty("instructedAmount")
    public InstructedAmountPojo getInstructedAmount() {
        return instructedAmount;
    }

    @JsonProperty("instructedAmount")
    public void setInstructedAmount(InstructedAmountPojo instructedAmount) {
        this.instructedAmount = instructedAmount;
    }

    @JsonProperty("debtorAccount")
    public DebtorAccountPojo getDebtorAccount() {
        return debtorAccount;
    }

    @JsonProperty("debtorAccount")
    public void setDebtorAccount(DebtorAccountPojo debtorAccount) {
        this.debtorAccount = debtorAccount;
    }

    @JsonProperty("debtorName")
    public String getDebtorName() {
        return debtorName;
    }

    @JsonProperty("debtorName")
    public void setDebtorName(String debtorName) {
        this.debtorName = debtorName;
    }

    @JsonProperty("debtorType")
    public String getDebtorType() {
        return debtorType;
    }

    @JsonProperty("debtorType")
    public void setDebtorType(String debtorType) {
        this.debtorType = debtorType;
    }

    @JsonProperty("debtorId")
    public String getDebtorId() {
        return debtorId;
    }

    @JsonProperty("debtorId")
    public void setDebtorId(String debtorId) {
        this.debtorId = debtorId;
    }

    @JsonProperty("debtorIdType")
    public String getDebtorIdType() {
        return debtorIdType;
    }

    @JsonProperty("debtorIdType")
    public void setDebtorIdType(String debtorIdType) {
        this.debtorIdType = debtorIdType;
    }

    @JsonProperty("requestedExecutionDate")
    public String getRequestedExecutionDate() {
        return requestedExecutionDate;
    }

    @JsonProperty("requestedExecutionDate")
    public void setRequestedExecutionDate(String requestedExecutionDate) {
        this.requestedExecutionDate = requestedExecutionDate;
    }

    @JsonProperty("creditorName")
    public String getCreditorName() {
        return creditorName;
    }

    @JsonProperty("creditorName")
    public void setCreditorName(String creditorName) {
        this.creditorName = creditorName;
    }

    @JsonProperty("creditorAccount")
    public CreditorAccountPojo getCreditorAccount() {
        return creditorAccount;
    }

    @JsonProperty("creditorAccount")
    public void setCreditorAccount(CreditorAccountPojo creditorAccount) {
        this.creditorAccount = creditorAccount;
    }

    @JsonProperty("creditorAddress")
    public CreditorAddressPojo getCreditorAddress() {
        return creditorAddress;
    }

    @JsonProperty("creditorAddress")
    public void setCreditorAddress(CreditorAddressPojo creditorAddress) {
        this.creditorAddress = creditorAddress;
    }

    @JsonProperty("remittanceInformationUnstructured")
    public String getRemittanceInformationUnstructured() {
        return remittanceInformationUnstructured;
    }

    @JsonProperty("remittanceInformationUnstructured")
    public void setRemittanceInformationUnstructured(String remittanceInformationUnstructured) {
        this.remittanceInformationUnstructured = remittanceInformationUnstructured;
    }

    @JsonProperty("iban")
    public String getIban() {
        return iban;
    }

    @JsonProperty("iban")
    public void setDebtorAccount(String iban) {
        this.iban = iban;
    }
}
