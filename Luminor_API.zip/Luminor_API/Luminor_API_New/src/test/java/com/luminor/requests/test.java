package com.luminor.requests;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import com.luminor.utils.SslconfigUtils;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class test {

	//public static void main(String args[]) {
		//System.out.println("Test inside");
		/*
		 * SSLConfig config=null; String password = "123456"; KeyStore keyStore = null;
		 * try { FileInputStream fis = new FileInputStream(
		 * "C:\\Users\\0019FH744\\ProjectWorkspace\\Luminor_API_Main\\src\\main\\resources\\keystore.jks"
		 * ); keyStore = KeyStore.getInstance("JKS"); keyStore.load( fis,
		 * password.toCharArray());
		 * 
		 * } catch (Exception ex) {
		 * System.out.println("Error while loading keystore >>>>>>>>>");
		 * ex.printStackTrace(); } if (keyStore != null) {
		 * 
		 * @SuppressWarnings("deprecation") org.apache.http.conn.ssl.SSLSocketFactory
		 * clientAuthFactory = null; try { clientAuthFactory = new
		 * org.apache.http.conn.ssl.SSLSocketFactory(keyStore, password); } catch
		 * (NoSuchAlgorithmException e) { e.printStackTrace(); } catch
		 * (KeyManagementException e) { e.printStackTrace(); } catch (KeyStoreException
		 * e) { e.printStackTrace(); } catch (UnrecoverableKeyException e) {
		 * e.printStackTrace(); } config = new
		 * SSLConfig().with().sslSocketFactory(clientAuthFactory).and().
		 * allowAllHostnames(); } // else return null;
		 */
	@Test(dataProvider = "TestCaseDataProvider")
	
	public void tpp(){
		RestAssured.config = RestAssured.config().sslConfig(SslconfigUtils.getSslConfig());		
		//RestAssured.useRelaxedHTTPSValidation();
		//String res = given().relaxedHTTPSValidation().when().post("https://psd2.tst.lumsolutions.net").asString();
		//System.out.println(res);
		
		  Response response = (Response) given()
		  .baseUri("https://psd2.stg.lumsolutions.net/v1")
		  .header("Content-Type","application/json") //.contentType(ContentType.JSON)
					
					  .body("{\n" + "\"appName\": \"Bhoomika1-25-08\",\n" + "\"contacts\": [\n" +
					  "\"admin@tpp-system-a.com\"\n" + "],\n" + "\"redirectUris\": [\n" +
					  "\"https://localhost/login\",\n" + "\"https://localhost/login1\",\n" +
					  "\"https://localhost/login2\",\n" + "\"https://localhost/login3\"]\n" + "}")
					 .when()//StringConstants.getReqBodyForPost())
		  .post("/tpp-clients").then().log().all();//.then().statusCode(200);
		  System.out.println(response.asString());
		 //FrameworkConstants.getEmployeesEndpoint());
//then().log().all();
	//	assertThat(response.getStatusCode())/
		//.isEqualTo(201);
		
	}

}
