package com.luminor.tests;

import java.util.Map;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.luminor.base.BaseTest;
import com.luminor.requests.ConsentAuthorizationViaAPI;
import com.luminor.requests.ConsentDetails;
import com.luminor.requests.FundsAvailable;
import com.luminor.requests.MakePayment;
import com.luminor.requests.TppRegistration;
import com.luminor.requests.TransactionHistory;
import com.luminor.requests.GetAccountList;
import com.luminor.utils.DataProviderUtils;

public class TestExecution extends BaseTest {

	GetAccountList getAccountList = new GetAccountList();
	ConsentDetails consent = new ConsentDetails();
	ConsentAuthorizationViaAPI consentAuth = new ConsentAuthorizationViaAPI();
	MakePayment makepayment = new MakePayment();
	FundsAvailable fund = new FundsAvailable();
	TransactionHistory transactionHistory = new TransactionHistory();
	TppRegistration tppregistration = new TppRegistration();
	// RequestSpecification reqSpec = RequestBulider.Builder();

	@Test(dataProvider = "dataProvider", dataProviderClass = DataProviderUtils.class)
	public void API_01_consentAuthorizationViaAPI(Map<String, String> map) throws Exception {

		System.out.println(map.get("TC_Name"));
		
		  consentAuth.consentAuthorizationDetails(map.get("username"),
		  map.get("perosonalCode"), map.get("recurringIndicator"),
		  map.get("validUntilInPutIndays"), map.get("frequencyPerDay"),
		  map.get("combinedServiceIndicator"));		
		
	}

	@Test(dataProvider = "dataProvider", dataProviderClass = DataProviderUtils.class)
	public void API_02_CreateConsentAndGetConsentDetails(Map<String, String> map) throws Exception {

		System.out.println(map.get("TC_Name"));
		
		consent.consentDetails(map.get("username"), map.get("perosonalCode"), map.get("recurringIndicator"),
				map.get("validUntilInPutIndays"), map.get("frequencyPerDay"), map.get("combinedServiceIndicator"));

	}

	@Test(dataProvider = "dataProvider", dataProviderClass = DataProviderUtils.class)
	public void API_03_makePaymentViaAPI(Map<String, String> map) throws Exception {

		 System.out.println(map.get("TC_Name"));
		// consentAuth.ConsentAuthorizationAPI(map.get("username"),map.get("perosonalCode"),map.get("recurringIndicator"),map.get("validUntilInPutIndays"),map.get("frequencyPerDay"),map.get("combinedServiceIndicator"));
		
		  makepayment.makePaymentViaAPI(map.get("username"), map.get("perosonalCode"),
		  map.get("amount"), map.get("currency"), map.get("debtorName"),
		  map.get("debtorType"), map.get("debtorId"), map.get("debtorIdType"),
		  map.get("requestedExecutionDate"), map.get("creditorName"),
		  map.get("creditorIban"), map.get("country"), map.get("street"),
		  map.get("remittanceInformationUnstructured"));
		 
		
	}
	
	@Test(dataProvider = "dataProvider", dataProviderClass = DataProviderUtils.class)
	public void API_06_makePaymentViaAPIFixedIban(Map<String, String> map) throws Exception {

		System.out.println(map.get("TC_Name"));
		// consentAuth.ConsentAuthorizationAPI(map.get("username"),map.get("perosonalCode"),map.get("recurringIndicator"),map.get("validUntilInPutIndays"),map.get("frequencyPerDay"),map.get("combinedServiceIndicator"));
		
		  makepayment.makePaymentViaAPIFixedIban(map.get("username"), map.get("perosonalCode"),
		  map.get("amount"),map.get("iban"), map.get("currency"), map.get("debtorName"),
		  map.get("debtorType"), map.get("debtorId"), map.get("debtorIdType"),
		  map.get("requestedExecutionDate"), map.get("creditorName"),
		  map.get("creditorIban"), map.get("country"), map.get("street"),
		  map.get("remittanceInformationUnstructured"));
		 
		
	}
	
	@Test(dataProvider = "dataProvider", dataProviderClass = DataProviderUtils.class)
	public void API_07_makePaymentViaAPIFixedIban(Map<String, String> map) throws Exception {

		System.out.println(map.get("TC_Name"));
		// consentAuth.ConsentAuthorizationAPI(map.get("username"),map.get("perosonalCode"),map.get("recurringIndicator"),map.get("validUntilInPutIndays"),map.get("frequencyPerDay"),map.get("combinedServiceIndicator"));
		
		  makepayment.makePaymentViaAPIFixedIban(map.get("username"), map.get("perosonalCode"),
		  map.get("amount"),map.get("iban"), map.get("currency"), map.get("debtorName"),
		  map.get("debtorType"), map.get("debtorId"), map.get("debtorIdType"),
		  map.get("requestedExecutionDate"), map.get("creditorName"),
		  map.get("creditorIban"), map.get("country"), map.get("street"),
		  map.get("remittanceInformationUnstructured"));
		 
		
	}
	
	
	
	@Test(dataProvider = "dataProvider", dataProviderClass = DataProviderUtils.class)
	public void API_04_fundsAvailable(Map<String, String> map) throws Exception{
		fund.fundsAvailableAmount(map.get("username"), map.get("perosonalCode"),map.get("amount"), map.get("currency"),map.get("recurringIndicator"), map.get("validUntilInPutIndays"), map.get("frequencyPerDay"),
				map.get("combinedServiceIndicator"));
	}
	
	@Test(dataProvider = "dataProvider", dataProviderClass = DataProviderUtils.class)
	public void API_05_TppRegistration(Map<String, String> map) throws Exception{
		tppregistration.createTPPRegistration(map.get("appName"), map.get("contacts"),map.get("tppRedirectUris"));
	}
	
	@Test(dataProvider = "dataProvider", dataProviderClass = DataProviderUtils.class)
	public void API_07_makePaymentViaUI(Map<String, String> map) throws Exception {

		 System.out.println(map.get("TC_Name"));
		// consentAuth.ConsentAuthorizationAPI(map.get("username"),map.get("perosonalCode"),map.get("recurringIndicator"),map.get("validUntilInPutIndays"),map.get("frequencyPerDay"),map.get("combinedServiceIndicator"));
		
		  makepayment.makePaymentViaUI(map.get("username"), map.get("perosonalCode"),
		  map.get("amount"), map.get("currency"), map.get("debtorName"),
		  map.get("debtorType"), map.get("debtorId"), map.get("debtorIdType"),
		  map.get("requestedExecutionDate"), map.get("creditorName"),
		  map.get("creditorIban"), map.get("country"), map.get("street"),
		  map.get("remittanceInformationUnstructured"));
		 
		
	}
	
	@Test(dataProvider = "dataProvider", dataProviderClass = DataProviderUtils.class)
	public void API_08_createAndAuthorizeConsentUI(Map<String, String> map) throws Exception {

		 System.out.println(map.get("TC_Name"));
		// consentAuth.ConsentAuthorizationAPI(map.get("username"),map.get("perosonalCode"),map.get("recurringIndicator"),map.get("validUntilInPutIndays"),map.get("frequencyPerDay"),map.get("combinedServiceIndicator"));
		
		  consent.createAndAuthorizeConsentUI(map.get("username"),
				  map.get("perosonalCode"), map.get("recurringIndicator"),
				  map.get("validUntilInPutIndays"), map.get("frequencyPerDay"),
				  map.get("combinedServiceIndicator"));
		 
		
	}
	
	@Test(dataProvider = "dataProvider", dataProviderClass = DataProviderUtils.class)
	public void API_09_initateAndSignedTransactionDetails(Map<String, String> map) throws Exception {

		System.out.println(map.get("TC_Name"));
		transactionHistory.getTransactionHistoryDetails(map.get("username"), map.get("perosonalCode"), map.get("recurringIndicator"),
				map.get("validUntilInPutIndays"), map.get("frequencyPerDay"), map.get("combinedServiceIndicator"));
		

	}
	
}
