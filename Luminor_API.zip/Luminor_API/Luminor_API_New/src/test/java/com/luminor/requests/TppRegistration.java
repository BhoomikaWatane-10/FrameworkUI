package com.luminor.requests;

import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.luminor.base.BaseTest;
import com.luminor.builders.RequestBulider;
import com.luminor.pojo.TPPRegistrationPojo;
import com.luminor.reports.Reporting;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TppRegistration extends BaseTest {

	public void createTPPRegistration(String appName, String contacts, String redirectUris) throws Exception {
		// System.out.println("testing");
		// RestAssured.config =
		// RestAssured.config().sslConfig(Sslconfiguration.getSslConfig());
		RequestSpecification reqSpec = RequestBulider.TPPBuilder();
		String BaseUriTpp = prop.getProperty("tppregistration");
		List<String> contact = new ArrayList<>();
		String contactArray[] = contacts.split(";");
		System.out.println(contactArray.length);

		for (int i = 0; i <= contactArray.length-1; i++) {
			contact.add(contactArray[i]);
		}

		List<String> redirectUri = new ArrayList<>();
		String redirectUriArray[] = redirectUris.split(";");
		for (int i = 0; i <= redirectUriArray.length-1; i++) {
			redirectUri.add(redirectUriArray[i]);
		}
		TPPRegistrationPojo tppregpojo = new TPPRegistrationPojo(appName, contact, redirectUri);
		try {
			Response resTppRegistration = RestAssured.given().spec(reqSpec)
					.body(tppregpojo).when().post("/tpp-clients");// .then().statusCode(200);
			
			ObjectMapper object = new ObjectMapper();
			String myData = object.writerWithDefaultPrettyPrinter().writeValueAsString(tppregpojo);
			System.out.println(myData);
			
			 System.out.println(resTppRegistration.statusCode());
			if (resTppRegistration.statusCode() == 200 || resTppRegistration.statusCode() == 201) {
				System.out.println(resTppRegistration.asPrettyString());
				Reporting.test.pass("Tpp registrtion:-->" + resTppRegistration.statusCode() + "<br>"
						+ resTppRegistration.asPrettyString());
			} else {
				Reporting.test.fail("Tpp registrtion:-->" + resTppRegistration.statusCode() + "<br>"
						+ resTppRegistration.asPrettyString());
				Assert.assertTrue(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
