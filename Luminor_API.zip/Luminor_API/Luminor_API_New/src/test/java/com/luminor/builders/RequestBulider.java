package com.luminor.builders;

import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import com.luminor.base.BaseTest;
import com.luminor.operations.GetToken;
import com.luminor.utils.SslconfigUtils;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;

public class RequestBulider extends BaseTest {
	static String bearer = "";
	// public static String bearer1 = "";
	static RequestSpecification reqspec;
	static RequestSpecBuilder reqBuilder;
	static String baseURI = prop.getProperty("baseURI");

	public static RequestSpecification Builder(String username,String personalCode) {//String username,String personalCode

		try {
			bearer = GetToken.getAccessToken(username,personalCode);//"k1FS24iP2AihfibBd/3ySoJpp0krmfILPMWfnMZ6Bxu2+9qZmwmO3FYPIHvyFJeEgGE1yM6QVOK1tEhs4QVS3QX4JEhCBseG8lvx+6ToTXDalHQOgLSnuDDT58S2gky4NuxlfwQQAcmdVGLflncAtFzkmdad6Wr/y6BmJ/QjbY5RS/UEJ9OHFSGxW2pVIVC2fyieJnzVrsBaR5Gqqp0HEwzGaVkvisz83GN0sT3uhtEXpHfnchrPcExS+WNH+JYVNzmdP/GbRDojNETZ3Ezb9o8F1KpPa1IssS1/adeczDMitAUqNerqRRIr3LMne9Y16WFC+eRkYa85giZ3O8sTybM3HHIhoYnm+Iy6nb8ljY6xHotbr1xd0qsmow4FE101ZYIAkwLtTuunX2GmLUGV9md3LLEpPNgwShsZAWsB6sPWSxtEeI3vfoeF06fbkD5tDLxRtxWJUHwI6HCfXG7INO/AC19Ub0MzMUTrCEWkONHjWcqd65YY66cgQcCDG20L9zTAmPrJ/6xEpKjt5X8oRKHztK+M5Nr+gGIeewT8lOlbC041zlSSvR+bcq07BqgwHLXVbWzj4oNzunJqmlp46IQwLDMluP+K2nI9KmRfzaIMCnrSZv0mceK8pfpv4JbRo45Hi4FE3LCUBXadTiWji5Muhof135v/Ly6/OBGcsgwqmzpUfWGXyy9Kq8dj0Vr26FYJbIiwU0gAv67tsigIe+w17lJ5ZWlLu43CcNUNAis1jVZU8wSk3hqo1R0H2mmyq2TdZpgLVL7IKg1KaNaRPkc1XuWpnJxJU8f+PhacS2vxa01pOiUCLMcSU5Q+FwkOoEytGjAWGuk8vDb8XKTMMRZWmEbwgQEUYRQ6QTKui0jYA1nM+ZmCkIs8O9DV44wDQ1C9w11jShOLBmescWGXza93c7sd2PbAAaO9ATfvfWuA1I5uve4MNesSas+jiWazhqauugVRpMj3Y7Gz0wtkXQ4dJZtvlGICosXBtfEbSzQmiSOdsqTWttgx6K2xv6HA9WIj4FrEDc9AcR5vBOe6gn4BgRPdNBSUMMLhU3vj98NBMULNQuryn6hFbVuBlOwnQRpbdm5rDSu+geuLUwe1lwGUGoHqHRTsfoIYVcHvIBKD34qW6kTpCZGskQ6WAw2TOKjUTHOLcWamgGM+pEFK1OsQ/QwgjilEG8Vskdqs3+X9rOMMtY3R1Lbw2kZQN4jOq5eQD9almrs91MfKoHcJCXff5OTSRbNJXPL45nB7aUxQUrp7if9/NSMuFoORtcqH/VRvey+dYrT82inbKSQipSm3Ep6NgR2YBQHxd/l984aQANEfbRodNigx9ghOzUwVBI+RSttUlrPgsYoPqgM2nF9af26vTjWl0RCtX6JQFrTgJACcoOztNdqdbDLFqndeiYB61KvFCJgYHqgflJNVtkatsAUrQtUOFFAqzPeSyClUdlkJ1v7LAa+yM8QGVyYcXsUtq3pgC+ce5+5WqS/2ojMR4BcX2YlQTgWX7Z52DXiEbHr7fxlNk8jce3ihwOxOL4fAEzznMmflZ8f8Yxc7Ea5iR/00n7S5XBa1bBVYjrfDTRM9G3CRzi4BRzrfeTyTyabmzx+g0RvPcK7qYsXBRKi8/V/+7Kx3VhYNBxeFadQdhcGEJXKQbha7e4rtTM0d44SpeG+CTTzD/xHuPsmTO5XxiXLIpnT43uR+8pVA395ZEbdijIyWTLcZCv6MVX0IRhi+jouv5MXWPzcenp6Sq7Sd+Aw25fmFc9QHHoAUijUQnZEm9lsr0ASfS8llr+jEBBqXgKkEKcZUU0TD7mFZ0xXETdtsm+3OhJSlKkL0uKvkPuTd0U/Lm9rx6lNhctaJ0uP7xLLmSMbsSojnu0BeChQlCvbpwcWUlr5XgMvgwtyPVbmFnvDwH1XAfGEUOWo6lfA6OFarDdN67fJSBcPA0ajLhUryokuCjH2cipQqm3to0jv9KW4UGbj3wtLkiCb3Lg1m5XVDpBL56FK7+VJCUwxx6CshPLz1+FflmhC23DDQQ4vb5v/e07cwu5Y9pT5qLEs+Q8G3VPG5d8yHTrkKANywPSwxrUVH37xfG8iwS8simCXs+7JvoqSyw+wFT5fgSoPdKUi0XZ6Fe80yZmPE3OrvfdO1l9yKmUYtPLGApfHi8SPlqUSywQXRIShpO308Dy/lZbjLMrFLITxsTsSIgQgG0iXnfCZV1FZl9P005qoSA68pWTexFe2OysI/tugtxBVg1xCrYk6bXYZYAW8p9yLt92p9rZjfh0PzN7tf6OrPyqX9Fl1205Y4Cm9vG/AyukGZyBJIUVsKAAjkTT/h6nP4APfRbqUDtH25n85EDxhBLUTXIcJdaQKacRKerxOoQEalv/MFVXz+oGIk0guZYlnBs4ceR+UNsceTyW8Yn1uOtJTjJVF3lc7TVlTSaIBzG8S1nl32zBizGjjt9Kx3DkNEd8JPxNbquPw1Kq4A6jhDgdvFL6/g5GwEjqWdKg1uYBYreWuXKxOj6dpxdR/jRg==";
			
		} catch (Exception e){//FileNotFoundException) {
			e.printStackTrace();
		} /*
			 * catch (InterruptedException e1) { e1.printStackTrace(); }
			 */

		Map<String, String> header = new HashMap<>();
		header.put("Authorization", "Bearer " + bearer);
		header.put("X-Request-ID", com.luminor.utils.RandomUtils.generateRandomString(14));
		header.put("PSU-IP-Address", "122.122.122");
		reqBuilder = new RequestSpecBuilder();
		reqBuilder.setBaseUri(baseURI).addHeaders(header)
				.setContentType(ContentType.JSON);
		reqspec = reqBuilder.build();
		return reqspec;
	}

	public static RequestSpecification TPPBuilder() {
		RestAssured.config = RestAssured.config().sslConfig(SslconfigUtils.getSslConfig());

		Map<String, String> header = new HashMap<>();
		// header.put("Authorization", "Bearer " + bearer);
		header.put("X-Request-ID", com.luminor.utils.RandomUtils.generateRandomString(14));
		// header.put("PSU-IP-Address", "122.122.122");
		reqBuilder = new RequestSpecBuilder();
		reqBuilder.setBaseUri(baseURI).addHeaders(header).setContentType(ContentType.JSON);
		reqspec = reqBuilder.build();
		return reqspec;

	}

	public static RequestSpecification RedirectURIBuilder(String username, String personalCode) {

		try {
			bearer = GetToken.getAccessToken(username, personalCode);
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}

		Map<String, String> header = new HashMap<>();
		header.put("Authorization", "Bearer " + bearer);
		header.put("X-Request-ID", com.luminor.utils.RandomUtils.generateRandomString(14));
		header.put("PSU-IP-Address", "122.122.122");
		header.put("Tpp-Redirect-URI", "https://www.microsoft.com");
		header.put("Tpp-Nok-Redirect-URI", "https://www.google.lv");
		header.put("Tpp-Client-Id", "37e6faeb-7638-4a19-9b11-8cba21de028f");
		reqBuilder = new RequestSpecBuilder();
		reqBuilder.setBaseUri(baseURI).addHeaders(header).setContentType(ContentType.JSON);
		reqspec = reqBuilder.build();
		return reqspec;
	}
	
	public static RequestSpecification Builder1() {//String username,String personalCode

		try {
			bearer = "k1FS24iP2AihfibBd/3ySoJpp0krmfILPMWfnMZ6Bxu2+9qZmwmO3FYPIHvyFJeEgGE1yM6QVOK1tEhs4QVS3QX4JEhCBseG8lvx+6ToTXDalHQOgLSnuDDT58S2gky4NuxlfwQQAcmdVGLflncAtFzkmdad6Wr/y6BmJ/QjbY5RS/UEJ9OHFSGxW2pVIVC2fyieJnzVrsBaR5Gqqp0HEyKAhXYLsg7TLaob5UEHK9hKKokm1R/DUE4jBluFZzE33Ni0AXhNK35+xB55+seFpfTNCxf1CNmXmM0J0apy7ora4lahb9GtufYYef2NXcOAQhlgXY5RVQI8WdzZ4f8btXGzwI+/maMl8TtHgsuj732yAGO1gG71NUqB2zfKkch5Hhz7L9qW8jVxDRe/kDJec3WS41b/61hslRz0d4/lSubctAMJg2nFuuQlgYc7SkmsfB1Tf9RBLwAzwKNcQPlSpXM4t8kDU/hULSvCGnglod8TghyulbODMiyP/Sxbkp0XKJquZ+QCq5czv6di40XpILEx082VxRPzSu6O8czcOSrqxOCipoe6dazju+Hniv3SaRS+x3bHVZ89iI4Sb51Ne0RzM1UCE30aLYcimGHL8xeZB3q8gewVdXuCPjkHjARGbf8QE/0knK0UdjKwCVbrJCN+yzIM3aaTPzAeqpAzvFtCx8cXj4LZdzSjjvqDwAOp6IZCnMtElXTCGilExyVd1k/GYFlmQ4e6yzqlMzJQ0HEB/0iHW5RGTo3mfiZM9Jr6Vv+nOJgpbYNpqXxjt7ojDYs0Ewg71Qw+Jgua0PsnHHPduWLIWVo6l9wSl9QcH9KQOY2ihZJ0+jSxgim84mRcA1iF0w26tdAhtajU6mznYihf1mKa+dmJGL8bQOFsg/VSISBCSAqXJ2AjRZ1NFs3sWZ+NktEy5EVz6z4utZWdTq63c/7524+/NjNBRK9q0CCCjdPLoY0RFwBy/kC7tQBgwNTm7Ls0ZXq7qWiNBVWYr3/HdTKWo9KFxkfPY+USLuqX9KfzicgBuCrg0YMvvAIify2JVpicdDfF6qHNNzMdpBu07/vqVJAvXZN2eq9DW1IS8t4v1dikTjIOwOE4b/wm6yE75EHOq/DBvpghMrqc59o9VDPrYbgbBhWT2I1eyeZ4/iLHFeRt3L5RKQtJbQM7OewZrVDu4Q5GVQuDn5TA0a/i5wPtTv65n4MNQ6cssS5LG9mWzkoRzQlMuvlfJmzbTcbzVDSYD3QABPGIfFNJtki+bTqz0p05mRwTqsTJl8ltnoaiavz+9YYHb4MyLhqpdxIh/blc+yCZyQ2ZNBtEIPeBDRJPYgiKu12D83QV7XFepSZsr7KQEvMl3GGbWhv6XxUmq+f5TZJnAr9b/J+xsGOq1Gs+TAvL0tNfyJ9Ekbyu1MONTD3B1pWsXw7l2W/pOJgKPzzU+bPpBVAN4n1ZkVuB1KsN3wODpXgBKFn+V337+0UmBLpk9SEFy7oC3CUuler7lsiWIF3Qi3BbWWdBIlCraQ//Rwv12qQ0KvUjTQDcvg0+SRpKUQKnHyd4vL3UM9F+MXqtyasP4QkcspthmwT+ooCJIpoLZb5LUjbVVnmW/LA41/veCDqVme6ejcTlOmEdvwD+YPPVosfxMaeWSzqTy3SKaO64LBSwxqhZStMSGG2fUEx8Zc+31jjpW/XyaI/2XF5rJ8Y0Gw4m+4c2OOQ3Xecpza5ksezys10ITdvvwFMhpYOhJd1/1AEU4/l8R67Nbiwz2FyWZ9eFcxbBX2+5fB/bCB/gLYWvuZe+OXvOFHUVXkH45Azn21k/f0fO+SKCkMvpElC5SB6y3IqN1+JEkiMbG9xEbwVcmhQvQEsk7ihE3ijjVmx8/vRwyUCM1dkuKYYheoHD2mrhr7SHivlBCMGi1uYI2okuxiOGojloZgeQw9EdavKcuuH6DbFbyyavbToLo9Ax1cwBXMZAyiSPXqp8Gn7ah3h6d8pGPMYNRiweO0/aMRWW+UYgxyJT2glNE8DoN4DcyntKKRWOM7NLt+8jFnSk5ZkMZfVOZPgjkcfKRNqeDpAk+yANrN9ykA7SBggwcHZJOLms9XkIgqFaYOIZiJl/bsud3flXWcV/sbk+WVN9pcStdP0malvUOonIY6wGoeDVFXuh7VMZpzumL0pe8MQ9F6STaEJPN02j8LZ7S4uYibUEUnR1DXmczHZlsF6alKJwCU9tvKY0cU8uq8+cJvyMqa4jG1A65qhUuml7DASpQW+JreiqNQgXPh9o9uF2/XwqVh4ux5Q65pS4WKBDRbqCCEAMc50W8My3NM3MbLhp6PmqGGmHOrDiho1RV3miO+6smW82WuH5SD09P2Xni6eH882q8rvPztw4zYBWiFwOsE0yZIOZknN4nLzsMTsaFRBNPftwaVaG6hJ11y27/p7kPJOe9pH4FYPOGXIUOmCjbLD+lo7uyCXGrsv8tNtX61xdR5JI4JrOOBlAPoU/HkZ4yo/1u0/2G/S1MRitXWKIkcYeB1DTnEIdnQ==";
			//GetToken.getAccessToken(username,personalCode);
		} catch (Exception e){//FileNotFoundException) {
			e.printStackTrace();
		} /*
			 * catch (InterruptedException e1) { e1.printStackTrace(); }
			 */

		Map<String, String> header = new HashMap<>();
		header.put("Authorization", "Bearer " + bearer);
		header.put("X-Request-ID", com.luminor.utils.RandomUtils.generateRandomString(14));
		header.put("PSU-IP-Address", "122.122.122");
		reqBuilder = new RequestSpecBuilder();
		reqBuilder.setBaseUri(baseURI).addHeaders(header)
				.setContentType(ContentType.JSON);
		reqspec = reqBuilder.build();
		return reqspec;
	}

}