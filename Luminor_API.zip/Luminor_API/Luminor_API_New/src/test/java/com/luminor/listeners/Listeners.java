package com.luminor.listeners;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.luminor.base.BaseTest;
import com.luminor.reports.Reporting;


public class Listeners extends BaseTest implements ITestListener {
	ExtentReports extent = Reporting.reportConfig();
	//Reporting reporting = new Reporting();
	ExtentTest test;
	//WebDriver driver;
	//ThreadLocal<ExtentTest> extentTest = new ThreadLocal<ExtentTest>();
	
	@Override
	public void onTestStart(ITestResult result) {
		// TODO Auto-generated method stub
		 test = Reporting.extentCreateTest(result.getMethod().getMethodName());
		 test.assignAuthor("Bhoomika Watane");
		//System.out.println(test);
		//extentTest.set(test);
		//extentTest.get().assignAuthor("Bhoomika");
		

	}

	@Override
	public void onTestSuccess(ITestResult result) {
		// TODO Auto-generated method stub
		//ITestListener.super.onTestSuccess(result);
		// System.out.println("pASS LISTENERS");
		test.log(Status.PASS, result.getMethod().getMethodName()+" test Passed");
		 
		/*
		 * String testMethodName = result.getMethod().getMethodName();
		 * 
		 * try { driver = (WebDriver)
		 * result.getTestClass().getRealClass().getDeclaredField("driver")
		 * .get(result.getInstance()); } catch (Exception e) {
		 * 
		 * } try {
		 * extentTest.get().addScreenCaptureFromPath(getScreenShotPath(testMethodName,
		 * driver), result.getMethod().getMethodName());
		 * 
		 * } catch (IOException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); }
		 */

	}

	@Override
	public void onTestFailure(ITestResult result) {
		// TODO Auto-generated method stub
		// ITestListener.super.onTestFailure(result);

		test.fail(result.getThrowable().toString());
		//WebDriver driver1 =null;
		String testMethodName =result.getMethod().getMethodName();
		
		try {
			/*
			 * driver1
			 * =(WebDriver)result.getTestClass().getRealClass().getDeclaredField("driver").
			 * get(result.getInstance()); System.out.println(driver1);
			 */
			test.addScreenCaptureFromPath(getScreenShotPath(testMethodName,driver), result.getMethod().getMethodName());
		} catch(Exception e)
		{
			System.out.println("Exception");
			//Reporting.test.fail(testMethodName);
		}
		/*
		 * try {
		 * //test.addScreenCaptureFromPath(getScreenShotPath(testMethodName,driver1),
		 * result.getMethod().getMethodName());
		 * //MediaEntityBuilder.createScreenCaptureFromBase64String(getScreenShotPath(
		 * testMethodName,driver)).build(); } catch (IOException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); }
		 */
	}

	@Override
	public void onFinish(ITestContext context) {
		// TODO Auto-generated method stub
		// ITestListener.super.onFinish(context);

		extent.flush();
		//Desktop.getDesktop().browse(new File( System.getProperty("user.dir") + "\\reports\\" + System.currentTimeMillis()+ "\\Report.html")).toURI();
	}
}
