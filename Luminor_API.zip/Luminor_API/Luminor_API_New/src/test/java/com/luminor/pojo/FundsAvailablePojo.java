package com.luminor.pojo;



import com.fasterxml.jackson.annotation.JsonProperty;



public class FundsAvailablePojo {
	@JsonProperty("instructedAmount")
	private InstructedAmountPojo instructedAmount;
	@JsonProperty("account")
	private AccountPojo account;
	
	public FundsAvailablePojo(InstructedAmountPojo instructedAmount, AccountPojo account) {
	super();
	this.instructedAmount = instructedAmount;
	this.account = account;
	}

	@JsonProperty("instructedAmount")
	public InstructedAmountPojo getInstructedAmount() {
	return instructedAmount;
	}

	@JsonProperty("instructedAmount")
	public void setInstructedAmount(InstructedAmountPojo instructedAmount) {
	this.instructedAmount = instructedAmount;
	}

	@JsonProperty("account")
	public AccountPojo getAccount() {
	return account;
	}

	@JsonProperty("account")
	public void setAccount(AccountPojo account) {
	this.account = account;
	}

	}

