package com.luminor.requests;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.luminor.base.BaseTest;
import com.luminor.builders.RequestBulider;
import com.luminor.operations.PerformOperations;
import com.luminor.pojo.AccessPojo;
import com.luminor.pojo.AccountPojo;
import com.luminor.pojo.GetAccountListPojo;
import com.luminor.reports.Reporting;
import com.luminor.utils.Calender;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class ConsentDetails extends BaseTest {

	CreateConsent consent = new CreateConsent();
	GetAccountList getaccount = new GetAccountList();

	PerformOperations common = new PerformOperations();
	String consentId = "";
	Response resConsentDetails = null;
	String iban = "";
	String bearer = "";
	String link = "";
	// String consentId = "";
	String authorizationId = "";
	String StringResponseGetAccountList = "";
	Response resGetAccountList = null;
	Select s = null;
	private String SmartIDButton = "//*[text()=\"Sign with Smart-ID\"]";

	// private String paymentProcessingRequest = "//*[text()=\"we're processing your
	// payment\"]";
	public void consentDetails(String username, String personalCode, String recurringIndicator,
			String validUntilInPutIndays, String frequencyPerDay, String combinedServiceIndicator) throws Exception {
		RequestSpecification reqSpec = RequestBulider.Builder(username, personalCode);
		String consentId = consent.createConsent(reqSpec, recurringIndicator, validUntilInPutIndays, frequencyPerDay,
				combinedServiceIndicator);
		Response resConsentDetails = RestAssured.given().spec(reqSpec).get("/consents/" + consentId).then().extract()
				.response();
		Reporting.test.pass("Consent Deails are :" + resConsentDetails.prettyPrint());
		System.out.println(resConsentDetails.statusCode());
		System.out.println(resConsentDetails.prettyPrint());
	}

	public void createAndAuthorizeConsentUI(String username, String personalCode, 
			String recurringIndicator, String validUntilInPutIndays, String frequencyPerDay,
			String combinedServiceIndicator) throws JsonProcessingException {
		String consentId1 = "";
		String ConsentSignURL = "";
		RequestSpecification reqSpec = RequestBulider.Builder(username, personalCode);
		boolean recurringIndicator1 = Boolean.parseBoolean(recurringIndicator);
		int validUntilInPutIndays1 = Integer.parseInt(validUntilInPutIndays);
		int frequencyPerDay1 = Integer.parseInt(frequencyPerDay);
		boolean combinedServiceIndicator1 = Boolean.parseBoolean(recurringIndicator);

		String iban = getaccount.getAccountList(reqSpec);
		System.out.println(iban);
		AccountPojo account = new AccountPojo(iban);
		ArrayList<AccountPojo> accountlist = new ArrayList<>();
		System.out.println(account);
		accountlist.add(account);

		AccessPojo access = new AccessPojo(accountlist);
		GetAccountListPojo getAccountList1 = new GetAccountListPojo(access, recurringIndicator1,
				Calender.getFutureDate(validUntilInPutIndays1), frequencyPerDay1, combinedServiceIndicator1);

		ObjectMapper object = new ObjectMapper();
		String myData = object.writerWithDefaultPrettyPrinter().writeValueAsString(getAccountList1);
		System.out.println(myData);

		Reporting.test.pass("Request Body of Consent Creation: " + "<br>" + myData);
		Response resConsent = RestAssured.given().spec(reqSpec).headers("Tpp-Redirect-Preferred","true","Tpp-Redirect-URI", "https://www.microsoft.com","Tpp-Nok-Redirect-URI", "https://www.google.lv","Tpp-Client-Id", prop.getProperty("clientId")).body(getAccountList1).post("/consents");

		System.out.println(resConsent.statusCode());
		System.out.println(resConsent.prettyPrint());

		consentId1 = common.getvalueFromJsonBodyResponse(resConsent.asPrettyString(), "consentId");
		ConsentSignURL = common.getvalueFromJsonBodyResponse(resConsent.asPrettyString(), "_links.scaRedirect.href");

		System.out.println(consentId1);
		if (resConsent.statusCode() == 200) {
			Reporting.test.pass("consent created " + "<Br>" + "Response code :" + resConsent.statusCode());
			Reporting.test.pass("Response: " + resConsent.prettyPrint());
		} else {
			Reporting.test.fail("consent created " + "<Br>" + "Response code :" + resConsent.statusCode());
			Reporting.test.fail("Response: " + resConsent.prettyPrint());
			Assert.assertFalse(false);
		}

		System.out.println(ConsentSignURL);
		Reporting.test.pass("Request Body for Payment " + "<br>" + myData);
		if (resConsent.statusCode() == 200 || resConsent.statusCode() == 201) {
			System.out.println(resConsent.prettyPrint());
			Reporting.test.pass("Response of Make Payment:" + "<br>" + resConsent.prettyPrint());
			common.waitForSync(SMALL_WAIT);

		} else {
			Reporting.test
					.fail("Response of Make Payment:" + "<br>" + resConsent.statusCode() + resConsent.prettyPrint());
		}
		common.waitForSync(SMALL_WAIT);
		if (ConsentSignURL != "") {
			driver.get(ConsentSignURL);
			common.waitForSync(LONG_WAIT);
		} else {
			Reporting.test.pass("URL value is Empty");
			Assert.assertFalse(false);
		}

		/*if (common.waitForvisible(By.id("smartid"))) {
			if (common.waitForvisible(By.id("lang-select"))) {
				s = new Select(driver.findElement(By.id("lang-select")));
				s.selectByValue("en");
				common.waitForSync(SMALL_WAIT);
			}
			driver.findElement(By.id("smartid")).click();
			Reporting.test.pass("clicked on SMART ID");
			common.waitForSync(SMALL_WAIT);
		}
		if (common.waitForvisible(By.id("idToken4"))) {
			driver.findElement(By.id("idToken4")).sendKeys(username);// "7939112"
			Reporting.test.pass("enter the User ID");
			common.waitForSync(SMALL_WAIT);
		}
		if (common.waitForvisible(By.id("idToken6"))) {
			driver.findElement(By.id("idToken6")).sendKeys(personalCode);// "46401266973"
			Reporting.test.pass("enter the Personal code");
			common.waitForSync(SMALL_WAIT);
		} else {
			// Reporting.test.pass("Personal code");
		}

		if (common.waitForvisible(By.id("idToken15_0"))) {
			driver.findElement(By.id("idToken15_0")).click();
			Reporting.test.pass("clicked on Log In");
			common.waitForSync(LONG_WAIT);
		}
*/
		/*
		 * else { Reporting.test.fail("URL is not Loaded"); Assert.assertFalse(false); }
		 */

		/*
		 * if (driver.findElement(By.
		 * xpath("//div[@class='btn mandate-selection col-lg-8 col-lg-offset-2 active']"
		 * )) .isDisplayed()) { common.waitForSync(5); driver.findElement(By.
		 * xpath("//div[@class='btn mandate-selection col-lg-8 col-lg-offset-2 active']"
		 * )) .click(); common.waitForSync(SMALL_WAIT); }
		 */
		if (common.waitForvisible(By.xpath("//*[@class='icon']"))) {
			common.waitForSync(5);
			driver.findElement(By.xpath("//*[@class='icon']")).click();
			common.waitForSync(SMALL_WAIT);
			driver.findElement(By.xpath("//ul[@class='languageselect-languages']/li/div[text()='en']")).click();
			common.waitForSync(SMALL_WAIT);
		}

		if (driver.findElement(By.xpath(SmartIDButton)).isDisplayed()) {

			driver.findElement(By.xpath(SmartIDButton)).click();
			common.waitForSync(SMALL_WAIT);
			if (driver.findElement(By.xpath("//*[@class='icon']")).isDisplayed()) {

				driver.findElement(By.xpath("//*[@class='icon']")).click();
				common.waitForSync(SMALL_WAIT);
				Reporting.test.pass("Please Wait..!! we are processing your payment");
				driver.findElement(By.xpath("//ul[@class='languageselect-languages']/li/div[text()='en']")).click();
				common.waitForSync(SMALL_WAIT);
			}
			Reporting.test.pass("Consent is Confirmed..!!!");

		}

		Response resConsentStatus = RestAssured.given().spec(reqSpec)
				.get("/consents/" + consentId1 +  "/status");

		if (resConsentStatus.statusCode() == 200 || resConsentStatus.statusCode() == 201) {
			System.out.println(resConsentStatus.prettyPrint());
			Reporting.test.pass("Payment authorization Status:" + "<br>" + resConsentStatus.prettyPrint());

		} else {
			Reporting.test.fail("Payment authorization Status:" + "<br>" + resConsentStatus.statusCode()
					+ resConsentStatus.prettyPrint());

	}
}}
