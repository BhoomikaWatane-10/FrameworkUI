
package com.luminor.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)

//@Generated("jsonschema2pojo")
public class GetAccountListPojo {

	@JsonProperty("access")
	private AccessPojo access;
	//@Column(name = "recurringIndicator",index = 2 ,converterClass = BooleanCoverterUtils.class)
	@JsonProperty("recurringIndicator")
	private Boolean recurringIndicator;
	
	@JsonProperty("validUntil")
	//@Column(name = "validUntil",index = 3 )
	private String validUntil;
	
	@JsonProperty("frequencyPerDay")
	//@Column(name = "frequencyPerDay",index = 4 ,converterClass = BooleanCoverterUtils.class)
	
	private Integer frequencyPerDay;
	//@Column(name = "combinedServiceIndicator",index = 5 ,converterClass =  BooleanCoverterUtils.class)
	@JsonProperty("combinedServiceIndicator")
	private Boolean combinedServiceIndicator;

	

	public GetAccountListPojo(AccessPojo access, Boolean recurringIndicator, String validUntil, Integer frequencyPerDay,
			Boolean combinedServiceIndicator) {
		this.access = access;
		this.recurringIndicator = recurringIndicator;
		this.validUntil = validUntil;
		this.frequencyPerDay = frequencyPerDay;
		this.combinedServiceIndicator = combinedServiceIndicator;

	}

	@JsonProperty("recurringIndicator")
	public Boolean getRecurringIndicator() {
		return recurringIndicator;
	}

	@JsonProperty("recurringIndicator")
	public void setRecurringIndicator(Boolean recurringIndicator) {
		this.recurringIndicator = recurringIndicator;
	}

	@JsonProperty("validUntil")
	public String getValidUntil() {
		return validUntil;
	}

	@JsonProperty("validUntil")
	public void setValidUntil(String validUntil) {
		this.validUntil = validUntil;
	}

	@JsonProperty("frequencyPerDay")
	public Integer getFrequencyPerDay() {
		return frequencyPerDay;
	}

	@JsonProperty("frequencyPerDay")
	public void setFrequencyPerDay(Integer frequencyPerDay) {
		this.frequencyPerDay = frequencyPerDay;
	}

	@JsonProperty("combinedServiceIndicator")
	public Boolean getCombinedServiceIndicator() {
		return combinedServiceIndicator;
	}

	@JsonProperty("combinedServiceIndicator")
	public void setCombinedServiceIndicator(Boolean combinedServiceIndicator) {
		this.combinedServiceIndicator = combinedServiceIndicator;
	}

	@JsonProperty("access")
	public AccessPojo getAccess() {
		return access;
	}

	@JsonProperty("access")
	public void setAccess(AccessPojo access) {
		this.access = access;
	}

}
