package com.luminor.requests;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.luminor.base.BaseTest;
import com.luminor.operations.PerformOperations;
import com.luminor.pojo.AccessPojo;
import com.luminor.pojo.AccountPojo;
import com.luminor.pojo.GetAccountListPojo;
import com.luminor.reports.Reporting;
import com.luminor.utils.Calender;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateConsent extends BaseTest {

	GetAccountList getaccount = new GetAccountList();
	PerformOperations common = new PerformOperations();
	
	String iban = "";
	String bearer = "";
	String link = "";
	String consentId = "";
	String authorizationId = "";
	String StringResponseGetAccountList = "";
	Response resGetAccountList = null;
	Select s = null;
	private String SmartIDButton = "//*[text()=\"Sign with Smart-ID\"]";
	//private String paymentProcessingRequest = "//*[text()=\"we're processing your payment\"]";
//	private String backToserviceProviderButton = "//*[contains(text(),\"You will pay\"]";
	public String createConsent(RequestSpecification reqSpec,String recurringIndicator,String validUntilInPutIndays,String frequencyPerDay,String combinedServiceIndicator) throws JsonProcessingException {

		boolean recurringIndicator1=Boolean.parseBoolean(recurringIndicator);
		int validUntilInPutIndays1=Integer.parseInt(validUntilInPutIndays);
		int frequencyPerDay1=Integer.parseInt(frequencyPerDay);
		boolean combinedServiceIndicator1=Boolean.parseBoolean(recurringIndicator);
		
		
		String iban=getaccount.getAccountList(reqSpec);
		System.out.println(iban);
		AccountPojo account = new AccountPojo(iban);
		ArrayList<AccountPojo> accountlist = new ArrayList<>();
		System.out.println(account);
		accountlist.add(account);
		
		AccessPojo access = new AccessPojo(accountlist);
		GetAccountListPojo getAccountList1 = new GetAccountListPojo(access, recurringIndicator1,Calender.getFutureDate(validUntilInPutIndays1) , frequencyPerDay1, combinedServiceIndicator1);

		ObjectMapper object = new ObjectMapper();
		String myData = object.writerWithDefaultPrettyPrinter().writeValueAsString(getAccountList1);
		System.out.println(myData);
		
		Reporting.test.pass("Request Body of Consent Creation: "+"<br>"+myData);
		Response resConsent = RestAssured.given().spec(reqSpec).body(getAccountList1).post("/consents");
		
		
		System.out.println(resConsent.statusCode());
		System.out.println(resConsent.prettyPrint());
		consentId = common.getvalueFromJsonBodyResponse(resConsent.asPrettyString(),"consentId");
		System.out.println(consentId);
		if(resConsent.statusCode()==200) {
			Reporting.test.pass("consent created "+"<Br>"+"Response code :"+resConsent.statusCode());
			Reporting.test.pass("Response: "+resConsent.prettyPrint());
		}
		else {
			Reporting.test.fail("consent created "+"<Br>"+"Response code :"+resConsent.statusCode());
			Reporting.test.fail("Response: "+resConsent.prettyPrint());
			Assert.assertFalse(false);
		}
		
		return consentId;
	}
	
	
	
	
	
}
