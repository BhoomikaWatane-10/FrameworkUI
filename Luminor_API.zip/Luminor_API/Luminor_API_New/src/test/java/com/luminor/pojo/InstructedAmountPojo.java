package com.luminor.pojo;



import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;



public class InstructedAmountPojo {

    @JsonProperty("amount")
    private String amount;
    @JsonProperty("currency")
    private String currency;

    /**
     * No args constructor for use in serialization
     * 
     */
    public InstructedAmountPojo() {
    }

    /**
     * 
     * @param amount
     * @param currency
     */
    public InstructedAmountPojo(String amount, String currency) {
        super();
        this.amount = amount;
        this.currency = currency;
    }

    @JsonProperty("amount")
    public String getAmount() {
        return amount;
    }

    @JsonProperty("amount")
    public void setAmount(String amount) {
        this.amount = amount;
    }

    @JsonProperty("currency")
    public String getCurrency() {
        return currency;
    }

    @JsonProperty("currency")
    public void setCurrency(String currency) {
        this.currency = currency;
    }

}
