package com.luminor.pojo;



import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


public class CreditorAddressPojo {

    @JsonProperty("country")
    private String country;
    @JsonProperty("street")
    private String street;

    /**
     * No args constructor for use in serialization
     * 
     */
    public CreditorAddressPojo() {
    }

    /**
     * 
     * @param country
     * @param street
     */
    public CreditorAddressPojo(String country, String street) {
        super();
        this.country = country;
        this.street = street;
    }

    @JsonProperty("country")
    public String getCountry() {
        return country;
    }

    @JsonProperty("country")
    public void setCountry(String country) {
        this.country = country;
    }

    @JsonProperty("street")
    public String getStreet() {
        return street;
    }

    @JsonProperty("street")
    public void setStreet(String street) {
        this.street = street;
    }

}
