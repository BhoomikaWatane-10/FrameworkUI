
package com.luminor.pojo;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

public class TPPRegistrationPojo {

    @JsonProperty("appName")
    private String appName;
    @JsonProperty("contacts")
    private List<String> contacts = null;
    @JsonProperty("redirectUris")
    private List<String> redirectUris = null;

    
    public TPPRegistrationPojo(String appName, List<String> contacts, List<String> redirectUris) {
        super();
        this.appName = appName;
        this.contacts = contacts;
        this.redirectUris = redirectUris;
    }

    @JsonProperty("appName")
    public String getAppName() {
        return appName;
    }

    @JsonProperty("appName")
    public void setAppName(String appName) {
        this.appName = appName;
    }

    @JsonProperty("contacts")
    public List<String> getContacts() {
        return contacts;
    }

    @JsonProperty("contacts")
    public void setContacts(List<String> contacts) {
        this.contacts = contacts;
    }

    @JsonProperty("redirectUris")
    public List<String> getRedirectUris() {
        return redirectUris;
    }

    @JsonProperty("redirectUris")
    public void setRedirectUris(List<String> redirectUris) {
        this.redirectUris = redirectUris;
    }

}
