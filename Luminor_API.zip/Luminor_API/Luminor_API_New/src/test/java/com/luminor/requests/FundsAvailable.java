package com.luminor.requests;

import org.testng.Assert;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.luminor.base.BaseTest;
import com.luminor.builders.RequestBulider;
import com.luminor.pojo.AccountPojo;
import com.luminor.pojo.FundsAvailablePojo;
import com.luminor.pojo.InstructedAmountPojo;
import com.luminor.reports.Reporting;

import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class FundsAvailable extends BaseTest {

	GetAccountList accountList = new GetAccountList();
	ConsentAuthorizationViaAPI consentauthorize = new ConsentAuthorizationViaAPI();
	CreateConsent consent = new CreateConsent();
	private String iban = "";
	private String consentId = "";

	public void fundsAvailableAmount(String username, String perosonalCode, String amount, String currency,
			String recurringIndicator, String validUntilInPutIndays, String frequencyPerDay,
			String combinedServiceIndicator) {
		RequestSpecification reqSpec = RequestBulider.Builder(username, perosonalCode);
		try {
			consentId = consent.createConsent(reqSpec, recurringIndicator, validUntilInPutIndays, frequencyPerDay,
					combinedServiceIndicator);

			consentauthorize.ConsentAuthorizationAPI(reqSpec, consentId, recurringIndicator, validUntilInPutIndays,
					frequencyPerDay, combinedServiceIndicator);
			iban = accountList.getAccountList(reqSpec);
			// String iban;
			AccountPojo account = new AccountPojo(iban);
			InstructedAmountPojo Instructedamount = new InstructedAmountPojo(amount, currency);
			FundsAvailablePojo fund = new FundsAvailablePojo(Instructedamount, account);
			ObjectMapper object = new ObjectMapper();
			String myData;
		//	try {
				myData = object.writerWithDefaultPrettyPrinter().writeValueAsString(fund);
				System.out.println(myData);
		//	} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			//}

			Response resFundsAvailable = RestAssured.given().spec(reqSpec).header("Consent-id", consentId).body(fund)
					.post("/funds-confirmations");
			if (resFundsAvailable.statusCode() == 200 || resFundsAvailable.statusCode() == 201) {
				System.out.println(resFundsAvailable.prettyPrint());
				Reporting.test.pass("Response of fundsAvailable:" + "<br>" + resFundsAvailable.prettyPrint());

			} else {
				Reporting.test.fail("Response of fundsAvailable:" + "<br>" + resFundsAvailable.statusCode()
						+ resFundsAvailable.prettyPrint());
				Assert.assertTrue(false);
			}
		} catch (JsonProcessingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
}
