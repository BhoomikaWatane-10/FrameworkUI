
package com.luminor.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
//Generated("jsonschema2pojo")
public class AccountPojo {

	@JsonProperty("iban")
	private String iban;

	public AccountPojo(String iban) {
		this.iban = iban;

	}

	@JsonProperty("iban")
	public String getIban() {
		return iban;
	}

	@JsonProperty("iban")
	public void setIban(String iban) {
		this.iban = iban;
	}

}
